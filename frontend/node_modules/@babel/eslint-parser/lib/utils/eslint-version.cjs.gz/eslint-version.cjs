module.exports = parseInt(require("eslint/package.json").version, 10);

//# sourceMappingURL=eslint-version.cjs.map
