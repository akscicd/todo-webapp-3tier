"use strict";

exports.__esModule = true;
exports.usage = exports.entry = void 0;
var _usage = _interopRequireDefault(require("./usage"));
exports.usage = _usage.default;
var _entry = _interopRequireDefault(require("./entry"));
exports.entry = _entry.default;
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }