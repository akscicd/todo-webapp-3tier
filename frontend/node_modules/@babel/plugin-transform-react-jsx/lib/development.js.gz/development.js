"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _createPlugin = require("./create-plugin.js");
var _default = (0, _createPlugin.default)({
  name: "transform-react-jsx/development",
  development: true
});
exports.default = _default;

//# sourceMappingURL=development.js.map
