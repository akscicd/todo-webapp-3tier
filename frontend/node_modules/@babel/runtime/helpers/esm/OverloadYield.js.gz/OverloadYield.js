export default function _OverloadYield(t, e) {
  this.v = t, this.k = e;
}