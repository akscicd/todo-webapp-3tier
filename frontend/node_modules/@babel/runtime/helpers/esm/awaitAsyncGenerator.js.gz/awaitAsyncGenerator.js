import OverloadYield from "./OverloadYield.js";
export default function _awaitAsyncGenerator(e) {
  return new OverloadYield(e, 0);
}