export default function _identity(x) {
  return x;
}