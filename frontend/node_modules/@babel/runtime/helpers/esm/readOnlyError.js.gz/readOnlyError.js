export default function _readOnlyError(name) {
  throw new TypeError("\"" + name + "\" is read-only");
}