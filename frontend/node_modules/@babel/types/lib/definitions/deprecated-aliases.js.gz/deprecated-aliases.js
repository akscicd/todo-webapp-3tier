"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEPRECATED_ALIASES = void 0;
const DEPRECATED_ALIASES = {
  ModuleDeclaration: "ImportOrExportDeclaration"
};
exports.DEPRECATED_ALIASES = DEPRECATED_ALIASES;

//# sourceMappingURL=deprecated-aliases.js.map
