export declare function adjustSelectorSpecificity(selector: string, amount: number): string;
