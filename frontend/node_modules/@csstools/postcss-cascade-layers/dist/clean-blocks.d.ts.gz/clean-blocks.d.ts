import type { Container } from 'postcss';
export declare function removeEmptyDescendantBlocks(block: Container): void;
export declare function removeEmptyAncestorBlocks(block: Container): void;
