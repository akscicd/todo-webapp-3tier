import type { Container, ChildNode } from 'postcss';
import type { Model } from './model';
export declare function desugarNestedLayers(root: Container<ChildNode>, model: Model): void;
