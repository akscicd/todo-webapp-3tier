import type { AtRule } from 'postcss';
export declare function getConditionalAtRuleAncestor(layerRule: AtRule): AtRule | null;
