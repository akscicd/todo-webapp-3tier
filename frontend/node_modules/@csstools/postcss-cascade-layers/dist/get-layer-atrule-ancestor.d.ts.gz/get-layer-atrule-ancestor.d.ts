import type { AtRule, Node } from 'postcss';
export declare function getLayerAtRuleAncestor(node: Node): AtRule | null;
