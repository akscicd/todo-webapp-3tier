import type { PluginCreator } from 'postcss';
import { pluginOptions } from './options';
declare const creator: PluginCreator<pluginOptions>;
export default creator;
