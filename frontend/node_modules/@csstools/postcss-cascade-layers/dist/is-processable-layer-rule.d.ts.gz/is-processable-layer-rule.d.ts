import type { AtRule } from 'postcss';
export declare function isProcessableLayerRule(atRule: AtRule): boolean;
