export declare type pluginOptions = {
    onRevertLayerKeyword: 'warn' | false;
    onConditionalRulesChangingLayerOrder: 'warn' | false;
    onImportLayerRule: 'warn' | false;
};
