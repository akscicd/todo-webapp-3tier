import type { Container } from 'postcss';
export declare function splitImportantStyles(root: Container): void;
