declare type color = [number, number, number];
export declare function cieXyz50ToSRgb(xyz: color): color;
export {};
