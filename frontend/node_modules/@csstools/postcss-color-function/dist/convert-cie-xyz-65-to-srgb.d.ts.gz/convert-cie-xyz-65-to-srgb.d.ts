declare type color = [number, number, number];
export declare function cieXyz65ToSRgb(xyz: color): color;
export {};
