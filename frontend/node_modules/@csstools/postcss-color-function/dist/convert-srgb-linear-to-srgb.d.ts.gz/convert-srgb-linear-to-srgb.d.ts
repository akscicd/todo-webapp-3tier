declare type color = [number, number, number];
export declare function sRgbLinearToSRgb(linearSRgb: color): color;
export {};
