declare type color = [number, number, number];
export declare function sRgbToSRgb(sRgb: color): color;
export {};
