# Changes to PostCSS HWB Function

### 1.0.2 (July 8, 2022)

- Fix case insensitive matching.

### 1.0.1 (May 18, 2022)

- Fix grayscale conversions.

### 1.0.0 (January 22, 2022)

- Initial version
