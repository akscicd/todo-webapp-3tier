declare type color = [number, number, number];
export declare function hwbToRgb(hwb: color): color;
export {};
