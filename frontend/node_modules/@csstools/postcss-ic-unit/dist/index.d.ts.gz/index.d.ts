import type { PluginCreator } from 'postcss';
declare type pluginOptions = {
    preserve?: boolean;
    enableProgressiveCustomProperties?: boolean;
};
declare const postcssPlugin: PluginCreator<pluginOptions>;
export default postcssPlugin;
