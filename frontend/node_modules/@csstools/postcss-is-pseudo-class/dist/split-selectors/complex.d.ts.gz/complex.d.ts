export default function complexSelectors(selectors: string[], pluginOptions: {
    onComplexSelector?: 'warning';
}, warnOnComplexSelector: () => void, warnOnPseudoElements: () => void): string[];
