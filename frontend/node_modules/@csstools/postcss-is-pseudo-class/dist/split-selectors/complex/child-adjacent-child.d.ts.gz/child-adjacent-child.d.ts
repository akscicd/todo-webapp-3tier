export declare function childAdjacentChild(selector: any): boolean;
