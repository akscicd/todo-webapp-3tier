export declare function isInCompoundWithOneOtherElement(selector: any): boolean;
