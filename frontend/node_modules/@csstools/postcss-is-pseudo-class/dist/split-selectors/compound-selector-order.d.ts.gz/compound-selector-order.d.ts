export declare function sortCompoundSelectorsInsideComplexSelector(node: any): void;
