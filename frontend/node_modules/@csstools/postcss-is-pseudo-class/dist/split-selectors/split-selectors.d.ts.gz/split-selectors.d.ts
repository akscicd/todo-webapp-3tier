export default function splitSelectors(selectors: string[], pluginOptions: {
    specificityMatchingName: string;
}, recursionDepth?: number): any[];
