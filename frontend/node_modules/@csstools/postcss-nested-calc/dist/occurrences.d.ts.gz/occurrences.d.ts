export declare function numberOfCalcOccurrences(value: string): number;
