/**
 * Specification: https://www.w3.org/TR/css-display-3/#the-display-properties
 */
declare const _default: Map<string, string>;
export default _default;
