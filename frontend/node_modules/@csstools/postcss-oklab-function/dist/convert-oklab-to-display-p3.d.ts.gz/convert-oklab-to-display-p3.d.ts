declare type color = [number, number, number];
export declare function oklabToDisplayP3(oklabRaw: color): [color, boolean];
export {};
