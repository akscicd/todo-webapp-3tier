declare type color = [number, number, number];
export declare function oklchToSRgb(oklchRaw: color): color;
export {};
