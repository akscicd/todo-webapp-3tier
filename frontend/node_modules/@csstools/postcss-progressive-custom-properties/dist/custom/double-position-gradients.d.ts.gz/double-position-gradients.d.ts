import type { Node } from 'postcss-value-parser';
export declare function doublePositionGradients(node: Node): Array<string>;
