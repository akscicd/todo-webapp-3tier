import type { PluginCreator } from 'postcss';
declare const creator: PluginCreator<null>;
export default creator;
