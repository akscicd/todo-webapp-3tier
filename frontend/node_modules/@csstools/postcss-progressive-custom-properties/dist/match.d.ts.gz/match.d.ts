export declare function matches(a: any, b: any): boolean;
