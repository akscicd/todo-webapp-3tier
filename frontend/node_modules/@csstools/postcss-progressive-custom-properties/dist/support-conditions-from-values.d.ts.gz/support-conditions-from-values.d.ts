export declare function supportConditionsFromValue(value: string): Array<string>;
