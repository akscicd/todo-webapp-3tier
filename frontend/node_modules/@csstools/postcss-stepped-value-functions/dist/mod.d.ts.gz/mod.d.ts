import type { Declaration, Result } from 'postcss';
import { pluginOptions } from './index';
declare const modFunctionCheck = "mod(";
declare function transformModFunction(decl: Declaration, result: Result, options: pluginOptions): string | undefined;
export { modFunctionCheck, transformModFunction };
