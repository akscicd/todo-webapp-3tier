exports._default = require("./emotion-babel-plugin.cjs.js").default;
