export {
  macros
} from "./emotion-babel-plugin.cjs.js";
export { _default as default } from "./emotion-babel-plugin.cjs.default.js";
