exports._default = require("./emotion-cache.cjs.js").default;
