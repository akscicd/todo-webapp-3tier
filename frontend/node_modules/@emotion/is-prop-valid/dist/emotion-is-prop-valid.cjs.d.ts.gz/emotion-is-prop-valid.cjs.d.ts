export * from "./declarations/src/index";
export { default } from "./declarations/src/index";
//# sourceMappingURL=emotion-is-prop-valid.cjs.d.ts.map
