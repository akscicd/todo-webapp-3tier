exports._default = require("./emotion-is-prop-valid.cjs.js").default;
