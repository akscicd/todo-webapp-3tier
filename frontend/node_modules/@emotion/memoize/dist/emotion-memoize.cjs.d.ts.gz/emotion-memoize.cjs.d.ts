export * from "./declarations/src/index";
export { default } from "./declarations/src/index";
//# sourceMappingURL=emotion-memoize.cjs.d.ts.map
