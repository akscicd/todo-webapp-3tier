exports._default = require("./emotion-memoize.cjs.js").default;
