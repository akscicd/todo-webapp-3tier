export * from "../../dist/declarations/src/_isolated-hnrs";
export { default } from "../../dist/declarations/src/_isolated-hnrs";
//# sourceMappingURL=emotion-react-_isolated-hnrs.cjs.d.ts.map
