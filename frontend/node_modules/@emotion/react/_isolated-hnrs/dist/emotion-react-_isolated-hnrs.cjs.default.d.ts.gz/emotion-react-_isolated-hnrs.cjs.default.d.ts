export { default as _default } from "../../dist/declarations/src/_isolated-hnrs.js"
