exports._default = require("./emotion-react-_isolated-hnrs.cjs.js").default;
