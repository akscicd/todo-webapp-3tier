export * from "./declarations/src/index";
//# sourceMappingURL=emotion-react.cjs.d.ts.map
