export * from "../../dist/declarations/src/jsx-dev-runtime";
//# sourceMappingURL=emotion-react-jsx-dev-runtime.cjs.d.ts.map
