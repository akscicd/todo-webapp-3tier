export * from "../../dist/declarations/src/jsx-runtime";
//# sourceMappingURL=emotion-react-jsx-runtime.cjs.d.ts.map
