export * from "./declarations/src/index";
//# sourceMappingURL=emotion-serialize.cjs.d.ts.map
