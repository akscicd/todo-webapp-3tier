export {
  serializeStyles
} from "./emotion-serialize.cjs.js";
