export {
  StyleSheet
} from "./emotion-sheet.cjs.js";
