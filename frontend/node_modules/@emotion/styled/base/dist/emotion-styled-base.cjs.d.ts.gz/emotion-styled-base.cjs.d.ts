export * from "../../dist/declarations/src/base";
export { default } from "../../dist/declarations/src/base";
//# sourceMappingURL=emotion-styled-base.cjs.d.ts.map
