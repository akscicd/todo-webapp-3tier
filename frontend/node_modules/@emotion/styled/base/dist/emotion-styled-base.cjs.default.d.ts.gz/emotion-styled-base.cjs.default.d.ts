export { default as _default } from "../../dist/declarations/src/base.js"
