exports._default = require("./emotion-styled-base.cjs.js").default;
