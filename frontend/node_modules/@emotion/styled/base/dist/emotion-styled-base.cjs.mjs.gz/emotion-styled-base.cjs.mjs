export {
  
} from "./emotion-styled-base.cjs.js";
export { _default as default } from "./emotion-styled-base.cjs.default.js";
