export * from "./declarations/src/index";
export { default } from "./declarations/src/index";
//# sourceMappingURL=emotion-styled.cjs.d.ts.map
