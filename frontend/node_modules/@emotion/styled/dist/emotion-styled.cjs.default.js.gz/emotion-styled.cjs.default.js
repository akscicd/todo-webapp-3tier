exports._default = require("./emotion-styled.cjs.js").default;
