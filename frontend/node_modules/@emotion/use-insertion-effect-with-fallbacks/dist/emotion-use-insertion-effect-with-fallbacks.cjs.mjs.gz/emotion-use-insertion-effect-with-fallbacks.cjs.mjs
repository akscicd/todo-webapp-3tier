export {
  useInsertionEffectAlwaysWithSyncFallback,
  useInsertionEffectWithLayoutFallback
} from "./emotion-use-insertion-effect-with-fallbacks.cjs.js";
