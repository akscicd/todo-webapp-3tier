export * from "./declarations/src/index";
//# sourceMappingURL=emotion-utils.cjs.d.ts.map
