export {
  getRegisteredStyles,
  insertStyles,
  registerStyles
} from "./emotion-utils.cjs.js";
