export * from "./declarations/src/index";
export { default } from "./declarations/src/index";
//# sourceMappingURL=emotion-weak-memoize.cjs.d.ts.map
