exports._default = require("./emotion-weak-memoize.cjs.js").default;
