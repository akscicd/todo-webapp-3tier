import type { Rect } from '@floating-ui/core';
export declare function paintDebugRects(elementRect: Rect, clippingRect: Rect): void;
