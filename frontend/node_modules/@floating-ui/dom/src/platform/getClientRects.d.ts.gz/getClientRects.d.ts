export declare function getClientRects(element: Element): DOMRect[];
