import type { Dimensions } from '@floating-ui/core';
export declare function getDimensions(element: Element): Dimensions;
