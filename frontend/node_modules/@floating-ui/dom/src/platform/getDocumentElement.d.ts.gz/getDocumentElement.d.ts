export { getDocumentElement } from '@floating-ui/utils/dom';
