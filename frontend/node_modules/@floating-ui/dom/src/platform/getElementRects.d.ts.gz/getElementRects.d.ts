import { Platform } from '../types';
export declare const getElementRects: Platform['getElementRects'];
