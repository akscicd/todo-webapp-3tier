type Polyfill = (element: HTMLElement) => Element | null;
export declare function getOffsetParent(element: Element, polyfill?: Polyfill): Element | Window;
export {};
