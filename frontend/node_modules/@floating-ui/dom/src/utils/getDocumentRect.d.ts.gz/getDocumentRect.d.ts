import type { Rect } from '@floating-ui/core';
export declare function getDocumentRect(element: HTMLElement): Rect;
