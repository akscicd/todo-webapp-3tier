export declare function getWindowScrollBarX(element: Element): number;
