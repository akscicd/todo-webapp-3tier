import type { VirtualElement } from '../types';
export declare function unwrapElement(element: Element | VirtualElement): Element | undefined;
