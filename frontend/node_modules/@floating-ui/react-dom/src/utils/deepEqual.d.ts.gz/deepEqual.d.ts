export declare function deepEqual(a: any, b: any): boolean;
