export declare function getDPR(element: Element): number;
