export declare function roundByDPR(element: Element, value: number): number;
