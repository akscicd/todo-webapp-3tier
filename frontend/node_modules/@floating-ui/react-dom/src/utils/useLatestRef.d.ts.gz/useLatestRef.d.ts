import * as React from 'react';
export declare function useLatestRef<T>(value: T): React.MutableRefObject<T>;
