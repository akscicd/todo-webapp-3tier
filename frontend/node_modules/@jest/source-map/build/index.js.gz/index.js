'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});
Object.defineProperty(exports, 'getCallsite', {
  enumerable: true,
  get: function () {
    return _getCallsite.default;
  }
});

var _getCallsite = _interopRequireDefault(require('./getCallsite'));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {default: obj};
}
