/**
 * The foundation for building custom-styled multi-selection select components.
 *
 * @deprecated The multi-select functionality is now available in the Select component. Replace <MultiSelect> with <Select multiple /> in your code.
 * @ignore - do not document.
 */
export declare function MultiSelect(): null;
