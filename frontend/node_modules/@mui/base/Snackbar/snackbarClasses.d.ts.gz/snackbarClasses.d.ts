export interface SnackbarClasses {
    /** Class name applied to the root element. */
    root: string;
}
export declare function getSnackbarUtilityClass(slot: string): string;
export declare const snackbarClasses: SnackbarClasses;
