'use client';

export { TabPanel } from './TabPanel';
export * from './TabPanel.types';
export * from './tabPanelClasses';