export { TextareaAutosize } from './TextareaAutosize';
export * from './TextareaAutosize.types';
