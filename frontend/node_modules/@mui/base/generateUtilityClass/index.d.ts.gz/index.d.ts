export { unstable_generateUtilityClass as generateUtilityClass } from '@mui/utils';
export type { GlobalStateSlot } from '@mui/utils';
