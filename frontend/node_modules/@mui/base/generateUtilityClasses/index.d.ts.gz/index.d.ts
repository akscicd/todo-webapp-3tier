export { unstable_generateUtilityClasses as generateUtilityClasses } from '@mui/utils';
