import * as React from 'react';
var DropdownContext = /*#__PURE__*/React.createContext(null);
export { DropdownContext };