export var SelectActionTypes = {
  buttonClick: 'buttonClick',
  browserAutoFill: 'browserAutoFill'
};