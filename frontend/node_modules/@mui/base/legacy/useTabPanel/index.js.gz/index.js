'use client';

export { useTabPanel } from './useTabPanel';
export * from './useTabPanel.types';