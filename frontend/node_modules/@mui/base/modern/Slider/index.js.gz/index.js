'use client';

export { Slider } from './Slider';
export * from './Slider.types';
export * from './sliderClasses';