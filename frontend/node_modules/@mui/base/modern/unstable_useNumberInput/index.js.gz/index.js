'use client';

export { useNumberInput as unstable_useNumberInput } from './useNumberInput';
export * from './useNumberInput.types';