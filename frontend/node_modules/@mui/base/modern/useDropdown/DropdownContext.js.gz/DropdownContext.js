import * as React from 'react';
const DropdownContext = /*#__PURE__*/React.createContext(null);
export { DropdownContext };