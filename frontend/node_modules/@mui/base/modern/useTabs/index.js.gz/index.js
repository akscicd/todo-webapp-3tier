'use client';

export * from './useTabs';
export * from './useTabs.types';
export * from './TabsProvider';