"use strict";
'use client';

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "MultiSelect", {
  enumerable: true,
  get: function () {
    return _MultiSelect.MultiSelect;
  }
});
var _MultiSelect = require("./MultiSelect");