"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SelectActionTypes = void 0;
const SelectActionTypes = exports.SelectActionTypes = {
  buttonClick: 'buttonClick',
  browserAutoFill: 'browserAutoFill'
};