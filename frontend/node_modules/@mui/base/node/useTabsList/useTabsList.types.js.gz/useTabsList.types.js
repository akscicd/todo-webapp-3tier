"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TabsListActionTypes = void 0;
const TabsListActionTypes = exports.TabsListActionTypes = {
  valueChange: 'valueChange'
};