export declare function clamp(val: number, min?: number, max?: number, stepProp?: number): number;
export declare function isNumber(val: unknown): val is number;
