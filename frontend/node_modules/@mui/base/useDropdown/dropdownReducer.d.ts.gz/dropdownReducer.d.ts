import { DropdownAction, DropdownState } from './useDropdown.types';
export declare function dropdownReducer(state: DropdownState, action: DropdownAction): DropdownState;
