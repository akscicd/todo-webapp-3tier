export const DropdownActionTypes = {
  blur: 'dropdown:blur',
  escapeKeyDown: 'dropdown:escapeKeyDown',
  toggle: 'dropdown:toggle',
  open: 'dropdown:open',
  close: 'dropdown:close'
};