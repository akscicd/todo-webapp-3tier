import { SelectOption } from '../useOption';
declare const defaultOptionStringifier: <OptionValue>(option: SelectOption<OptionValue>) => string;
export { defaultOptionStringifier };
