export const SelectActionTypes = {
  buttonClick: 'buttonClick',
  browserAutoFill: 'browserAutoFill'
};