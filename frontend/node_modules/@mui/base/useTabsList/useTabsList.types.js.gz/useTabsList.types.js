export const TabsListActionTypes = {
  valueChange: 'valueChange'
};