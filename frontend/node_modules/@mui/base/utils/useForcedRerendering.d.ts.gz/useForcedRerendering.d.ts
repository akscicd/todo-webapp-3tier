/**
 * @ignore - internal hook.
 */
export declare function useForcedRerendering(): () => void;
