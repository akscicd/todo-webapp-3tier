"use strict";
"use client";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _createSvgIcon = _interopRequireDefault(require("./utils/createSvgIcon"));
var _jsxRuntime = require("react/jsx-runtime");
var _default = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 4c3.87 0 7 3.13 7 7v1h-2c-.6 0-1.13.27-1.49.68L21 18.17V11c0-4.97-4.03-9-9-9-2.02 0-3.88.67-5.38 1.8l1.43 1.43C9.17 4.45 10.53 4 12 4zm9.19 17.19L2.81 2.81a.9959.9959 0 0 0-1.41 0C1 3.2 1 3.83 1.39 4.22l2.63 2.63C3.37 8.09 3 9.5 3 11v7c0 1.1.9 2 2 2h2c1.1 0 2-.9 2-2v-4c0-1.1-.9-2-2-2H5v-1c0-.94.19-1.83.52-2.65L15 17.83V18c0 1.1.9 2 2 2h.17l1 1H13c-.55 0-1 .45-1 1s.45 1 1 1h6c.36 0 .68-.1.97-.26.38.23.89.2 1.22-.13.39-.39.39-1.03 0-1.42z"
}), 'HeadsetOffRounded');
exports.default = _default;