"use strict";
"use client";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _createSvgIcon = _interopRequireDefault(require("./utils/createSvgIcon"));
var _jsxRuntime = require("react/jsx-runtime");
var _default = (0, _createSvgIcon.default)([/*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M17.59 18 19 16.59 14.42 12 19 7.41 17.59 6l-6 6z"
}, "0"), /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "m11 18 1.41-1.41L7.83 12l4.58-4.59L11 6l-6 6z"
}, "1")], 'KeyboardDoubleArrowLeftOutlined');
exports.default = _default;