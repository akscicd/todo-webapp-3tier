"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M19 1H5v22h14V1zm-2 18H7V5h10v14z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M8 6h8v2H8z"
}, "1")], 'AdUnitsSharp');