"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M4 22H2V2h2v20zM22 7H6v3h16V7zm-6 7H6v3h10v-3z"
}), 'AlignHorizontalLeft');