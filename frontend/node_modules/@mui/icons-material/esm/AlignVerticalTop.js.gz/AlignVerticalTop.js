"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M22 2v2H2V2h20zM7 22h3V6H7v16zm7-6h3V6h-3v10z"
}), 'AlignVerticalTop');