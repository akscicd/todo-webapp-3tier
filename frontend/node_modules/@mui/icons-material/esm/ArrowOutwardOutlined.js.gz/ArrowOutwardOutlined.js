"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M6 6v2h8.59L5 17.59 6.41 19 16 9.41V18h2V6z"
}), 'ArrowOutwardOutlined');