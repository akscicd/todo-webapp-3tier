"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M4 9h4v11H4zm12 4h4v7h-4zm-6-9h4v16h-4z"
}), 'BarChartSharp');