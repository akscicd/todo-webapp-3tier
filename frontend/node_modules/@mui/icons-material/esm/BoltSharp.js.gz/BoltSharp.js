"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M11 21h-1l1-7H6.74S10.42 7.54 13 3h1l-1 7h4.28L11 21z"
}), 'BoltSharp');