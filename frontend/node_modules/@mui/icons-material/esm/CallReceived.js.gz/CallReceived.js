"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M20 5.41 18.59 4 7 15.59V9H5v10h10v-2H8.41z"
}), 'CallReceived');