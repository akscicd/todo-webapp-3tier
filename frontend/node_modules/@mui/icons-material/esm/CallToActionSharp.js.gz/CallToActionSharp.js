"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M23 3H1v18h22V3zm-2 16H3v-3h18v3z"
}), 'CallToActionSharp');