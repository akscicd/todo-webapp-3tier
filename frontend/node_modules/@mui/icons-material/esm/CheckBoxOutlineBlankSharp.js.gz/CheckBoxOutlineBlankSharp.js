"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M19 5v14H5V5h14m2-2H3v18h18V3z"
}), 'CheckBoxOutlineBlankSharp');