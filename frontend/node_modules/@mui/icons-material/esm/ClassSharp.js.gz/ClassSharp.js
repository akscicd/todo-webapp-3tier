"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M20 2H4v20h16V2zM6 4h5v8l-2.5-1.5L6 12V4z"
}), 'ClassSharp');