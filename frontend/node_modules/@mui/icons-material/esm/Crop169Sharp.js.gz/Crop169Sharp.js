"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M21 7H3v10h18V7zm-2 8H5V9h14v6z"
}), 'Crop169Sharp');