"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M21 6H3v12h18V6zm-2 10H5V8h14v8z"
}), 'Crop32Sharp');