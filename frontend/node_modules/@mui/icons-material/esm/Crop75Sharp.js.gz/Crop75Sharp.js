"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M21 5H3v14h18V5zm-2 12H5V7h14v10z"
}), 'Crop75Sharp');