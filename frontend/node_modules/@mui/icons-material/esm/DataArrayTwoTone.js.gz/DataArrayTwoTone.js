"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M15 4v2h3v12h-3v2h5V4zM4 20h5v-2H6V6h3V4H4z"
}), 'DataArrayTwoTone');