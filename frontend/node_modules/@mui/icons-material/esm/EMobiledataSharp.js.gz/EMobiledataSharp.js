"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M16 9V7H8v10h8v-2h-6v-2h6v-2h-6V9h6z"
}), 'EMobiledataSharp');