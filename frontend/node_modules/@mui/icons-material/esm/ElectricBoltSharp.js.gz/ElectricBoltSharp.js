"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M15 2 2.5 13 13 14l-5 7 1 1 12.5-11L11 10l5-7z"
}), 'ElectricBoltSharp');