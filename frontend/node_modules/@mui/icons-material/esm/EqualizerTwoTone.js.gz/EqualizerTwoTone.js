"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M16 9h4v11h-4zm-6-5h4v16h-4zm-6 8h4v8H4z"
}), 'EqualizerTwoTone');