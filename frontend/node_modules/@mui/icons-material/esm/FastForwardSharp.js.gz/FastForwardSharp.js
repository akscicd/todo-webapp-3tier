"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "m4 18 8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"
}), 'FastForwardSharp');