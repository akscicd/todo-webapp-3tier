"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M5 10h4v6h6v-6h4l-7-7-7 7zm0 8v2h14v-2H5z"
}), 'FileUploadSharp');