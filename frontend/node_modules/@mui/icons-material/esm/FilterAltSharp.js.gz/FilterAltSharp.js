"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M3 4c2.01 2.59 7 9 7 9v7h4v-7s4.98-6.41 7-9H3z"
}), 'FilterAltSharp');