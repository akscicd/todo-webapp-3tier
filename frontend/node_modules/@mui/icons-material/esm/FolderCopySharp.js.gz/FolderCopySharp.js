"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M3 6H1v15h19v-2H3z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M23 4h-9l-2-2H5.01L5 17h18V4z"
}, "1")], 'FolderCopySharp');