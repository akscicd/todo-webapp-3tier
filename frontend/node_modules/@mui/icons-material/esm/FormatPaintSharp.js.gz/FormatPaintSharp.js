"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M18 4V2H4v6h14V6h1v4H9v12h4V12h8V4h-3z"
}), 'FormatPaintSharp');