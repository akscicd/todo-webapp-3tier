"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M18 17h-7l5-5-5-5h7V4H6v2l6.5 6L6 18v2h12z"
}), 'FunctionsTwoTone');