"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M12 11v2h2v2H9V9h7V7H7v10h9v-6h-4z"
}), 'GMobiledataSharp');