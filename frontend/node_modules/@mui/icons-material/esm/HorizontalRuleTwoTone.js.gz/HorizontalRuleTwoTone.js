"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  fillRule: "evenodd",
  d: "M4 11h16v2H4z"
}), 'HorizontalRuleTwoTone');