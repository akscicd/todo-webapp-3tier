"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M21 3H3v18h18V3zm-4 10H7v-2h10v2z"
}), 'IndeterminateCheckBoxSharp');