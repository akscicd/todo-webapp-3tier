"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "m5 12 1.41 1.41L12 7.83l5.59 5.58L19 12l-7-7z"
}), 'KeyboardControlKeyOutlined');