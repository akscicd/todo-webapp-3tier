"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M18 6.41 16.59 5 12 9.58 7.41 5 6 6.41l6 6z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "m18 13-1.41-1.41L12 16.17l-4.59-4.58L6 13l6 6z"
}, "1")], 'KeyboardDoubleArrowDown');