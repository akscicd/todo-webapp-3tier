"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M17.29 5.71a.9959.9959 0 0 0-1.41 0L12 9.58 8.11 5.7a.9959.9959 0 0 0-1.41 0c-.39.39-.39 1.02 0 1.41l4.59 4.59c.39.39 1.02.39 1.41 0l4.59-4.59c.39-.38.39-1.01 0-1.4z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M17.29 12.3a.9959.9959 0 0 0-1.41 0L12 16.17l-3.88-3.88a.9959.9959 0 0 0-1.41 0c-.39.39-.39 1.02 0 1.41l4.59 4.59c.39.39 1.02.39 1.41 0l4.59-4.59c.38-.38.38-1.01-.01-1.4z"
}, "1")], 'KeyboardDoubleArrowDownRounded');