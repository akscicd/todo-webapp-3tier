"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M15 5h6v2h-6zM9 5H3v2h4.85l6.92 12H21v-2h-5.07z"
}), 'KeyboardOptionKeySharp');