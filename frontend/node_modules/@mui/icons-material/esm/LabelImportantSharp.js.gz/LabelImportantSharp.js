"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M4 18.99h12.04L21 12l-4.97-7H4l5 7-5 6.99z"
}), 'LabelImportantSharp');