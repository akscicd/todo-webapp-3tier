"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M15.5 12v2.5h-7V12h-2v4.5h11V12z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M10 10v3h4v-3l2.25-.01V7.5h-8.5v2.49z"
}, "1"), /*#__PURE__*/_jsx("path", {
  d: "M22 2H2v20h20V2zm-3 7.99V18H5v-8l1.25-.01V6h11.5v3.99H19z"
}, "2")], 'LivingSharp');