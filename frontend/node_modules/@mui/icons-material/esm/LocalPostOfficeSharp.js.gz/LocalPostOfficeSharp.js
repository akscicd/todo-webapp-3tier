"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M22 4H2.01v16H22V4zm-2 4-8 5-8-5V6l8 5 8-5v2z"
}), 'LocalPostOfficeSharp');