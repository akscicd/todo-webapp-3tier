"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M5 5h7V3H3v18h9v-2H5z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "m21 12-4-4v3H9v2h8v3z"
}, "1")], 'LogoutSharp');