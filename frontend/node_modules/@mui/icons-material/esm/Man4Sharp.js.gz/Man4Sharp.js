"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M7.96 7 10 22h4l2.04-15z"
}, "0"), /*#__PURE__*/_jsx("circle", {
  cx: "12",
  cy: "4",
  r: "2"
}, "1")], 'Man4Sharp');