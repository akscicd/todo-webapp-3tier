"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M1 11v10h5v-6h4v6h5V11L8 6z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M10 3v1.97l7 5V11h2v2h-2v2h2v2h-2v4h6V3H10zm9 6h-2V7h2v2z"
}, "1")], 'MapsHomeWork');