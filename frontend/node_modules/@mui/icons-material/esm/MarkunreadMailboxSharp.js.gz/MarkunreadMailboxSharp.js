"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M22 6H10v6H8V4h6V0H6v6H2v16h20V6z"
}), 'MarkunreadMailboxSharp');