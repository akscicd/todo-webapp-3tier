"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M12 2 4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"
}), 'Navigation');