"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"
}), 'NorthEastTwoTone');