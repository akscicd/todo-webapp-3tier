"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M6 5h4v14H6zm8 0h4v14h-4z"
}), 'PauseTwoTone');