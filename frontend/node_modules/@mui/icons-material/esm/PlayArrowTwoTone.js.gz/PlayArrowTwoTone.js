"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M10 8.64v6.72L15.27 12z",
  opacity: ".3"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "m8 19 11-7L8 5v14zm2-10.36L15.27 12 10 15.36V8.64z"
}, "1")], 'PlayArrowTwoTone');