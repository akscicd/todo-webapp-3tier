"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M2.01 21 23 12 2.01 3 2 10l15 2-15 2 .01 7z"
}), 'SendSharp');