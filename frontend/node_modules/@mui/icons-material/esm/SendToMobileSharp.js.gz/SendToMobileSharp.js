"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M17 18H7V6h10v1h2V1H5v22h14v-6h-2z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "m22 12-4-4v3h-5v2h5v3z"
}, "1")], 'SendToMobileSharp');