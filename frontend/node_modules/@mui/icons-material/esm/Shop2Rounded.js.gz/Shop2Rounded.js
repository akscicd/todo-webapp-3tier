"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M2 9c-.55 0-1 .45-1 1v10c0 1.1.9 2 2 2h15c.55 0 1-.45 1-1s-.45-1-1-1H3V10c0-.55-.45-1-1-1z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M18 5V3c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H5v11c0 1.11.89 2 2 2h14c1.11 0 2-.89 2-2V5h-5zm-6-2h4v2h-4V3zm0 11.09V8.91c0-.39.44-.63.77-.42l4.07 2.59c.31.2.31.65 0 .84l-4.07 2.59c-.33.21-.77-.03-.77-.42z"
}, "1")], 'Shop2Rounded');