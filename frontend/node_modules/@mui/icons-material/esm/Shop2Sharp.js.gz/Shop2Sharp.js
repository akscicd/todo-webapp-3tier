"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M3 9H1v13h18v-2H3z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M18 5V1h-8v4H5v13h18V5h-5zm-6-2h4v2h-4V3zm0 12V8l5.5 3.5L12 15z"
}, "1")], 'Shop2Sharp');