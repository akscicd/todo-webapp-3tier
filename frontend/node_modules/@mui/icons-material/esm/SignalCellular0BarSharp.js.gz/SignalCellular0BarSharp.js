"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M2 22h20V2L2 22zm18-2H6.83L20 6.83V20z"
}), 'SignalCellular0BarSharp');