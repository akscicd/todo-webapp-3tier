"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M17 4h3v16h-3zM5 14h3v6H5zm6-5h3v11h-3z"
}), 'SignalCellularAlt');