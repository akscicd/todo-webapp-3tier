"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M20 6.83V20H6.83L20 6.83M22 2 2 22h20V2z"
}), 'SignalCellularNullTwoTone');