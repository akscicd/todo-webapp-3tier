"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M10 8v8l5-4-5-4zm11-5H3v18h18V3zm-2 16H5V5h14v14z"
}), 'SlideshowSharp');