"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M1 5v14h22V5H1zm17 12H6V7h12v10z"
}, "0"), /*#__PURE__*/_jsx("path", {
  d: "M12.5 11.25H14v1.5h-1.5zm2.5 0h1.5v1.5H15zm-5 0h1.5v1.5H10zm-2.5 0H9v1.5H7.5z"
}, "1")], 'SmartScreenSharp');