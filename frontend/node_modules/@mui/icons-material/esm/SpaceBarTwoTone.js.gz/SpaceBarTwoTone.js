"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M18 13H6V9H4v6h16V9h-2z"
}), 'SpaceBarTwoTone');