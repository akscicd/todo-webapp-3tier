"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M19 1.01 5.01 1v22H19V1.01zM17 19H7V5h10v14z"
}), 'StayCurrentPortraitSharp');