"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M1 19h22V5H1v14zM19 7v10H5V7h14z"
}), 'StayPrimaryLandscapeSharp');