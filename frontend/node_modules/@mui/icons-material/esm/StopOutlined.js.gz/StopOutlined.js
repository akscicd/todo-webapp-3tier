"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M16 8v8H8V8h8m2-2H6v12h12V6z"
}), 'StopOutlined');