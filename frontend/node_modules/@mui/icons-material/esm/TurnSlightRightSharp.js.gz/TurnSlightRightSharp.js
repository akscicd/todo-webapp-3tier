"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M12.34 6V4H18v5.66h-2V7.41l-5 5V20H9v-8.41L14.59 6z"
}), 'TurnSlightRightSharp');