"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M21 5h-3v14h3V5zm-4 0H7v14h10V5zM6 5H3v14h3V5z"
}), 'ViewArraySharp');