"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M2 4v7h20V4H2zm8 16h12v-7H10v7zm-8 0h6v-7H2v7z"
}), 'ViewComfy');