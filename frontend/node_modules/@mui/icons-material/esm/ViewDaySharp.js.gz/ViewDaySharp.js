"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M2 21h19v-3H2v3zM21 8H2v8h19V8zM2 3v3h19V3H2z"
}), 'ViewDaySharp');