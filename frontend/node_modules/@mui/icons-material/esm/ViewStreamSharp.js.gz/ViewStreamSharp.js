"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M3 19v-6h18v6H3zM3 5v6h18V5H3z"
}), 'ViewStreamSharp');