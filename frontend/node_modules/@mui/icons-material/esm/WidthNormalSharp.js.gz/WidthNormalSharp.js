"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M22 4H2v16h20V4zM4 6h4v12H4V6zm16 12h-4V6h4v12z"
}), 'WidthNormalSharp');