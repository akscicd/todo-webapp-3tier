"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M13.41 7h-2.82L7 16h3v6h4v-6h3z"
}, "0"), /*#__PURE__*/_jsx("circle", {
  cx: "12",
  cy: "4",
  r: "2"
}, "1")], 'WomanSharp');