"use client";

import createSvgIcon from './utils/createSvgIcon';
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon([/*#__PURE__*/_jsx("path", {
  d: "M13.94 8.31C13.62 7.52 12.85 7 12 7s-1.62.52-1.94 1.31L7 16h3v6h4v-6h3l-3.06-7.69z"
}, "0"), /*#__PURE__*/_jsx("circle", {
  cx: "12",
  cy: "4",
  r: "2"
}, "1")], 'WomanTwoTone');