'use client';

export { createSvgIcon as default } from '@mui/material/utils';