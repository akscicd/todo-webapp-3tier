export { default } from './AccordionDetails';
export * from './AccordionDetails';

export { default as accordionDetailsClasses } from './accordionDetailsClasses';
export * from './accordionDetailsClasses';
