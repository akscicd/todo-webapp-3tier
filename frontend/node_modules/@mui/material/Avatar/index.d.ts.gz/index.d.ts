export { default } from './Avatar';
export * from './Avatar';

export { default as avatarClasses } from './avatarClasses';
export * from './avatarClasses';
