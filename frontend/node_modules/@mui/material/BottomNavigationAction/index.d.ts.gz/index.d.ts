export { default } from './BottomNavigationAction';
export * from './BottomNavigationAction';

export { default as bottomNavigationActionClasses } from './bottomNavigationActionClasses';
export * from './bottomNavigationActionClasses';
