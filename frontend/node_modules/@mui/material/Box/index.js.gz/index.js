'use client';

export { default } from './Box';