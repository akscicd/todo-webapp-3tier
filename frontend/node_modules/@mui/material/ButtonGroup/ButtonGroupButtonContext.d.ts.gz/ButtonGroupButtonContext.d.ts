import * as React from 'react';
/**
 * @ignore - internal component.
 */
declare const ButtonGroupButtonContext: React.Context<string | undefined>;
export default ButtonGroupButtonContext;
