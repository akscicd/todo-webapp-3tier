import * as React from 'react';
/**
 * @ignore - internal component.
 */
const ButtonGroupButtonContext = /*#__PURE__*/React.createContext(undefined);
if (process.env.NODE_ENV !== 'production') {
  ButtonGroupButtonContext.displayName = 'ButtonGroupButtonContext';
}
export default ButtonGroupButtonContext;