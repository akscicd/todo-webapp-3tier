export { default } from './CardMedia';
export * from './CardMedia';

export { default as cardMediaClasses } from './cardMediaClasses';
export * from './cardMediaClasses';
