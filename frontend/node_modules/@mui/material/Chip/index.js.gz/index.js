'use client';

export { default } from './Chip';
export { default as chipClasses } from './chipClasses';
export * from './chipClasses';