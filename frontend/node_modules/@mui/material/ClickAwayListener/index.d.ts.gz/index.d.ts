export { ClickAwayListener as default, type ClickAwayListenerProps, } from '@mui/base/ClickAwayListener';
