import { ContainerClasses } from '@mui/system';
export type { ContainerClassKey } from '@mui/system';
export type { ContainerClasses };
export declare function getContainerUtilityClass(slot: string): string;
declare const containerClasses: ContainerClasses;
export default containerClasses;
