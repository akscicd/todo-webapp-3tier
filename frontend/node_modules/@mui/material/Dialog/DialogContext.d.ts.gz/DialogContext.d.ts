import * as React from 'react';
interface DialogContextValue {
    titleId?: string;
}
declare const DialogContext: React.Context<DialogContextValue>;
export default DialogContext;
