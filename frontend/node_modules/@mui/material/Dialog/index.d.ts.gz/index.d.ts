export { default } from './Dialog';
export * from './Dialog';

export { default as dialogClasses } from './dialogClasses';
export * from './dialogClasses';
