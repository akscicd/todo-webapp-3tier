export { default } from './DialogActions';
export * from './DialogActions';

export { default as dialogActionsClasses } from './dialogActionsClasses';
export * from './dialogActionsClasses';
