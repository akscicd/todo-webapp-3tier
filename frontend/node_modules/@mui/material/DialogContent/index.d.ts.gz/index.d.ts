export { default } from './DialogContent';
export * from './DialogContent';

export { default as dialogContentClasses } from './dialogContentClasses';
export * from './dialogContentClasses';
