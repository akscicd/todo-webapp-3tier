export { default } from './DialogContentText';
export * from './DialogContentText';

export { default as dialogContentTextClasses } from './dialogContentTextClasses';
export * from './dialogContentTextClasses';
