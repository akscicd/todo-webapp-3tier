export { default } from './DialogTitle';
export * from './DialogTitle';

export { default as dialogTitleClasses } from './dialogTitleClasses';
export * from './dialogTitleClasses';
