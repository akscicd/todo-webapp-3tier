'use client';

export { default } from './DialogTitle';
export { default as dialogTitleClasses } from './dialogTitleClasses';
export * from './dialogTitleClasses';