export { default } from './Divider';
export * from './Divider';

export { default as dividerClasses } from './dividerClasses';
export * from './dividerClasses';
