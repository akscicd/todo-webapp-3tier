import { FormControlState } from './FormControlContext';
export default function useFormControl(): FormControlState | undefined;
