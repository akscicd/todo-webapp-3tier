export { default } from './FormControlLabel';
export * from './FormControlLabel';

export { default as formControlLabelClasses } from './formControlLabelClasses';
export * from './formControlLabelClasses';
