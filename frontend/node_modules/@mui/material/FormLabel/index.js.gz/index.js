'use client';

export { default } from './FormLabel';
export * from './FormLabel';
export { default as formLabelClasses } from './formLabelClasses';
export * from './formLabelClasses';