export * from './InputAdornment';
export { default } from './InputAdornment';

export { default as inputAdornmentClasses } from './inputAdornmentClasses';
export * from './inputAdornmentClasses';
