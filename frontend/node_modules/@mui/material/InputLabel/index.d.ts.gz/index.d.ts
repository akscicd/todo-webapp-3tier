export { default } from './InputLabel';
export * from './InputLabel';

export { default as inputLabelClasses } from './inputLabelClasses';
export * from './inputLabelClasses';
