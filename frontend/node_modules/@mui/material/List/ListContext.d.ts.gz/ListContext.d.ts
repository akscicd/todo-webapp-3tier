import * as React from 'react';

declare const ListContext: React.Context<{ dense?: boolean }>;
export default ListContext;
