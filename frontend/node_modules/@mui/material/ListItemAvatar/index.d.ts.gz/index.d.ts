export { default } from './ListItemAvatar';
export * from './ListItemAvatar';

export { default as listItemAvatarClasses } from './listItemAvatarClasses';
export * from './listItemAvatarClasses';
