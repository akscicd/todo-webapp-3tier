export { default } from './ListItemIcon';
export * from './ListItemIcon';

export { default as listItemIconClasses } from './listItemIconClasses';
export * from './listItemIconClasses';
