'use client';

export { default } from './ListItemText';
export { default as listItemTextClasses } from './listItemTextClasses';
export * from './listItemTextClasses';