export { ModalManager } from '@mui/base/unstable_useModal'; // exporting ModalManager

export { default } from './Modal';
export * from './Modal';

export { default as modalClasses } from './modalClasses';
export * from './modalClasses';
