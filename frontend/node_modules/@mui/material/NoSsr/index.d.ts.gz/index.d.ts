export { NoSsr as default } from '@mui/base/NoSsr';
export * from '@mui/base/NoSsr';
