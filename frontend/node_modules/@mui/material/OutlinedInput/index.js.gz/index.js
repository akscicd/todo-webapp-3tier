'use client';

export { default } from './OutlinedInput';
export { default as outlinedInputClasses } from './outlinedInputClasses';
export * from './outlinedInputClasses';