export { default } from './Pagination';
export * from './Pagination';

export { default as paginationClasses } from './paginationClasses';
export * from './paginationClasses';
