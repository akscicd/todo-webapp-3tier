export { Portal as default } from '@mui/base/Portal';
export * from '@mui/base/Portal';
