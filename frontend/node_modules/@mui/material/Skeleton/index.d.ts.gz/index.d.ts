export * from './Skeleton';
export { default } from './Skeleton';

export * from './skeletonClasses';
export { default as skeletonClasses } from './skeletonClasses';
