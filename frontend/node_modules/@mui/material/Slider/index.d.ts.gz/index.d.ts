export { default } from './Slider';
export * from './Slider';

export { default as sliderClasses } from './sliderClasses';
export * from './sliderClasses';
