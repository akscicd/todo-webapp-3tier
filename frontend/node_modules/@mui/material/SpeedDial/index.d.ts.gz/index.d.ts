export { default } from './SpeedDial';
export * from './SpeedDial';

export { default as speedDialClasses } from './speedDialClasses';
export * from './speedDialClasses';
