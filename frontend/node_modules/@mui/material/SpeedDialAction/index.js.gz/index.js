'use client';

export { default } from './SpeedDialAction';
export { default as speedDialActionClasses } from './speedDialActionClasses';
export * from './speedDialActionClasses';