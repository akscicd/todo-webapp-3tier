export { default } from './SpeedDialIcon';
export * from './SpeedDialIcon';

export { default as speedDialIconClasses } from './speedDialIconClasses';
export * from './speedDialIconClasses';
