import { StackClasses } from '@mui/system';
export type { StackClassKey } from '@mui/system';
export type { StackClasses };
export declare function getStackUtilityClass(slot: string): string;
declare const stackClasses: StackClasses;
export default stackClasses;
