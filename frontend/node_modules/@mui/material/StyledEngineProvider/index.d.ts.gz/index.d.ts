/**
 * @deprecated will be removed in v5.beta, please use StyledEngineProvider from @mui/material/styles instead
 */
export { StyledEngineProvider as default } from '@mui/system';
