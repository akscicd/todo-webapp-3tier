export { default } from './Tab';
export * from './Tab';

export { default as tabClasses } from './tabClasses';
export * from './tabClasses';
