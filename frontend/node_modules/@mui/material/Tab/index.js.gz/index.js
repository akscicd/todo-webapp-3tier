'use client';

export { default } from './Tab';
export { default as tabClasses } from './tabClasses';
export * from './tabClasses';