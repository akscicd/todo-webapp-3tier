export { default } from './TabScrollButton';
export * from './TabScrollButton';

export { default as tabScrollButtonClasses } from './tabScrollButtonClasses';
export * from './tabScrollButtonClasses';
