'use client';

export { default } from './TabScrollButton';
export { default as tabScrollButtonClasses } from './tabScrollButtonClasses';
export * from './tabScrollButtonClasses';