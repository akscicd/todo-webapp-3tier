'use client';

export { default } from './Table';
export { default as tableClasses } from './tableClasses';
export * from './tableClasses';