export { default } from './TableBody';
export * from './TableBody';

export { default as tableBodyClasses } from './tableBodyClasses';
export * from './tableBodyClasses';
