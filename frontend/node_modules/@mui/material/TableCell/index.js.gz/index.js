'use client';

export { default } from './TableCell';
export { default as tableCellClasses } from './tableCellClasses';
export * from './tableCellClasses';