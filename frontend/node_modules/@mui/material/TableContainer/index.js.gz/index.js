'use client';

export { default } from './TableContainer';
export { default as tableContainerClasses } from './tableContainerClasses';
export * from './tableContainerClasses';