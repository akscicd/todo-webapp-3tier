export { default } from './TableFooter';
export * from './TableFooter';

export { default as tableFooterClasses } from './tableFooterClasses';
export * from './tableFooterClasses';
