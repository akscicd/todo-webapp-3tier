'use client';

export { default } from './TableFooter';
export { default as tableFooterClasses } from './tableFooterClasses';
export * from './tableFooterClasses';