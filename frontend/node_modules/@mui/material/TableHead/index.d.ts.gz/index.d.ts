export { default } from './TableHead';
export * from './TableHead';

export { default as tableHeadClasses } from './tableHeadClasses';
export * from './tableHeadClasses';
