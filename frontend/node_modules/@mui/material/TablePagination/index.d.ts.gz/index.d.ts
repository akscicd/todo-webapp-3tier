export { default } from './TablePagination';
export * from './TablePagination';

export { default as tablePaginationClasses } from './tablePaginationClasses';
export * from './tablePaginationClasses';
