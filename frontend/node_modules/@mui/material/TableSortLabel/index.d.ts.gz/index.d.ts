export { default } from './TableSortLabel';
export * from './TableSortLabel';

export { default as tableSortLabelClasses } from './tableSortLabelClasses';
export * from './tableSortLabelClasses';
