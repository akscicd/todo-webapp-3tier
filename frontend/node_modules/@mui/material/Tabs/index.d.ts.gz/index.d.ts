export { default } from './Tabs';
export * from './Tabs';

export { default as tabsClasses } from './tabsClasses';
export * from './tabsClasses';
