export { TextareaAutosize as default } from '@mui/base/TextareaAutosize';
export * from '@mui/base/TextareaAutosize';
