export { default } from './Tooltip';
export * from './Tooltip';

export { default as tooltipClasses } from './tooltipClasses';
export * from './tooltipClasses';
