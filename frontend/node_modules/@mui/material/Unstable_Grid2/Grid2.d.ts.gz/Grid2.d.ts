import { OverridableComponent } from '@mui/types';
import { Grid2TypeMap } from './Grid2Props';
declare const Grid2: OverridableComponent<Grid2TypeMap<{}, "div">>;
export default Grid2;
