export { FocusTrap as default } from '@mui/base/FocusTrap';
export { FocusTrapProps as TrapFocusProps } from '@mui/base/FocusTrap';
