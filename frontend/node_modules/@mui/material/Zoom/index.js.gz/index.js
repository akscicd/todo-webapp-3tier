'use client';

export { default } from './Zoom';