/* tslint:disable max-line-length */
/**
 * ![common black](https://mui.com/static/colors-preview/common-black-24x24.png) ![common white](https://mui.com/static/colors-preview/common-white-24x24.png)
 */
declare const common: {
  /**
   * Preview: ![common black](https://mui.com/static/colors-preview/common-black-24x24.png)
   */
  black: '#000';
  /**
   * Preview: ![common white](https://mui.com/static/colors-preview/common-white-24x24.png)
   */
  white: '#fff';
};

export default common;
