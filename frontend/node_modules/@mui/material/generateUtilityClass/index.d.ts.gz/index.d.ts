export { unstable_generateUtilityClass as default } from '@mui/utils';
export type { GlobalStateSlot } from '@mui/utils';
