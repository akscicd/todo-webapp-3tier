export { unstable_generateUtilityClasses as default } from '@mui/utils';
