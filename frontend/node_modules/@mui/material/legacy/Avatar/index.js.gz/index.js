'use client';

export { default } from './Avatar';
export { default as avatarClasses } from './avatarClasses';
export * from './avatarClasses';