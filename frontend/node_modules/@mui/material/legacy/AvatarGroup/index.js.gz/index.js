'use client';

export { default } from './AvatarGroup';
export { default as avatarGroupClasses } from './avatarGroupClasses';
export * from './avatarGroupClasses';