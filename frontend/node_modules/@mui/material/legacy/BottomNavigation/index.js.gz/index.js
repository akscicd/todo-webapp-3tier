'use client';

export { default } from './BottomNavigation';
export { default as bottomNavigationClasses } from './bottomNavigationClasses';
export * from './bottomNavigationClasses';