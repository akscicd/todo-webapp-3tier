'use client';

export { default } from './CardActionArea';
export { default as cardActionAreaClasses } from './cardActionAreaClasses';
export * from './cardActionAreaClasses';