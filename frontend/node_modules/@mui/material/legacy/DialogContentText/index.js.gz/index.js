'use client';

export { default } from './DialogContentText';
export { default as dialogContentTextClasses } from './dialogContentTextClasses';
export * from './dialogContentTextClasses';