'use client';

export { default } from './Fade';