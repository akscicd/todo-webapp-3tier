'use client';

export { default } from './FormControlLabel';
export { default as formControlLabelClasses } from './formControlLabelClasses';
export * from './formControlLabelClasses';