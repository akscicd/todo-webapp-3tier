'use client';

export { default } from './Icon';
export { default as iconClasses } from './iconClasses';
export * from './iconClasses';