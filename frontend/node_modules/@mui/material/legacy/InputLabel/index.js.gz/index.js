'use client';

export { default } from './InputLabel';
export { default as inputLabelClasses } from './inputLabelClasses';
export * from './inputLabelClasses';