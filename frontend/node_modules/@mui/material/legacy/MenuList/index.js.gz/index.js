'use client';

export { default } from './MenuList';