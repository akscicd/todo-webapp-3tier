'use client';

export { default } from './Pagination';
export { default as paginationClasses } from './paginationClasses';
export * from './paginationClasses';