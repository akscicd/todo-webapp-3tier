'use client';

export { default } from './PaginationItem';
export { default as paginationItemClasses } from './paginationItemClasses';
export * from './paginationItemClasses';