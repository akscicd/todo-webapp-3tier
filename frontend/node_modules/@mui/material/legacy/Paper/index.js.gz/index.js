'use client';

export { default } from './Paper';
export { default as paperClasses } from './paperClasses';
export * from './paperClasses';