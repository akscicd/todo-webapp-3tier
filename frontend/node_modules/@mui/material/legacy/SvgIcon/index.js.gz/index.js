'use client';

export { default } from './SvgIcon';
export { default as svgIconClasses } from './svgIconClasses';
export * from './svgIconClasses';