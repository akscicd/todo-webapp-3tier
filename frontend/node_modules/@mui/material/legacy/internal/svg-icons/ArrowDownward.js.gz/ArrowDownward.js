'use client';

import * as React from 'react';
import createSvgIcon from '../../utils/createSvgIcon';

/**
 * @ignore - internal component.
 */
import { jsx as _jsx } from "react/jsx-runtime";
export default createSvgIcon( /*#__PURE__*/_jsx("path", {
  d: "M20 12l-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8 8-8z"
}), 'ArrowDownward');