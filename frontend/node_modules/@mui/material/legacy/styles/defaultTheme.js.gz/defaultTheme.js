'use client';

import createTheme from './createTheme';
var defaultTheme = createTheme();
export default defaultTheme;