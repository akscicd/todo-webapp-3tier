'use client';

export { default } from './useMediaQuery';