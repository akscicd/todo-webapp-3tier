'use client';

export { default } from './usePagination';