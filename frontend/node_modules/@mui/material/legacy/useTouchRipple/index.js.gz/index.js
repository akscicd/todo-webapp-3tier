'use client';

export { default } from './useTouchRipple';