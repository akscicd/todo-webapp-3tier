import { unstable_debounce as debounce } from '@mui/utils';
export default debounce;