import { unstable_deprecatedPropType as deprecatedPropType } from '@mui/utils';
export default deprecatedPropType;