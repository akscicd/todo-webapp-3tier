import { unstable_requirePropFactory as requirePropFactory } from '@mui/utils';
export default requirePropFactory;