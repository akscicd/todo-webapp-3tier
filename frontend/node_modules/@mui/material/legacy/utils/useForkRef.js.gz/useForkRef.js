'use client';

import { unstable_useForkRef as useForkRef } from '@mui/utils';
export default useForkRef;