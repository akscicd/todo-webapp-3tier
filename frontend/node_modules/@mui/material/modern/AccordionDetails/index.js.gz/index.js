'use client';

export { default } from './AccordionDetails';
export { default as accordionDetailsClasses } from './accordionDetailsClasses';
export * from './accordionDetailsClasses';