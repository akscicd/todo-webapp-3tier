'use client';

export { default } from './AlertTitle';
export { default as alertTitleClasses } from './alertTitleClasses';
export * from './alertTitleClasses';