'use client';

export { default } from './BottomNavigationAction';
export { default as bottomNavigationActionClasses } from './bottomNavigationActionClasses';
export * from './bottomNavigationActionClasses';