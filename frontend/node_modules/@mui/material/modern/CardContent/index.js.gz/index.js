'use client';

export { default } from './CardContent';
export { default as cardContentClasses } from './cardContentClasses';
export * from './cardContentClasses';