'use client';

export { default } from './CardMedia';
export { default as cardMediaClasses } from './cardMediaClasses';
export * from './cardMediaClasses';