'use client';

export { default } from './Dialog';
export { default as dialogClasses } from './dialogClasses';
export * from './dialogClasses';