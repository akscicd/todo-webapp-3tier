'use client';

export { default } from './Fab';
export { default as fabClasses } from './fabClasses';
export * from './fabClasses';