'use client';

export { default } from './Link';
export { default as linkClasses } from './linkClasses';
export * from './linkClasses';