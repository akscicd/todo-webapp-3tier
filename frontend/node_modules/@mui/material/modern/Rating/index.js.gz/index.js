'use client';

export { default } from './Rating';
export { default as ratingClasses } from './ratingClasses';
export * from './ratingClasses';