'use client';

export { default } from './Slide';