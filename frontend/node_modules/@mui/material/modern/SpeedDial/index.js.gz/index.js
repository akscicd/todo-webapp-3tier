'use client';

export { default } from './SpeedDial';
export { default as speedDialClasses } from './speedDialClasses';
export * from './speedDialClasses';