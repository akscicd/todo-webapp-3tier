'use client';

export { default } from './SpeedDialIcon';
export { default as speedDialIconClasses } from './speedDialIconClasses';
export * from './speedDialIconClasses';