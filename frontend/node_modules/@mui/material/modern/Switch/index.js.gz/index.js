'use client';

export { default } from './Switch';
export { default as switchClasses } from './switchClasses';
export * from './switchClasses';