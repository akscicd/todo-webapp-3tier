'use client';

export { default } from './TableBody';
export { default as tableBodyClasses } from './tableBodyClasses';
export * from './tableBodyClasses';