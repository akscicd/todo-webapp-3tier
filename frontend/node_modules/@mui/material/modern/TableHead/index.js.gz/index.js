'use client';

export { default } from './TableHead';
export { default as tableHeadClasses } from './tableHeadClasses';
export * from './tableHeadClasses';