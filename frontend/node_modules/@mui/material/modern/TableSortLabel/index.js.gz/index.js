'use client';

export { default } from './TableSortLabel';
export { default as tableSortLabelClasses } from './tableSortLabelClasses';
export * from './tableSortLabelClasses';