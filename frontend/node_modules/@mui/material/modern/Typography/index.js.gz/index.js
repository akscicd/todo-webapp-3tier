'use client';

export { default } from './Typography';
export { default as typographyClasses } from './typographyClasses';
export * from './typographyClasses';