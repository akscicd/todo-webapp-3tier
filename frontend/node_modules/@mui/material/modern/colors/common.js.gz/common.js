const common = {
  black: '#000',
  white: '#fff'
};
export default common;