'use client';

import createTheme from './createTheme';
const defaultTheme = createTheme();
export default defaultTheme;