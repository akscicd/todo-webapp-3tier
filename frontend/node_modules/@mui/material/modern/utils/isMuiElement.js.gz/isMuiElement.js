import { unstable_isMuiElement as isMuiElement } from '@mui/utils';
export default isMuiElement;