"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _Portal.Portal;
  }
});
var _Portal = require("@mui/base/Portal");