"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
exports.getRadioUtilityClass = getRadioUtilityClass;
var _utils = require("@mui/utils");
var _generateUtilityClass = _interopRequireDefault(require("../generateUtilityClass"));
function getRadioUtilityClass(slot) {
  return (0, _generateUtilityClass.default)('MuiRadio', slot);
}
const radioClasses = (0, _utils.unstable_generateUtilityClasses)('MuiRadio', ['root', 'checked', 'disabled', 'colorPrimary', 'colorSecondary', 'sizeSmall']);
var _default = exports.default = radioClasses;