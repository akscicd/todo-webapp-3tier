"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _system.StyledEngineProvider;
  }
});
var _system = require("@mui/system");