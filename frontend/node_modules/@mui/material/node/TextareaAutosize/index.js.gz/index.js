"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _TextareaAutosize.TextareaAutosize;
  }
});
var _TextareaAutosize = require("@mui/base/TextareaAutosize");