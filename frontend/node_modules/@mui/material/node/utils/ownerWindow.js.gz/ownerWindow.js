"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _utils = require("@mui/utils");
var _default = exports.default = _utils.unstable_ownerWindow;