export default function createStyles(styles: any): never;
