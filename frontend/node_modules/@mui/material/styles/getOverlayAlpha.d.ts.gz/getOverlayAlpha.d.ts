declare const getOverlayAlpha: (elevation: number) => string;
export default getOverlayAlpha;
