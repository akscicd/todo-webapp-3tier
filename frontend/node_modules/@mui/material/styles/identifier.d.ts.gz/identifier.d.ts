declare const _default: "$$material";
export default _default;
