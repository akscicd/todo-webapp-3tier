export default function makeStyles(stylesCreator: any, options?: object): never;
