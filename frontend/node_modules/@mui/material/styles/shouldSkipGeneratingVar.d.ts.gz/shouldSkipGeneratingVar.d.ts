export default function shouldSkipGeneratingVar(keys: string[]): boolean;
