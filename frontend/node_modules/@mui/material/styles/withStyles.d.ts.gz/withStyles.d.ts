export default function withStyles(stylesCreator: any, options?: object): never;
