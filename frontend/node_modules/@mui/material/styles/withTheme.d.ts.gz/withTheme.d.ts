export default function withTheme(Component: any): never;
