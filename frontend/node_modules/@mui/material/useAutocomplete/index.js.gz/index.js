'use client';

export { default, createFilterOptions } from './useAutocomplete';