'use client';

export { useAutocomplete as default } from '@mui/base/useAutocomplete';
export * from '@mui/base/useAutocomplete';