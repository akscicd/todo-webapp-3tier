export { default } from './useMediaQuery';
export * from './useMediaQuery';
