import useMediaQuery from './useMediaQuery';

export default useMediaQuery;
