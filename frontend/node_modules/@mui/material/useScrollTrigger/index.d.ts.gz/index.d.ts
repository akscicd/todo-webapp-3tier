export { default } from './useScrollTrigger';
