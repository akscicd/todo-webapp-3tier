'use client';

export { default } from './useScrollTrigger';