import { unstable_capitalize as capitalize } from '@mui/utils';

export default capitalize;
