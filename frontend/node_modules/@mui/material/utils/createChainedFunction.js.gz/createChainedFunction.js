import { unstable_createChainedFunction as createChainedFunction } from '@mui/utils';
export default createChainedFunction;