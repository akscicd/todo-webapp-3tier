import SvgIcon from '@mui/material/SvgIcon';

export default function createSvgIcon(path: React.ReactNode, displayName: string): typeof SvgIcon;
