import { unstable_getScrollbarSize as getScrollbarSize } from '@mui/utils';
export default getScrollbarSize;