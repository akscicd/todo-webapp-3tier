import { unstable_ownerDocument as ownerDocument } from '@mui/utils';
export default ownerDocument;
