import { unstable_ownerWindow as ownerWindow } from '@mui/utils';
export default ownerWindow;