import { unstable_unsupportedProp as unsupportedProp } from '@mui/utils';

export default unsupportedProp;
