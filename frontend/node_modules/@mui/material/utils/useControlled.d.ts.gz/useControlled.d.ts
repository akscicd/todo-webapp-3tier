import { unstable_useControlled as useControlled } from '@mui/utils';

export default useControlled;
