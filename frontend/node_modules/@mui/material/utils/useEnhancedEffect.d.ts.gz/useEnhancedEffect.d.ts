import { unstable_useEnhancedEffect as useEnhancedEffect } from '@mui/utils';

export default useEnhancedEffect;
