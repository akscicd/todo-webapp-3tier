import { unstable_useEventCallback as useEventCallback } from '@mui/utils';

export default useEventCallback;
