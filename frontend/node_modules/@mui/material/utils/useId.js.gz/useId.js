'use client';

import { unstable_useId as useId } from '@mui/utils';
export default useId;