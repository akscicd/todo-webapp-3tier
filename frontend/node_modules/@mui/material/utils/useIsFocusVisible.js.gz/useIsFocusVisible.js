'use client';

import { unstable_useIsFocusVisible as useIsFocusVisible } from '@mui/utils';
export default useIsFocusVisible;