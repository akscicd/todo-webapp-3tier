# @mui/private-theming

The React theme context to be shared between `@mui/styles` and `@mui/material`.
