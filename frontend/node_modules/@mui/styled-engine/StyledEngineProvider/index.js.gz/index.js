'use client';

export { default } from './StyledEngineProvider';