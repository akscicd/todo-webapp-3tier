export { default } from './GlobalStyles';
export * from './GlobalStyles';
