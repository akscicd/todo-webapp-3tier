'use client';

export { default } from './GlobalStyles';
export * from './GlobalStyles';