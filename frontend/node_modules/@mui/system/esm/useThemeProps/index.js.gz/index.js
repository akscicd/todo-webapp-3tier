'use client';

export { default } from './useThemeProps';
export { default as getThemeProps } from './getThemeProps';