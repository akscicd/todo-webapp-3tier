'use client';

export { default } from './ThemeProvider';