var shape = {
  borderRadius: 4
};
export default shape;