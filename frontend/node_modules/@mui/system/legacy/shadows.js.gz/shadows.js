import style from './style';
var boxShadow = style({
  prop: 'boxShadow',
  themeKey: 'shadows'
});
export default boxShadow;