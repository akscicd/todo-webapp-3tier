import createStyled from './createStyled';
var styled = createStyled();
export default styled;