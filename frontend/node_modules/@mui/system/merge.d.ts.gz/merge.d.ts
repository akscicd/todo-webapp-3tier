export default function merge(acc: object, item: object): object;
