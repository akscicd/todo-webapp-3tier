import createStyled from './createStyled';
const styled = createStyled();
export default styled;