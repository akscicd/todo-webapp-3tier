export default function propsToClassKey(props: object): string;
