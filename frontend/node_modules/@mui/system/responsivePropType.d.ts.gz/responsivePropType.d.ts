declare const responsivePropType: object;

export default responsivePropType;
