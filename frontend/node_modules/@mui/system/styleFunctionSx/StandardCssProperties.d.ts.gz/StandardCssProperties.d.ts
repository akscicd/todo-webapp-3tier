import * as CSS from 'csstype';

export type StandardCSSProperties = CSS.PropertiesFallback<number | string>;
