import { CreateMUIStyled } from './createStyled';

declare const styled: CreateMUIStyled;

export default styled;
