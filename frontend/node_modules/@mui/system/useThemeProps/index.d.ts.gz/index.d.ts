export { default } from './useThemeProps';
export * from './useThemeProps';

export { default as getThemeProps } from './getThemeProps';
