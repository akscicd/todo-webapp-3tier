export default function useThemeWithoutDefault<T = null>(defaultTheme?: T): T;
