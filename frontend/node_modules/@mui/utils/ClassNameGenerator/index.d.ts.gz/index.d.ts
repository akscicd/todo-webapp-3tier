export { default } from './ClassNameGenerator';
