export { default } from './HTMLElementType';
