import { ValidationMap } from 'prop-types';
export default function exactProp<T>(propTypes: ValidationMap<T>): ValidationMap<T>;
