export { default } from './exactProp';
