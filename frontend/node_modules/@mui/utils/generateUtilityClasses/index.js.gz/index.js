"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _generateUtilityClasses.default;
  }
});
var _generateUtilityClasses = _interopRequireDefault(require("./generateUtilityClasses"));