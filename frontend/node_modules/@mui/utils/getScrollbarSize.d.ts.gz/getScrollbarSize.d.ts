export default function getScrollbarSize(doc: Document): number;
