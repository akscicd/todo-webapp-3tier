import PropTypes from 'prop-types';

declare const integerPropType: PropTypes.Requireable<number>;

export default integerPropType;
