export default function isMuiElement(element: any, muiNames: readonly string[]): boolean;
