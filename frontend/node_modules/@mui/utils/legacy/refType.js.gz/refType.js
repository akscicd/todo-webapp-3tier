import PropTypes from 'prop-types';
var refType = PropTypes.oneOfType([PropTypes.func, PropTypes.object]);
export default refType;