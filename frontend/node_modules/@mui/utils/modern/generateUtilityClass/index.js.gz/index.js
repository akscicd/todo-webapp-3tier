export { default } from './generateUtilityClass';
export * from './generateUtilityClass';