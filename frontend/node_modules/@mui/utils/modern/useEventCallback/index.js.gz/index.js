'use client';

export { default } from './useEventCallback';