'use client';

export { default } from './useForkRef';