export { default } from './ponyfillGlobal';
