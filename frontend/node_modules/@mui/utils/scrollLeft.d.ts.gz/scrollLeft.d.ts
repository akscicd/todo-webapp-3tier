export function detectScrollType(): string;
export function getNormalizedScrollLeft(element: HTMLElement, direction: string): number;
