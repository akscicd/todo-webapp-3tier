export { default } from './useEventCallback';
