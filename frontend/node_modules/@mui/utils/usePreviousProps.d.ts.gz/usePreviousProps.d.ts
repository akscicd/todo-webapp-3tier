declare const usePreviousProps: <T>(value: T) => Partial<T>;
export default usePreviousProps;
