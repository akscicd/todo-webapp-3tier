"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fs = void 0;
const fs = require("./fs");
exports.fs = fs;
