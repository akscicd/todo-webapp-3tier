export default function getHTMLElementScroll(element: HTMLElement): {
    scrollLeft: number;
    scrollTop: number;
};
