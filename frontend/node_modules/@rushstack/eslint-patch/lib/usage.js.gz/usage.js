"use strict";
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
Object.defineProperty(exports, "__esModule", { value: true });
throw new Error('The @rushstack/eslint-patch package does not have a default entry point.' +
    ' See README.md for usage instructions.');
//# sourceMappingURL=usage.js.map