declare function blur(element: Element): void;
export { blur };
