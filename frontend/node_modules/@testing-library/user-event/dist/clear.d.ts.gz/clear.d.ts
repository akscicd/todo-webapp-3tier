declare function clear(element: Element): void;
export { clear };
