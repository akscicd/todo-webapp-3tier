declare module '@testing-library/dom/dist/helpers' {
  export function getWindowFromNode(node: Node): Window
}
