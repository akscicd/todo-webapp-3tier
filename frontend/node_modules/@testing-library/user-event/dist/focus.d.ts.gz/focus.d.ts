declare function focus(element: Element): void;
export { focus };
