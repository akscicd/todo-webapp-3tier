/**
 * This file should cover the behavior for keys that produce character input
 */
import { behaviorPlugin } from '../types';
export declare const keypressBehavior: behaviorPlugin[];
