export declare function fireChangeForInputTimeIfValid(el: HTMLInputElement & {
    type: 'time';
}, prevValue: unknown, timeNewEntry: string): void;
