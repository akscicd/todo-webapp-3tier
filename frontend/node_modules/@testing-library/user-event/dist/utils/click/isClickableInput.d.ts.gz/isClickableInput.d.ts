export declare function isClickableInput(element: Element): boolean;
