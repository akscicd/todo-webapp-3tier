export declare function buildTimeValue(value: string): string;
