export declare function isCursorAtEnd(element: Element): boolean;
export declare function isCursorAtStart(element: Element): boolean;
