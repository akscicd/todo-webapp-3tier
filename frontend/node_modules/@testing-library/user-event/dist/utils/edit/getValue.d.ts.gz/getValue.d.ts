export declare function getValue(element: Element | null): string | null;
