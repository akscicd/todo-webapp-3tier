export declare function isValidDateValue(element: HTMLInputElement & {
    type: 'date';
}, value: string): boolean;
