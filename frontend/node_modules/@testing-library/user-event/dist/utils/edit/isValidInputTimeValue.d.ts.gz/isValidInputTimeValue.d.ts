export declare function isValidInputTimeValue(element: HTMLInputElement & {
    type: 'time';
}, timeValue: string): boolean;
