export declare function getSpaceUntilMaxLength(element: Element): number | undefined;
