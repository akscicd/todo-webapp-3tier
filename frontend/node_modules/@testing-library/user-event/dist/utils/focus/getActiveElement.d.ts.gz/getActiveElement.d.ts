export declare function getActiveElement(document: Document | ShadowRoot): Element | null;
