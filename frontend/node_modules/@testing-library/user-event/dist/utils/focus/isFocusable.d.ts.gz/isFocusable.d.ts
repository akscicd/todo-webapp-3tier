export declare function isFocusable(element: Element): element is HTMLElement;
