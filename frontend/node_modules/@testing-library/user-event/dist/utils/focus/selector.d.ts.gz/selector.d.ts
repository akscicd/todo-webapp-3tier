export declare const FOCUSABLE_SELECTOR: string;
