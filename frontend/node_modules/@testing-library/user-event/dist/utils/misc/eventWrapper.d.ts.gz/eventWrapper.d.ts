export declare function eventWrapper<T>(cb: () => T): T | undefined;
