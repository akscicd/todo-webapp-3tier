export declare const hasFormSubmit: (form: HTMLFormElement | null) => form is HTMLFormElement;
