export declare function isDisabled(element: Element | null): boolean;
