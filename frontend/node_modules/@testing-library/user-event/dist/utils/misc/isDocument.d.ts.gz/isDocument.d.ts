export declare function isDocument(el: Document | Element): el is Document;
