export declare function isLabelWithInternallyDisabledControl(element: Element): boolean;
