export declare function isVisible(element: Element): boolean;
