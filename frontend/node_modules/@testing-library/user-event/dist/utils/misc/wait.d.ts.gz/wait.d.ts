export declare function wait(time?: number): Promise<void>;
