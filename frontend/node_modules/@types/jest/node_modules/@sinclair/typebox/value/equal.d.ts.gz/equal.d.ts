export declare namespace ValueEqual {
    function Equal<T>(left: T, right: unknown): right is T;
}
