# Installation
> `npm install --save @types/mime`

# Summary
This package contains type definitions for mime (https://github.com/broofa/node-mime).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mime/v1.

### Additional Details
 * Last updated: Wed, 18 Oct 2023 18:04:03 GMT
 * Dependencies: none

# Credits
These definitions were written by [Jeff Goddard](https://github.com/jedigo), and [Daniel Hritzkiv](https://github.com/dhritzkiv).
