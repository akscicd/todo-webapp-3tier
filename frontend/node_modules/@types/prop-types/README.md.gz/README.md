# Installation
> `npm install --save @types/prop-types`

# Summary
This package contains type definitions for prop-types (https://github.com/reactjs/prop-types).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/prop-types.

### Additional Details
 * Last updated: Wed, 18 Oct 2023 05:47:09 GMT
 * Dependencies: none

# Credits
These definitions were written by [DovydasNavickas](https://github.com/DovydasNavickas), [Ferdy Budhidharma](https://github.com/ferdaber), and [Sebastian Silbermann](https://github.com/eps1lon).
