# Installation
> `npm install --save @types/scheduler`

# Summary
This package contains type definitions for scheduler (https://reactjs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/scheduler.

### Additional Details
 * Last updated: Wed, 18 Oct 2023 18:04:04 GMT
 * Dependencies: none

# Credits
These definitions were written by [Nathan Bierema](https://github.com/Methuselah96), and [Sebastian Silbermann](https://github.com/eps1lon).
