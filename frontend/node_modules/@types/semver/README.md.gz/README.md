# Installation
> `npm install --save @types/semver`

# Summary
This package contains type definitions for semver (https://github.com/npm/node-semver).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/semver.

### Additional Details
 * Last updated: Wed, 18 Oct 2023 18:04:04 GMT
 * Dependencies: none

# Credits
These definitions were written by [Bart van der Schoor](https://github.com/Bartvds), [BendingBender](https://github.com/BendingBender), [Lucian Buzzo](https://github.com/LucianBuzzo), [Klaus Meinhardt](https://github.com/ajafff), [ExE Boss](https://github.com/ExE-Boss), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
