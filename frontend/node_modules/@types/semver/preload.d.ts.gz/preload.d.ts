import semver = require(".");
export = semver;
