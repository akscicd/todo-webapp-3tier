export * from '@typescript-eslint/utils';
//# sourceMappingURL=index.d.ts.map
