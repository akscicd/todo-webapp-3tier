declare function assert(value: unknown, message?: string): asserts value;
export { assert };
//# sourceMappingURL=assert.d.ts.map