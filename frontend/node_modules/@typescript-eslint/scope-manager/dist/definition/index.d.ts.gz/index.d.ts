export * from './CatchClauseDefinition';
export * from './ClassNameDefinition';
export * from './Definition';
export * from './DefinitionType';
export * from './FunctionNameDefinition';
export * from './ImplicitGlobalVariableDefinition';
export * from './ImportBindingDefinition';
export * from './ParameterDefinition';
export * from './TSEnumMemberDefinition';
export * from './TSEnumNameDefinition';
export * from './TSModuleNameDefinition';
export * from './TypeDefinition';
export * from './VariableDefinition';
//# sourceMappingURL=index.d.ts.map