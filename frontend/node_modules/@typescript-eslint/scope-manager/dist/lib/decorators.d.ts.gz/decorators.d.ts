import type { ImplicitLibVariableOptions } from '../variable';
export declare const decorators: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=decorators.d.ts.map