import type { ImplicitLibVariableOptions } from '../variable';
export declare const decorators_legacy: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=decorators.legacy.d.ts.map