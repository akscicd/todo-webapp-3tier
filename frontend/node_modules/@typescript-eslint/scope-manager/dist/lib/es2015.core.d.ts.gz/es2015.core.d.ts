import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_core: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.core.d.ts.map