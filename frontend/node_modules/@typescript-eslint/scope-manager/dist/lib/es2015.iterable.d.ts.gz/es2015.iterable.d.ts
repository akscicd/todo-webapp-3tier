import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_iterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.iterable.d.ts.map