"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// RUN THE FOLLOWING COMMAND FROM THE WORKSPACE ROOT TO REGENERATE:
// npx nx generate-lib @typescript-eslint/scope-manager
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2015_reflect = void 0;
const base_config_1 = require("./base-config");
exports.es2015_reflect = {
    Reflect: base_config_1.TYPE_VALUE,
};
//# sourceMappingURL=es2015.reflect.js.map