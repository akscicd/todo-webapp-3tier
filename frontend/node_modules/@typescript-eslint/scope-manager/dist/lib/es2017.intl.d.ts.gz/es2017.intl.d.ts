import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2017_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2017.intl.d.ts.map