"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// RUN THE FOLLOWING COMMAND FROM THE WORKSPACE ROOT TO REGENERATE:
// npx nx generate-lib @typescript-eslint/scope-manager
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2017_intl = void 0;
const base_config_1 = require("./base-config");
exports.es2017_intl = {
    Intl: base_config_1.TYPE_VALUE,
};
//# sourceMappingURL=es2017.intl.js.map