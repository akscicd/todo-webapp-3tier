import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2017_typedarrays: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2017.typedarrays.d.ts.map