import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2018_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2018.intl.d.ts.map