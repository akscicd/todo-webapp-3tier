import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2019_symbol: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2019.symbol.d.ts.map