import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2020_bigint: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.bigint.d.ts.map