"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// RUN THE FOLLOWING COMMAND FROM THE WORKSPACE ROOT TO REGENERATE:
// npx nx generate-lib @typescript-eslint/scope-manager
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2020_intl = void 0;
const base_config_1 = require("./base-config");
const es2018_intl_1 = require("./es2018.intl");
exports.es2020_intl = Object.assign(Object.assign({}, es2018_intl_1.es2018_intl), { Intl: base_config_1.TYPE_VALUE });
//# sourceMappingURL=es2020.intl.js.map