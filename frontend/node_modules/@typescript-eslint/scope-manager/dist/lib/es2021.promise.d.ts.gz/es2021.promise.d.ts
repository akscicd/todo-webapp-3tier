import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2021_promise: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2021.promise.d.ts.map