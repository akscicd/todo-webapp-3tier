import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2021_string: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2021.string.d.ts.map