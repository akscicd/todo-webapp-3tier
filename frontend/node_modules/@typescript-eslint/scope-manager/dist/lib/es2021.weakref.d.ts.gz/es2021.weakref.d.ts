import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2021_weakref: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2021.weakref.d.ts.map