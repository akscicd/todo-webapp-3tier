import type { ImplicitLibVariableOptions } from '../variable';
export declare const es6: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es6.d.ts.map