import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_bigint: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.bigint.d.ts.map