import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_promise: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.promise.d.ts.map