import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_symbol: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.symbol.d.ts.map