"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// RUN THE FOLLOWING COMMAND FROM THE WORKSPACE ROOT TO REGENERATE:
// npx nx generate-lib @typescript-eslint/scope-manager
Object.defineProperty(exports, "__esModule", { value: true });
exports.esnext_symbol = void 0;
const base_config_1 = require("./base-config");
exports.esnext_symbol = {
    Symbol: base_config_1.TYPE,
};
//# sourceMappingURL=esnext.symbol.js.map