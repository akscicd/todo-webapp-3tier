import type { ImplicitLibVariableOptions } from '../variable';
export declare const lib: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=lib.d.ts.map