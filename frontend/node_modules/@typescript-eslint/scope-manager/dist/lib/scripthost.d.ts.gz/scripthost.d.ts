import type { ImplicitLibVariableOptions } from '../variable';
export declare const scripthost: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=scripthost.d.ts.map