import type { ImplicitLibVariableOptions } from '../variable';
export declare const webworker: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=webworker.d.ts.map