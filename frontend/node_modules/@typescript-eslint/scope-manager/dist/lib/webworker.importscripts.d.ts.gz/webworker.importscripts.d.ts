import type { ImplicitLibVariableOptions } from '../variable';
export declare const webworker_importscripts: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=webworker.importscripts.d.ts.map