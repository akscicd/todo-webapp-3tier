import type { ImplicitLibVariableOptions } from '../variable';
export declare const webworker_iterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=webworker.iterable.d.ts.map