import * as ts from 'typescript';
declare function requiresQuoting(name: string, target?: ts.ScriptTarget): boolean;
export { requiresQuoting };
//# sourceMappingURL=requiresQuoting.d.ts.map
