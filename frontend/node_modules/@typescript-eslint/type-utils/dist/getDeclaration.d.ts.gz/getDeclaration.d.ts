import type * as ts from 'typescript';
/**
 * Gets the declaration for the given variable
 */
export declare function getDeclaration(checker: ts.TypeChecker, node: ts.Expression): ts.Declaration | null;
//# sourceMappingURL=getDeclaration.d.ts.map