import * as ts from 'typescript';
export declare function getTokenAtPosition(sourceFile: ts.SourceFile, position: number): ts.Node;
//# sourceMappingURL=getTokenAtPosition.d.ts.map