import * as TSESTree from './generated/ast-spec';
declare module './generated/ast-spec' {
    interface BaseNode {
        parent?: TSESTree.Node;
    }
}
import * as TSESTree_1 from './generated/ast-spec';
export { TSESTree_1 as TSESTree };
//# sourceMappingURL=ts-estree.d.ts.map
