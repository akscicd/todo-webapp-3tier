import type * as TSESTree from './generated/ast-spec';
declare module './generated/ast-spec' {
    interface BaseNode {
        parent?: TSESTree.Node;
    }
}
export * as TSESTree from './generated/ast-spec';
//# sourceMappingURL=ts-estree.d.ts.map