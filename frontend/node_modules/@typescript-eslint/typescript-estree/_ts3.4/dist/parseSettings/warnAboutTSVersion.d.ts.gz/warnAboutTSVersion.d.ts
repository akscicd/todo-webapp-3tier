import { ParseSettings } from './index';
export declare function warnAboutTSVersion(parseSettings: ParseSettings): void;
//# sourceMappingURL=warnAboutTSVersion.d.ts.map
