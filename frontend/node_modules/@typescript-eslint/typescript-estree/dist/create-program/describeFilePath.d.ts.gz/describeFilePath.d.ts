export declare function describeFilePath(filePath: string, tsconfigRootDir: string): string;
//# sourceMappingURL=describeFilePath.d.ts.map