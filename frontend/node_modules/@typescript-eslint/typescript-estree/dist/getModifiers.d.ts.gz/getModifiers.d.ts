import * as ts from 'typescript';
export declare function getModifiers(node: ts.Node | null | undefined): undefined | ts.Modifier[];
export declare function getDecorators(node: ts.Node | null | undefined): undefined | ts.Decorator[];
//# sourceMappingURL=getModifiers.d.ts.map