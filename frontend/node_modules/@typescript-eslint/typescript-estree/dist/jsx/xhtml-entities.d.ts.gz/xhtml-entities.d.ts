export declare const xhtmlEntities: Record<string, string>;
//# sourceMappingURL=xhtml-entities.d.ts.map