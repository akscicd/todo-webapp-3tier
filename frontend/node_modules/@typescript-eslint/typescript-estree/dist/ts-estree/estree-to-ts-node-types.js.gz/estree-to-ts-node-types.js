"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=estree-to-ts-node-types.js.map