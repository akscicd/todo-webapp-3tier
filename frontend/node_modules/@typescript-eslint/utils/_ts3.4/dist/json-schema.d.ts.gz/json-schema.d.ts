export { JSONSchema4, JSONSchema4Type, JSONSchema4TypeName, JSONSchema4Version, JSONSchema6, JSONSchema6Definition, JSONSchema6Type, JSONSchema6TypeName, JSONSchema6Version, JSONSchema7, JSONSchema7Array, JSONSchema7Definition, JSONSchema7Type, JSONSchema7TypeName, JSONSchema7Version, ValidationError, ValidationResult, } from 'json-schema';
//# sourceMappingURL=json-schema.d.ts.map
