export { AST_NODE_TYPES, AST_TOKEN_TYPES, TSESTree, } from '@typescript-eslint/types';
export { ParserServices } from '@typescript-eslint/typescript-estree/dist/parser-options';
//# sourceMappingURL=ts-estree.d.ts.map
