"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ParameterDefinition = exports.Definition = void 0;
const definition_1 = require("eslint-scope/lib/definition");
const Definition = definition_1.Definition;
exports.Definition = Definition;
const ParameterDefinition = definition_1.ParameterDefinition;
exports.ParameterDefinition = ParameterDefinition;
//# sourceMappingURL=Definition.js.map