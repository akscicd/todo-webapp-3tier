export { DebugLevel, EcmaVersion, ParserOptions, SourceType, } from '@typescript-eslint/types';
//# sourceMappingURL=ParserOptions.d.ts.map