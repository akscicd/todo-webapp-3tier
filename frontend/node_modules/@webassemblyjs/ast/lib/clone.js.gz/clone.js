"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cloneNode = cloneNode;

function cloneNode(n) {
  // $FlowIgnore
  return Object.assign({}, n);
}