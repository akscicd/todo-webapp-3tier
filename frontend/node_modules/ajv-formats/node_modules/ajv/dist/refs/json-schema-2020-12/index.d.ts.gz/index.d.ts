import type Ajv from "../../core";
export default function addMetaSchema2020(this: Ajv, $data?: boolean): Ajv;
