import * as re2 from "re2";
type Re2 = typeof re2 & {
    code: string;
};
declare const _default: Re2;
export default _default;
