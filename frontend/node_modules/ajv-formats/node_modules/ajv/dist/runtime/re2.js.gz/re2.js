"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const re2 = require("re2");
re2.code = 'require("ajv/dist/runtime/re2").default';
exports.default = re2;
//# sourceMappingURL=re2.js.map