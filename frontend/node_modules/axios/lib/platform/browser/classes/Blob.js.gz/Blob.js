'use strict'

export default typeof Blob !== 'undefined' ? Blob : null
