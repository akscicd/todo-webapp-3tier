'use strict';

export default typeof FormData !== 'undefined' ? FormData : null;
