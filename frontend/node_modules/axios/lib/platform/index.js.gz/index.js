import platform from './node/index.js';

export {platform as default}
