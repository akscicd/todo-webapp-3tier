import FormData from 'form-data';

export default FormData;
