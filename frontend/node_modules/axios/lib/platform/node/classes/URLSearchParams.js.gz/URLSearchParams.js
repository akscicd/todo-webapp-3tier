'use strict';

import url from 'url';
export default url.URLSearchParams;
