"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var AbbrRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'abbr'
    }
  }],
  type: 'structure'
};
var _default = AbbrRole;
exports.default = _default;