"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var AnnotationRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = AnnotationRole;
exports.default = _default;