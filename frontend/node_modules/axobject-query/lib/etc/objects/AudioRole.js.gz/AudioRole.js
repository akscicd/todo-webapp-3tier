"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var AudioRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'audio'
    }
  }],
  type: 'widget'
};
var _default = AudioRole;
exports.default = _default;