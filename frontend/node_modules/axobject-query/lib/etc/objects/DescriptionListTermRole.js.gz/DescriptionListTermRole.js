"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var DescriptionListTermRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'dt'
    }
  }],
  type: 'structure'
};
var _default = DescriptionListTermRole;
exports.default = _default;