"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var GridRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'grid'
    }
  }],
  type: 'widget'
};
var _default = GridRole;
exports.default = _default;