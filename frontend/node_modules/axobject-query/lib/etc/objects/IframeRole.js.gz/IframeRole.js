"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var IframeRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'iframe'
    }
  }],
  type: 'window'
};
var _default = IframeRole;
exports.default = _default;