"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var MathRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'math'
    }
  }],
  type: 'structure'
};
var _default = MathRole;
exports.default = _default;