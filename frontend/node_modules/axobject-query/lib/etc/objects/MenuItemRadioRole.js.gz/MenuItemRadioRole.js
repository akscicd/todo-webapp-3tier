"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var MenuItemRadioRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'menuitemradio'
    }
  }],
  type: 'widget'
};
var _default = MenuItemRadioRole;
exports.default = _default;