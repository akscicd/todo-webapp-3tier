"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var MeterRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'meter'
    }
  }],
  type: 'structure'
};
var _default = MeterRole;
exports.default = _default;