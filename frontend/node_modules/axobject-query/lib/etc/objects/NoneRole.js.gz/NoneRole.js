"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var NoneRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'none'
    }
  }],
  type: 'structure'
};
var _default = NoneRole;
exports.default = _default;