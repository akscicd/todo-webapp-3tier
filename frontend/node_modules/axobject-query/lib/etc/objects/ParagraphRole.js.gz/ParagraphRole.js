"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var ParagraphRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'p'
    }
  }],
  type: 'structure'
};
var _default = ParagraphRole;
exports.default = _default;