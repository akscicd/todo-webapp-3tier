"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var RootWebAreaRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = RootWebAreaRole;
exports.default = _default;