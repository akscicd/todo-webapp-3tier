"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var ScrollAreaRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = ScrollAreaRole;
exports.default = _default;