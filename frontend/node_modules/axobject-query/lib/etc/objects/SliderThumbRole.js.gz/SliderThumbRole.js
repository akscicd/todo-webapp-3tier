"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var SliderThumbRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = SliderThumbRole;
exports.default = _default;