"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var SpinButtonPartRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = SpinButtonPartRole;
exports.default = _default;