"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var StaticTextRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = StaticTextRole;
exports.default = _default;