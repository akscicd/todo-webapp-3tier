"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var TabPanelRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'tabpanel'
    }
  }],
  type: 'structure'
};
var _default = TabPanelRole;
exports.default = _default;