"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var TextAreaRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      attributes: [{
        name: 'aria-multiline',
        value: 'true'
      }],
      name: 'textbox'
    }
  }, {
    module: 'HTML',
    concept: {
      name: 'textarea'
    }
  }],
  type: 'widget'
};
var _default = TextAreaRole;
exports.default = _default;