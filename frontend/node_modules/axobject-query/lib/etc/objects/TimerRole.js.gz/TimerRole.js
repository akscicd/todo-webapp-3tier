"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var TimerRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'timer'
    }
  }],
  type: 'structure'
};
var _default = TimerRole;
exports.default = _default;