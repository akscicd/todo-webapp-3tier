"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var TreeRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'tree'
    }
  }],
  type: 'widget'
};
var _default = TreeRole;
exports.default = _default;