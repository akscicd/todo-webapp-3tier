type KeyValue = {
    [key: string]: any;
};
export default KeyValue;
