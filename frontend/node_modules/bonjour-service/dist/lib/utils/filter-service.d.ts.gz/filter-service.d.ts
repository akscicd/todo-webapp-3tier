import KeyValue from '../KeyValue';
import Service from '../service';
declare const _default: (service: Service, txtQuery: KeyValue | undefined) => boolean;
export default _default;
