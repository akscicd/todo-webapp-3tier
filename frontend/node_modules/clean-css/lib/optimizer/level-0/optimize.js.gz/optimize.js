function level0Optimize(tokens) {
  // noop as level 0 means no optimizations!
  return tokens;
}

module.exports = level0Optimize;
