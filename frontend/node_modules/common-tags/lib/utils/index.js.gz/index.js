'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.readFromFixture = undefined;

var _readFromFixture2 = require('./readFromFixture');

var _readFromFixture3 = _interopRequireDefault(_readFromFixture2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.readFromFixture = _readFromFixture3.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlscy9pbmRleC5qcyJdLCJuYW1lcyI6WyJyZWFkRnJvbUZpeHR1cmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFBT0EsZSIsImZpbGUiOiJpbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCByZWFkRnJvbUZpeHR1cmUgZnJvbSAnLi9yZWFkRnJvbUZpeHR1cmUnO1xuIl19