'use strict';
var parent = require('../../stable/array-buffer/is-view');

module.exports = parent;
