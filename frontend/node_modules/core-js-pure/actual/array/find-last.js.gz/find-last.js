'use strict';
require('../../modules/esnext.array.find-last');
var parent = require('../../stable/array/find-last');

module.exports = parent;
