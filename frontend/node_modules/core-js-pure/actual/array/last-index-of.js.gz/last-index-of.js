'use strict';
var parent = require('../../stable/array/last-index-of');

module.exports = parent;
