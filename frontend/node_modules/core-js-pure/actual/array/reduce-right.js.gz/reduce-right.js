'use strict';
var parent = require('../../stable/array/reduce-right');

module.exports = parent;
