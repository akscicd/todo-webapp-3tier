'use strict';
var parent = require('../../stable/array/some');

module.exports = parent;
