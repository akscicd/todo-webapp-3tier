'use strict';
var parent = require('../../stable/array/to-reversed');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.to-reversed');

module.exports = parent;
