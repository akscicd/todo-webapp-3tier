'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.promise');
require('../../modules/esnext.async-iterator.constructor');
require('../../modules/esnext.async-iterator.some');

var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('AsyncIterator', 'some');
