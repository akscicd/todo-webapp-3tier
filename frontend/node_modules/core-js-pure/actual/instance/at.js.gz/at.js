'use strict';
var parent = require('../../stable/instance/at');

module.exports = parent;
