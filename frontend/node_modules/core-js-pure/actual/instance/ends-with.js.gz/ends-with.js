'use strict';
var parent = require('../../stable/instance/ends-with');

module.exports = parent;
