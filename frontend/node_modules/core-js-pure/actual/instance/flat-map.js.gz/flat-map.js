'use strict';
var parent = require('../../stable/instance/flat-map');

module.exports = parent;
