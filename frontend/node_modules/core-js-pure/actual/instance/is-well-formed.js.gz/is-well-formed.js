'use strict';
var parent = require('../../stable/instance/is-well-formed');

module.exports = parent;
