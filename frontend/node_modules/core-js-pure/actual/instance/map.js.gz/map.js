'use strict';
var parent = require('../../stable/instance/map');

module.exports = parent;
