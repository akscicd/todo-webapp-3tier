'use strict';
var parent = require('../../stable/instance/push');

module.exports = parent;
