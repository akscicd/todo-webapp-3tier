'use strict';
var parent = require('../../stable/instance/reduce');

module.exports = parent;
