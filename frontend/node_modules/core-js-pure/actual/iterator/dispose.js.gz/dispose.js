'use strict';
require('../../modules/esnext.iterator.dispose');
