'use strict';
var parent = require('../../stable/math/log1p');

module.exports = parent;
