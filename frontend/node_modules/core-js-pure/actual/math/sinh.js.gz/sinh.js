'use strict';
var parent = require('../../stable/math/sinh');

module.exports = parent;
