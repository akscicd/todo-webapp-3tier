'use strict';
var parent = require('../../stable/math/to-string-tag');

module.exports = parent;
