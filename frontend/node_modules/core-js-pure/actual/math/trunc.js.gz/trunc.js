'use strict';
var parent = require('../../stable/math/trunc');

module.exports = parent;
