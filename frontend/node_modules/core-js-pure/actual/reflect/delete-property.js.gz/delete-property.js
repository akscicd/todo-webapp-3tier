'use strict';
var parent = require('../../stable/reflect/delete-property');

module.exports = parent;
