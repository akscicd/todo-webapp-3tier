'use strict';
var parent = require('../../stable/reflect/is-extensible');

module.exports = parent;
