'use strict';
var parent = require('../../stable/regexp/test');

module.exports = parent;
