'use strict';
var parent = require('../../stable/string/code-point-at');

module.exports = parent;
