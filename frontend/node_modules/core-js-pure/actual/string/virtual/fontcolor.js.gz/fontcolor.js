'use strict';
var parent = require('../../../stable/string/virtual/fontcolor');

module.exports = parent;
