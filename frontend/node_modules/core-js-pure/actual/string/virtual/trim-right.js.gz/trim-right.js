'use strict';
var parent = require('../../../stable/string/virtual/trim-right');

module.exports = parent;
