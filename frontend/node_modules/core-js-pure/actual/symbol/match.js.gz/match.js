'use strict';
var parent = require('../../stable/symbol/match');

module.exports = parent;
