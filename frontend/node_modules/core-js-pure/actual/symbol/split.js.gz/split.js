'use strict';
var parent = require('../../stable/symbol/split');

module.exports = parent;
