'use strict';
var parent = require('../../stable/typed-array/entries');

module.exports = parent;
