'use strict';
var parent = require('../../stable/typed-array/fill');

module.exports = parent;
