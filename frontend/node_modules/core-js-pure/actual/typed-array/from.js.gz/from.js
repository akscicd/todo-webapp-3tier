'use strict';
var parent = require('../../stable/typed-array/from');

module.exports = parent;
