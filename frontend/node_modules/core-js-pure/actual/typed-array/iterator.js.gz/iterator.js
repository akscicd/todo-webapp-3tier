'use strict';
var parent = require('../../stable/typed-array/iterator');

module.exports = parent;
