'use strict';
var parent = require('../../stable/typed-array/sort');

module.exports = parent;
