'use strict';
var parent = require('../../stable/typed-array/with');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.typed-array.with');

module.exports = parent;
