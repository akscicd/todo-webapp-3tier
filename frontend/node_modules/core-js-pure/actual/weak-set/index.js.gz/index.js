'use strict';
var parent = require('../../stable/weak-set');

module.exports = parent;
