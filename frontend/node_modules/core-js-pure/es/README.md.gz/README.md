This folder contains entry points for [stable ECMAScript features](https://github.com/zloirock/core-js/#ecmascript) with dependencies.
