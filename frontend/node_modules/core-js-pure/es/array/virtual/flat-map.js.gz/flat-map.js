'use strict';
require('../../../modules/es.array.flat-map');
require('../../../modules/es.array.unscopables.flat-map');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Array', 'flatMap');
