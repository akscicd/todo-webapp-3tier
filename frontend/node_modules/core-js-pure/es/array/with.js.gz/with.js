'use strict';
require('../../modules/es.array.with');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'with');
