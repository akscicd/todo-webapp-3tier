'use strict';
require('../../modules/es.date.set-year');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Date', 'setYear');
