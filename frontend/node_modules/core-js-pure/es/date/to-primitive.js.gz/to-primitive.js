'use strict';
require('../../modules/es.date.to-primitive');
var uncurryThis = require('../../internals/function-uncurry-this');
var toPrimitive = require('../../internals/date-to-primitive');

module.exports = uncurryThis(toPrimitive);
