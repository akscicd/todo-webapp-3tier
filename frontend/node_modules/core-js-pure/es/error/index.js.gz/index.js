'use strict';
require('../../modules/es.error.cause');
require('../../modules/es.error.to-string');
var path = require('../../internals/path');

module.exports = path;
