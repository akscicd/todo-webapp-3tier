'use strict';
require('../../modules/es.json.to-string-tag');

module.exports = 'JSON';
