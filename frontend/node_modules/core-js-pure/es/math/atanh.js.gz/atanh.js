'use strict';
require('../../modules/es.math.atanh');
var path = require('../../internals/path');

module.exports = path.Math.atanh;
