'use strict';
require('../../modules/es.math.to-string-tag');

module.exports = 'Math';
