'use strict';
require('../../modules/es.number.epsilon');

module.exports = Math.pow(2, -52);
