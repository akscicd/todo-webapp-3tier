'use strict';
require('../../modules/es.number.min-safe-integer');

module.exports = -0x1FFFFFFFFFFFFF;
