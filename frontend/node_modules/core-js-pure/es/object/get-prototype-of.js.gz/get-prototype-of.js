'use strict';
require('../../modules/es.object.get-prototype-of');
var path = require('../../internals/path');

module.exports = path.Object.getPrototypeOf;
