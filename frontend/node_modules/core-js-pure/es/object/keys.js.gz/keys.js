'use strict';
require('../../modules/es.object.keys');
var path = require('../../internals/path');

module.exports = path.Object.keys;
