'use strict';
require('../../modules/es.object.proto');
