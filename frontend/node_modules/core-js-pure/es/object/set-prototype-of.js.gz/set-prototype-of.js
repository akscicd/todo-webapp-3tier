'use strict';
require('../../modules/es.object.set-prototype-of');
var path = require('../../internals/path');

module.exports = path.Object.setPrototypeOf;
