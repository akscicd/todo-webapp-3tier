'use strict';
require('../../modules/es.string.code-point-at');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'codePointAt');
