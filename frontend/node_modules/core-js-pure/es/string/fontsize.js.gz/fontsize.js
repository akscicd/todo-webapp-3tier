'use strict';
require('../../modules/es.string.fontsize');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'fontsize');
