'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.regexp.exec');
require('../../modules/es.string.match-all');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'matchAll');
