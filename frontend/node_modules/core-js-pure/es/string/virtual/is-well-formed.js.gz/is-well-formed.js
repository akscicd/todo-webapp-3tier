'use strict';
require('../../../modules/es.string.is-well-formed');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'isWellFormed');
