'use strict';
require('../../modules/es.symbol');
var path = require('../../internals/path');

module.exports = path.Symbol.keyFor;
