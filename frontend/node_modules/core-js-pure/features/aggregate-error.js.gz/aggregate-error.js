'use strict';
module.exports = require('../full/aggregate-error');
