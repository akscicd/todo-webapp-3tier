'use strict';
module.exports = require('../../../full/array/virtual/find-index');
