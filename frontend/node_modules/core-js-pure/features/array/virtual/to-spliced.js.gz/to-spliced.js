'use strict';
module.exports = require('../../../full/array/virtual/to-spliced');
