'use strict';
module.exports = require('../../../full/array/virtual/unique-by');
