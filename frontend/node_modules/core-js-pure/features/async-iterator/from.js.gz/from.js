'use strict';
module.exports = require('../../full/async-iterator/from');
