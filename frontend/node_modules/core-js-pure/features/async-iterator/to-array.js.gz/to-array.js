'use strict';
module.exports = require('../../full/async-iterator/to-array');
