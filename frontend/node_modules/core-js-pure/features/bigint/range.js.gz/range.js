'use strict';
module.exports = require('../../full/bigint/range');
