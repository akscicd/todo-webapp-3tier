'use strict';
module.exports = require('../full/composite-key');
