'use strict';
module.exports = require('../../full/data-view/get-float16');
