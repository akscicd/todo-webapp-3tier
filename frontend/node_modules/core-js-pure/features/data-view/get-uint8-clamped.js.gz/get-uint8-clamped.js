'use strict';
module.exports = require('../../full/data-view/get-uint8-clamped');
