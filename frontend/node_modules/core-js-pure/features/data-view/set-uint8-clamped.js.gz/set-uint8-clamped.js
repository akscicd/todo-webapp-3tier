'use strict';
module.exports = require('../../full/data-view/set-uint8-clamped');
