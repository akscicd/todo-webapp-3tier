'use strict';
module.exports = require('../../full/date/set-year');
