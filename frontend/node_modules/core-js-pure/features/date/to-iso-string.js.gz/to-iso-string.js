'use strict';
module.exports = require('../../full/date/to-iso-string');
