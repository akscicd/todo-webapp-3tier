'use strict';
module.exports = require('../../full/dom-collections/iterator');
