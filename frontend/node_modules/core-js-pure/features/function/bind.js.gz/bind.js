'use strict';
module.exports = require('../../full/function/bind');
