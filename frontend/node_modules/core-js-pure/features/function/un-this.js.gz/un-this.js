'use strict';
module.exports = require('../../full/function/un-this');
