'use strict';
module.exports = require('../full/global-this');
