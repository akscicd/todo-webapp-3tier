'use strict';
module.exports = require('../../full/instance/reverse');
