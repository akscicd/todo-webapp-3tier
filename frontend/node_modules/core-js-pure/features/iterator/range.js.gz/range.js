'use strict';
module.exports = require('../../full/iterator/range');
