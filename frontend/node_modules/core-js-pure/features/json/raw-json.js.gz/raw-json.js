'use strict';
module.exports = require('../../full/json/raw-json');
