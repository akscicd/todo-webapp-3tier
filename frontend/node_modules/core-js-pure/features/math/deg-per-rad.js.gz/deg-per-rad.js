'use strict';
module.exports = require('../../full/math/deg-per-rad');
