'use strict';
module.exports = require('../../full/math/f16round');
