'use strict';
module.exports = require('../../full/math/isubh');
