'use strict';
module.exports = require('../../full/math/log1p');
