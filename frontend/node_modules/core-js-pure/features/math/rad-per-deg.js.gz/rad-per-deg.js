'use strict';
module.exports = require('../../full/math/rad-per-deg');
