'use strict';
module.exports = require('../../../full/number/virtual/to-exponential');
