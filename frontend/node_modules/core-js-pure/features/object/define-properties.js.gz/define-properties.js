'use strict';
module.exports = require('../../full/object/define-properties');
