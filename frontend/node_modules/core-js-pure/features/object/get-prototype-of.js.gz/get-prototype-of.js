'use strict';
module.exports = require('../../full/object/get-prototype-of');
