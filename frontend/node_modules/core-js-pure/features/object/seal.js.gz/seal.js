'use strict';
module.exports = require('../../full/object/seal');
