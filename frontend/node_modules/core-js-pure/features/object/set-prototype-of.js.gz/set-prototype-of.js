'use strict';
module.exports = require('../../full/object/set-prototype-of');
