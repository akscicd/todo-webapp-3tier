'use strict';
module.exports = require('../full/parse-float');
