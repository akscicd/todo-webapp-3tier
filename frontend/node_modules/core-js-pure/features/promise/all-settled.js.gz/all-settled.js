'use strict';
module.exports = require('../../full/promise/all-settled');
