'use strict';
module.exports = require('../../full/reflect/delete-metadata');
