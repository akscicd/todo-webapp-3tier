'use strict';
module.exports = require('../../full/regexp');
