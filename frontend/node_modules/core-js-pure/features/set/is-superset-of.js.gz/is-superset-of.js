'use strict';
module.exports = require('../../full/set/is-superset-of');
