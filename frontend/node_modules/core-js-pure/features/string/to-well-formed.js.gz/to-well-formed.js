'use strict';
module.exports = require('../../full/string/to-well-formed');
