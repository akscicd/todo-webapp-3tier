'use strict';
module.exports = require('../../../full/string/virtual/replace-all');
