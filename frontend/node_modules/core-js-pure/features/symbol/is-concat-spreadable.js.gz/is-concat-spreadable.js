'use strict';
module.exports = require('../../full/symbol/is-concat-spreadable');
