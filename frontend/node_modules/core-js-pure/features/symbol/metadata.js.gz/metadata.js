'use strict';
module.exports = require('../../full/symbol/metadata');
