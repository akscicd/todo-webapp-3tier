'use strict';
module.exports = require('../../full/symbol/pattern-match');
