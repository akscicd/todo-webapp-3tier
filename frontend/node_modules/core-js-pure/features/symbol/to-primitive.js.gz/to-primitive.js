'use strict';
module.exports = require('../../full/symbol/to-primitive');
