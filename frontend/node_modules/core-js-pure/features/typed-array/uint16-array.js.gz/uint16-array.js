'use strict';
module.exports = require('../../full/typed-array/uint16-array');
