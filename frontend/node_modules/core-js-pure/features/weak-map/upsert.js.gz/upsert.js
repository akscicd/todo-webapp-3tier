'use strict';
module.exports = require('../../full/weak-map/upsert');
