'use strict';
module.exports = require('../../full/weak-set/delete-all');
