'use strict';
var parent = require('../../actual/array-buffer/detached');

module.exports = parent;
