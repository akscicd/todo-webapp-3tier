'use strict';
var parent = require('../../actual/array-buffer/transfer-to-fixed-length');

module.exports = parent;
