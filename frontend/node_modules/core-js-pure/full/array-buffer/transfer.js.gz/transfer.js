'use strict';
var parent = require('../../actual/array-buffer/transfer');

module.exports = parent;
