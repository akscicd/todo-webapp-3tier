'use strict';
var parent = require('../../actual/array/find');

module.exports = parent;
