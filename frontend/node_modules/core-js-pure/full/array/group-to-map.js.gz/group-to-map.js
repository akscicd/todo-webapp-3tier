'use strict';
var parent = require('../../actual/array/group-to-map');

module.exports = parent;
