'use strict';
var parent = require('../../../actual/array/virtual/flat-map');

module.exports = parent;
