'use strict';
var parent = require('../../../actual/array/virtual/flat');

module.exports = parent;
