'use strict';
var parent = require('../../../actual/array/virtual/iterator');

module.exports = parent;
