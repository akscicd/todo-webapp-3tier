'use strict';
var parent = require('../../../actual/array/virtual/to-spliced');

module.exports = parent;
