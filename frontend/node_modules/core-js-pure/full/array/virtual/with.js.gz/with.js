'use strict';
var parent = require('../../../actual/array/virtual/with');

module.exports = parent;
