'use strict';
var parent = require('../../actual/array/with');

module.exports = parent;
