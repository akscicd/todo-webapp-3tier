'use strict';
var parent = require('../../actual/async-disposable-stack/constructor');

module.exports = parent;
