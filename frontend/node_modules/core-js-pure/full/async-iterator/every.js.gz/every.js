'use strict';
var parent = require('../../actual/async-iterator/every');

module.exports = parent;
