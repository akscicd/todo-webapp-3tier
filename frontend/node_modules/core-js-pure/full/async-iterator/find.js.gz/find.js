'use strict';
var parent = require('../../actual/async-iterator/find');

module.exports = parent;
