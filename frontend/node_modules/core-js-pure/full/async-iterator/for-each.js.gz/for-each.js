'use strict';
var parent = require('../../actual/async-iterator/for-each');

module.exports = parent;
