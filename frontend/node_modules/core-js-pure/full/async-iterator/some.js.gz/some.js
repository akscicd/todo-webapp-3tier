'use strict';
var parent = require('../../actual/async-iterator/some');

module.exports = parent;
