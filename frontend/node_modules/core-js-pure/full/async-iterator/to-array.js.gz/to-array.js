'use strict';
var parent = require('../../actual/async-iterator/to-array');

module.exports = parent;
