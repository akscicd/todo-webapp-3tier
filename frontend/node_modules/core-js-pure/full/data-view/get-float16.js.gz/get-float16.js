'use strict';
var parent = require('../../actual/data-view/get-float16');

module.exports = parent;
