'use strict';
var parent = require('../../actual/data-view/set-float16');

module.exports = parent;
