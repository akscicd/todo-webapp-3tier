'use strict';
require('../../modules/esnext.data-view.set-uint8-clamped');
