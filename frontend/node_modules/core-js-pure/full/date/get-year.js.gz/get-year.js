'use strict';
var parent = require('../../actual/date/get-year');

module.exports = parent;
