'use strict';
var parent = require('../../actual/date/to-string');

module.exports = parent;
