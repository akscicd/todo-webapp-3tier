'use strict';
var parent = require('../../actual/dom-exception');

module.exports = parent;
