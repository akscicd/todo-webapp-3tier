'use strict';
var parent = require('../../../actual/function/virtual');
require('../../../modules/esnext.function.demethodize');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.function.un-this');

module.exports = parent;
