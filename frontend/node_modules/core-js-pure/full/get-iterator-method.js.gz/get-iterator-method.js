'use strict';
var parent = require('../actual/get-iterator-method');

module.exports = parent;
