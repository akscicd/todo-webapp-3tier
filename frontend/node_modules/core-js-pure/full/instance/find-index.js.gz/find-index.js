'use strict';
var parent = require('../../actual/instance/find-index');

module.exports = parent;
