'use strict';
var parent = require('../../actual/instance/flat');

module.exports = parent;
