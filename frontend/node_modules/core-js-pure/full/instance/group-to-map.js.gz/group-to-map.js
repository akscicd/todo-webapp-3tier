'use strict';
var parent = require('../../actual/instance/group-to-map');

module.exports = parent;
