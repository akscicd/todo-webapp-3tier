'use strict';
var parent = require('../../actual/instance/group');

module.exports = parent;
