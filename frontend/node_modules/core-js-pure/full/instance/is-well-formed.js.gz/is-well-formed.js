'use strict';
var parent = require('../../actual/instance/is-well-formed');

module.exports = parent;
