'use strict';
var parent = require('../../actual/instance/last-index-of');

module.exports = parent;
