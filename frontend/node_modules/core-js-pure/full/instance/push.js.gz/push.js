'use strict';
var parent = require('../../actual/instance/push');

module.exports = parent;
