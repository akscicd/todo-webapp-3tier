'use strict';
var parent = require('../../actual/instance/reduce-right');

module.exports = parent;
