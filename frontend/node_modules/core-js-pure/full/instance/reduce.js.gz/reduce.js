'use strict';
var parent = require('../../actual/instance/reduce');

module.exports = parent;
