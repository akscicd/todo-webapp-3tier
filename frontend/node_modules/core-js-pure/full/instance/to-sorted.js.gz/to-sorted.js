'use strict';
var parent = require('../../actual/instance/to-sorted');

module.exports = parent;
