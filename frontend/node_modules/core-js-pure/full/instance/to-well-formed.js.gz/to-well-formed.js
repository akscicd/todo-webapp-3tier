'use strict';
var parent = require('../../actual/instance/to-well-formed');

module.exports = parent;
