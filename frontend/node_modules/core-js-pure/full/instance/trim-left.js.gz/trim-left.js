'use strict';
var parent = require('../../actual/instance/trim-left');

module.exports = parent;
