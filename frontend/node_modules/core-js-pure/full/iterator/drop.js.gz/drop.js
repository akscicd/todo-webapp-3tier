'use strict';
var parent = require('../../actual/iterator/drop');

module.exports = parent;
