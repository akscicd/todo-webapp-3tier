'use strict';
var parent = require('../../actual/iterator/every');

module.exports = parent;
