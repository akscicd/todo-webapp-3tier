'use strict';
var parent = require('../../actual/iterator/filter');

module.exports = parent;
