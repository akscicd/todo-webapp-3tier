'use strict';
var parent = require('../../actual/iterator/find');

module.exports = parent;
