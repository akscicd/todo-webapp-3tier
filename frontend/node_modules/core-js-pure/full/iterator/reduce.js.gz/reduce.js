'use strict';
var parent = require('../../actual/iterator/reduce');

module.exports = parent;
