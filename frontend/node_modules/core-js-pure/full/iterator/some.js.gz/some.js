'use strict';
var parent = require('../../actual/iterator/some');

module.exports = parent;
