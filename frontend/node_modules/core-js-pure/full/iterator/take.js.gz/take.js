'use strict';
var parent = require('../../actual/iterator/take');

module.exports = parent;
