'use strict';
var parent = require('../../actual/iterator/to-array');

module.exports = parent;
