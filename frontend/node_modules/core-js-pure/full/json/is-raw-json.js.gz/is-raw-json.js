'use strict';
var parent = require('../../actual/json/is-raw-json');

module.exports = parent;
