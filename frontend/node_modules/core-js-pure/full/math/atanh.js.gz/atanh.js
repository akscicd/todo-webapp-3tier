'use strict';
var parent = require('../../actual/math/atanh');

module.exports = parent;
