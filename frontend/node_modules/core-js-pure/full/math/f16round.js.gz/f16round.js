'use strict';
var parent = require('../../actual/math/f16round');

module.exports = parent;
