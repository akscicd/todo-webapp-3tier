'use strict';
var parent = require('../../actual/math/fround');

module.exports = parent;
