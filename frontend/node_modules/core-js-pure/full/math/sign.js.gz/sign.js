'use strict';
var parent = require('../../actual/math/sign');

module.exports = parent;
