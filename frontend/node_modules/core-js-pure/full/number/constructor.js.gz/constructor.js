'use strict';
var parent = require('../../actual/number/constructor');

module.exports = parent;
