'use strict';
var parent = require('../../actual/number/parse-float');

module.exports = parent;
