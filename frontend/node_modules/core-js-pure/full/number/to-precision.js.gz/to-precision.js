'use strict';
var parent = require('../../actual/number/to-precision');

module.exports = parent;
