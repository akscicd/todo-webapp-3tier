'use strict';
var parent = require('../../actual/object/from-entries');

module.exports = parent;
