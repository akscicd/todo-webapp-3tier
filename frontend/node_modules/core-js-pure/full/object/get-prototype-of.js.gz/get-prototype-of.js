'use strict';
var parent = require('../../actual/object/get-prototype-of');

module.exports = parent;
