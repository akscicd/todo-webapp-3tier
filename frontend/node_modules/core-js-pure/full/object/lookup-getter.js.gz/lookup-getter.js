'use strict';
var parent = require('../../actual/object/lookup-getter');

module.exports = parent;
