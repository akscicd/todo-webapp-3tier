'use strict';
var parent = require('../../actual/object/prevent-extensions');

module.exports = parent;
