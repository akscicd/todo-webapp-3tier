'use strict';
var parent = require('../../actual/object/proto');

module.exports = parent;
