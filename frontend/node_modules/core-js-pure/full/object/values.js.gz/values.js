'use strict';
var parent = require('../../actual/object/values');

module.exports = parent;
