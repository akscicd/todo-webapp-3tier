'use strict';
// TODO: Remove from `core-js@4`
require('../../modules/esnext.promise.all-settled');

var parent = require('../../actual/promise/all-settled');

module.exports = parent;
