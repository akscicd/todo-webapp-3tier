'use strict';
var parent = require('../../actual/reflect/apply');

module.exports = parent;
