'use strict';
require('../../modules/esnext.reflect.get-own-metadata');
var path = require('../../internals/path');

module.exports = path.Reflect.getOwnMetadata;
