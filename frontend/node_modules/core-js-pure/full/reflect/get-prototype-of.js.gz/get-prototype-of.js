'use strict';
var parent = require('../../actual/reflect/get-prototype-of');

module.exports = parent;
