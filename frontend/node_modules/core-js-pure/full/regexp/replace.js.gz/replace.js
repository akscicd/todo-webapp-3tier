'use strict';
var parent = require('../../actual/regexp/replace');

module.exports = parent;
