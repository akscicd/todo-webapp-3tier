'use strict';
var parent = require('../../actual/string/fontsize');

module.exports = parent;
