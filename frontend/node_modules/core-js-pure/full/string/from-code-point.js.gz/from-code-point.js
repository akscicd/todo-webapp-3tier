'use strict';
var parent = require('../../actual/string/from-code-point');

module.exports = parent;
