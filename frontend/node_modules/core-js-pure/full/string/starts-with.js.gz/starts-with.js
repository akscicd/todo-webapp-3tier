'use strict';
var parent = require('../../actual/string/starts-with');

module.exports = parent;
