'use strict';
var parent = require('../../actual/string/to-well-formed');

module.exports = parent;
