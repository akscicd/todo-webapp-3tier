'use strict';
var parent = require('../../actual/string/trim-right');

module.exports = parent;
