'use strict';
var parent = require('../../../actual/string/virtual/code-point-at');

module.exports = parent;
