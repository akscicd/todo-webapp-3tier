'use strict';
var parent = require('../../../actual/string/virtual/fixed');

module.exports = parent;
