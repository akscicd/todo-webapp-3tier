'use strict';
var parent = require('../../../actual/string/virtual/small');

module.exports = parent;
