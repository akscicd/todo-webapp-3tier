'use strict';
var parent = require('../../../actual/string/virtual/to-well-formed');

module.exports = parent;
