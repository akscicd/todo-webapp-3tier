'use strict';
var parent = require('../actual/suppressed-error');

module.exports = parent;
