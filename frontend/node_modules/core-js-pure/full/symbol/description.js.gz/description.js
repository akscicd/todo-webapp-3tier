'use strict';
require('../../modules/es.symbol.description');
