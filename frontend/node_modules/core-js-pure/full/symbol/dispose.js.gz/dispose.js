'use strict';
var parent = require('../../actual/symbol/dispose');

module.exports = parent;
