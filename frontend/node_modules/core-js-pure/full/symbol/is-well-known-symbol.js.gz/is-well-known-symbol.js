'use strict';
require('../../modules/es.symbol');
require('../../modules/esnext.symbol.is-well-known-symbol');
var path = require('../../internals/path');

module.exports = path.Symbol.isWellKnownSymbol;
