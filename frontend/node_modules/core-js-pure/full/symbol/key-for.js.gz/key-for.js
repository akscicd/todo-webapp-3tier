'use strict';
var parent = require('../../actual/symbol/key-for');

module.exports = parent;
