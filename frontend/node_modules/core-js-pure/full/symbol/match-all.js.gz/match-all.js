'use strict';
var parent = require('../../actual/symbol/match-all');

module.exports = parent;
