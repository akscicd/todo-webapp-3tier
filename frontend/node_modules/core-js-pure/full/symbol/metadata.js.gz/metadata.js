'use strict';
var parent = require('../../actual/symbol/metadata');

module.exports = parent;
