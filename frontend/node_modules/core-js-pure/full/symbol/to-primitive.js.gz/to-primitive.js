'use strict';
var parent = require('../../actual/symbol/to-primitive');

module.exports = parent;
