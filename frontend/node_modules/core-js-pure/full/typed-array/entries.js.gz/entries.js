'use strict';
var parent = require('../../actual/typed-array/entries');

module.exports = parent;
