'use strict';
var parent = require('../../actual/typed-array/filter');

module.exports = parent;
