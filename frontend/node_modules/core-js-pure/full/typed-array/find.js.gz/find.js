'use strict';
var parent = require('../../actual/typed-array/find');

module.exports = parent;
