'use strict';
require('../../modules/esnext.typed-array.group-by');
