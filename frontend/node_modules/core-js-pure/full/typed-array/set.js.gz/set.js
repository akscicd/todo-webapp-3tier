'use strict';
var parent = require('../../actual/typed-array/set');

module.exports = parent;
