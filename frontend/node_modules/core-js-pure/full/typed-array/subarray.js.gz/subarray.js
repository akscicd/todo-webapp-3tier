'use strict';
var parent = require('../../actual/typed-array/subarray');

module.exports = parent;
