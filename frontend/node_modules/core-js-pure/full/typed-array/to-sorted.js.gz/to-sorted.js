'use strict';
var parent = require('../../actual/typed-array/to-sorted');

module.exports = parent;
