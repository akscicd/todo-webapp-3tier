'use strict';
module.exports = function () { /* empty */ };
