'use strict';
module.exports = /./.exec;
