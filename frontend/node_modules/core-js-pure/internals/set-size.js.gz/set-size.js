'use strict';
module.exports = function (set) {
  return set.size;
};
