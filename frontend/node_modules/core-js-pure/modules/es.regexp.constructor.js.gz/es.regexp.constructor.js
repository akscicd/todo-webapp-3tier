'use strict';
var setSpecies = require('../internals/set-species');

setSpecies('RegExp');
