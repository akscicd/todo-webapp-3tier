'use strict';
// TODO: Remove from `core-js@4`
require('../modules/es.typed-array.to-reversed');
