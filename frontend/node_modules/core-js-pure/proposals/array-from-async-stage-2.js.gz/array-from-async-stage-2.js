'use strict';
// https://github.com/tc39/proposal-array-from-async
require('../modules/esnext.array.from-async');
