'use strict';
// TODO: Remove from `core-js@4`
// https://github.com/tc39/proposal-decorators
require('../modules/esnext.symbol.metadata');
