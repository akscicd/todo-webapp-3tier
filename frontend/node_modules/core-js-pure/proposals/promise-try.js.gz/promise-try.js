'use strict';
// https://github.com/tc39/proposal-promise-try
require('../modules/esnext.promise.try');
