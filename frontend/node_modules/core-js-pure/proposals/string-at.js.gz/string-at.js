'use strict';
// https://github.com/mathiasbynens/String.prototype.at
require('../modules/esnext.string.at');
