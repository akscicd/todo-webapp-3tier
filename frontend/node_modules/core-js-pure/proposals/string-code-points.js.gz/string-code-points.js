'use strict';
// https://github.com/tc39/proposal-string-prototype-codepoints
require('../modules/esnext.string.code-points');
