'use strict';
// https://github.com/tc39/proposal-string-dedent
require('../modules/esnext.string.dedent');
