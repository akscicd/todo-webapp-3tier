'use strict';
// https://github.com/tc39/proposal-string-replaceall
require('../modules/esnext.string.replace-all');
