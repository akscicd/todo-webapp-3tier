'use strict';
// https://github.com/tc39/proposal-string-replaceall
require('../modules/esnext.string.replace-all');
// TODO: remove from `core-js@4`
require('../modules/esnext.symbol.replace-all');
