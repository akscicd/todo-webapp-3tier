'use strict';
// https://github.com/tc39/proposal-Symbol-description
require('../modules/es.symbol.description');
