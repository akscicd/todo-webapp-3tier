'use strict';
// https://github.com/tc39/proposal-symbol-predicates
require('../modules/esnext.symbol.is-registered-symbol');
require('../modules/esnext.symbol.is-well-known-symbol');
