'use strict';
// https://github.com/tc39/proposal-well-formed-stringify
require('../modules/es.json.stringify');
