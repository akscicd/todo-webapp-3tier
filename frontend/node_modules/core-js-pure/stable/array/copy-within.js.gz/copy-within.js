'use strict';
var parent = require('../../es/array/copy-within');

module.exports = parent;
