'use strict';
var parent = require('../../es/array/join');

module.exports = parent;
