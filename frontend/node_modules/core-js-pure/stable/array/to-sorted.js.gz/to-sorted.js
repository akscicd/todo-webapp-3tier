'use strict';
var parent = require('../../es/array/to-sorted');

module.exports = parent;
