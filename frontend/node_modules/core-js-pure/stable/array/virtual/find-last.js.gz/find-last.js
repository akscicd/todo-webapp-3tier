'use strict';
module.exports = require('../../../es/array/virtual/find-last');
