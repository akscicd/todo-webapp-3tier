'use strict';
var parent = require('../../../es/array/virtual/for-each');

module.exports = parent;
