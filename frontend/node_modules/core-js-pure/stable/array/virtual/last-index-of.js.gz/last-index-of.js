'use strict';
var parent = require('../../../es/array/virtual/last-index-of');

module.exports = parent;
