'use strict';
var parent = require('../../../es/array/virtual/to-reversed');

module.exports = parent;
