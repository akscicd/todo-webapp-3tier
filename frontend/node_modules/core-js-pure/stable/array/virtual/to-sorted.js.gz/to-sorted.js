'use strict';
var parent = require('../../../es/array/virtual/to-sorted');

module.exports = parent;
