'use strict';
var parent = require('../../../es/array/virtual/with');

module.exports = parent;
