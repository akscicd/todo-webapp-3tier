'use strict';
var parent = require('../../es/data-view');

module.exports = parent;
