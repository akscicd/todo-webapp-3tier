'use strict';
var parent = require('../../es/date/get-year');

module.exports = parent;
