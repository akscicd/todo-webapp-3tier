'use strict';
var parent = require('../../es/error/to-string');

module.exports = parent;
