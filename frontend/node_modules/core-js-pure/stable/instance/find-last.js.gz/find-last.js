'use strict';
var parent = require('../../es/instance/find-last');

module.exports = parent;
