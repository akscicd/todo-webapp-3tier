'use strict';
var parent = require('../../es/instance/push');

module.exports = parent;
