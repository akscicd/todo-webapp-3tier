'use strict';
var parent = require('../../es/instance/repeat');

module.exports = parent;
