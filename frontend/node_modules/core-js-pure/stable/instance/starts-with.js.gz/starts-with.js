'use strict';
var parent = require('../../es/instance/starts-with');

module.exports = parent;
