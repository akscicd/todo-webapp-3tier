'use strict';
var parent = require('../../es/instance/to-spliced');

module.exports = parent;
