'use strict';
var parent = require('../../es/instance/to-well-formed');

module.exports = parent;
