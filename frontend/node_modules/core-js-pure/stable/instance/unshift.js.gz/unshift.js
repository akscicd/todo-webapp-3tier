'use strict';
var parent = require('../../es/instance/unshift');

module.exports = parent;
