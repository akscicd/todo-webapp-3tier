'use strict';
var parent = require('../../es/instance/with');

module.exports = parent;
