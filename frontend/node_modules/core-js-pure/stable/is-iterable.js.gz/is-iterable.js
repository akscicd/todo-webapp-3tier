'use strict';
var parent = require('../es/is-iterable');
require('../modules/web.dom-collections.iterator');

module.exports = parent;
