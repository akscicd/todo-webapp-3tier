'use strict';
var parent = require('../../es/math/asinh');

module.exports = parent;
