'use strict';
var parent = require('../../es/number');

module.exports = parent;
