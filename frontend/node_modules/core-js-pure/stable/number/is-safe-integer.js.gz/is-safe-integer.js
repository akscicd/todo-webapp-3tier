'use strict';
var parent = require('../../es/number/is-safe-integer');

module.exports = parent;
