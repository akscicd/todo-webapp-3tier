'use strict';
var parent = require('../../es/object/assign');

module.exports = parent;
