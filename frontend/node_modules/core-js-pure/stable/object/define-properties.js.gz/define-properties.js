'use strict';
var parent = require('../../es/object/define-properties');

module.exports = parent;
