'use strict';
var parent = require('../../es/object/get-own-property-descriptor');

module.exports = parent;
