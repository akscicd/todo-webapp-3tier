'use strict';
var parent = require('../../es/object/proto');

module.exports = parent;
