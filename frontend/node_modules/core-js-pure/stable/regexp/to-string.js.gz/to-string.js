'use strict';
var parent = require('../../es/regexp/to-string');

module.exports = parent;
