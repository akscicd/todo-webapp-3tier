'use strict';
require('../modules/web.immediate');
var path = require('../internals/path');

module.exports = path.setImmediate;
