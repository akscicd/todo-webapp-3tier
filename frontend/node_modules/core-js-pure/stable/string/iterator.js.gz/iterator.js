'use strict';
var parent = require('../../es/string/iterator');

module.exports = parent;
