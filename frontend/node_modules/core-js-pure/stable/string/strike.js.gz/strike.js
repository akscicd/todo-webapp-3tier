'use strict';
var parent = require('../../es/string/strike');

module.exports = parent;
