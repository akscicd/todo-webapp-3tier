'use strict';
var parent = require('../../es/string/substr');

module.exports = parent;
