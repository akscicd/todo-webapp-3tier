'use strict';
var parent = require('../../../es/string/virtual/big');

module.exports = parent;
