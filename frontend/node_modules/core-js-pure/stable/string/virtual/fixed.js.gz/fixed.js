'use strict';
var parent = require('../../../es/string/virtual/fixed');

module.exports = parent;
