'use strict';
var parent = require('../../../es/string/virtual/is-well-formed');

module.exports = parent;
