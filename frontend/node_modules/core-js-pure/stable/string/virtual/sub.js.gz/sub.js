'use strict';
var parent = require('../../../es/string/virtual/sub');

module.exports = parent;
