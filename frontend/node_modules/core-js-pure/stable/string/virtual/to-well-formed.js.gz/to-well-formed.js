'use strict';
var parent = require('../../../es/string/virtual/to-well-formed');

module.exports = parent;
