'use strict';
var parent = require('../../../es/string/virtual/trim-start');

module.exports = parent;
