'use strict';
var parent = require('../../es/symbol/description');

module.exports = parent;
