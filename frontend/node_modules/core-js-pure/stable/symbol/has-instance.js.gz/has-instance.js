'use strict';
var parent = require('../../es/symbol/has-instance');

module.exports = parent;
