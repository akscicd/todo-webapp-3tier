'use strict';
var parent = require('../../es/symbol/match-all');

module.exports = parent;
