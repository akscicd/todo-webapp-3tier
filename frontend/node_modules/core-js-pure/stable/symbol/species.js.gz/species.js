'use strict';
var parent = require('../../es/symbol/species');

module.exports = parent;
