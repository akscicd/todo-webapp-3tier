'use strict';
var parent = require('../../es/symbol/split');

module.exports = parent;
