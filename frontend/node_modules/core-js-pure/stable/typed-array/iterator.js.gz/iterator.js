'use strict';
var parent = require('../../es/typed-array/iterator');

module.exports = parent;
