'use strict';
var parent = require('../../es/typed-array/last-index-of');

module.exports = parent;
