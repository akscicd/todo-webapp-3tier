'use strict';
var parent = require('../../es/typed-array/of');

module.exports = parent;
