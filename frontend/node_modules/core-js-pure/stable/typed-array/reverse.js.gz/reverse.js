'use strict';
var parent = require('../../es/typed-array/reverse');

module.exports = parent;
