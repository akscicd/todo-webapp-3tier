'use strict';
var parent = require('../../es/typed-array/slice');

module.exports = parent;
