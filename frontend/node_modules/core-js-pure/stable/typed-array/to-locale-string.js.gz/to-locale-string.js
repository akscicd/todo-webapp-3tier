'use strict';
var parent = require('../../es/typed-array/to-locale-string');

module.exports = parent;
