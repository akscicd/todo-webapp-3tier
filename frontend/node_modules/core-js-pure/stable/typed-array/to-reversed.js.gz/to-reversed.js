'use strict';
var parent = require('../../es/typed-array/to-reversed');

module.exports = parent;
