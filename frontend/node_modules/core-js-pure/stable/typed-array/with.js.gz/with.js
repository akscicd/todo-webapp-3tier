'use strict';
var parent = require('../../es/typed-array/with');

module.exports = parent;
