'use strict';
var parent = require('../es/unescape');

module.exports = parent;
