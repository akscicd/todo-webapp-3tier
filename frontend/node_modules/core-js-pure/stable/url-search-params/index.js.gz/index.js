'use strict';
var parent = require('../../web/url-search-params');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
