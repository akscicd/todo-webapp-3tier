'use strict';
var parent = require('../../web/url');

module.exports = parent;
