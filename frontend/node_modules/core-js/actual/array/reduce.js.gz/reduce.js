'use strict';
var parent = require('../../stable/array/reduce');

module.exports = parent;
