'use strict';
var parent = require('../stable/atob');

module.exports = parent;
