'use strict';
require('../../modules/esnext.function.metadata');

module.exports = null;
