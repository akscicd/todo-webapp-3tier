'use strict';
var parent = require('../../stable/instance/pad-start');

module.exports = parent;
