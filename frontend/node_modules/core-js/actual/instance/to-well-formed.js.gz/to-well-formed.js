'use strict';
var parent = require('../../stable/instance/to-well-formed');

module.exports = parent;
