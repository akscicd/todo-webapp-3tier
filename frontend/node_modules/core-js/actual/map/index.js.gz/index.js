'use strict';
var parent = require('../../stable/map');
require('../../modules/esnext.map.group-by');

module.exports = parent;
