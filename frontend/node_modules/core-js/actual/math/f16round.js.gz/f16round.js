'use strict';
require('../../modules/esnext.math.f16round');
var path = require('../../internals/path');

module.exports = path.Math.f16round;
