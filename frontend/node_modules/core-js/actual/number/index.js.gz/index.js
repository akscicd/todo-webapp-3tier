'use strict';
var parent = require('../../stable/number');

module.exports = parent;
