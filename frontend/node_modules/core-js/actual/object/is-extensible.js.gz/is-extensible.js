'use strict';
var parent = require('../../stable/object/is-extensible');

module.exports = parent;
