'use strict';
var parent = require('../../stable/regexp/match');

module.exports = parent;
