'use strict';
var parent = require('../../../stable/string/virtual/trim');

module.exports = parent;
