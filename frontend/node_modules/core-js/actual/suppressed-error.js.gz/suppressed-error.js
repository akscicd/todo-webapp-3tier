'use strict';
require('../modules/es.error.cause');
require('../modules/es.error.to-string');
require('../modules/esnext.suppressed-error.constructor');
var path = require('../internals/path');

module.exports = path.SuppressedError;
