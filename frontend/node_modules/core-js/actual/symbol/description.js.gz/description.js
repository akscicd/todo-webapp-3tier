'use strict';
var parent = require('../../stable/symbol/description');

module.exports = parent;
