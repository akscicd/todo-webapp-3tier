'use strict';
var parent = require('../../stable/symbol/to-primitive');

module.exports = parent;
