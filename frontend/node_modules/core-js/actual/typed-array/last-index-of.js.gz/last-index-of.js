'use strict';
var parent = require('../../stable/typed-array/last-index-of');

module.exports = parent;
