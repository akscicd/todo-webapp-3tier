'use strict';
// TODO: Remove from `core-js@4`
require('../../modules/esnext.typed-array.to-spliced');
