'use strict';
require('../../modules/es.array.concat');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'concat');
