'use strict';
require('../../modules/es.array.slice');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'slice');
