'use strict';
require('../../../modules/es.array.index-of');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Array', 'indexOf');
