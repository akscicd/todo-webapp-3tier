'use strict';
require('../../modules/es.math.imul');
var path = require('../../internals/path');

module.exports = path.Math.imul;
