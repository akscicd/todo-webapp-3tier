'use strict';
require('../../modules/es.math.sinh');
var path = require('../../internals/path');

module.exports = path.Math.sinh;
