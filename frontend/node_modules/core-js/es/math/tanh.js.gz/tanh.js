'use strict';
require('../../modules/es.math.tanh');
var path = require('../../internals/path');

module.exports = path.Math.tanh;
