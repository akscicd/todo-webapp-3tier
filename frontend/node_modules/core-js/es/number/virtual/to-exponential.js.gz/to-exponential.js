'use strict';
require('../../../modules/es.number.to-exponential');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Number', 'toExponential');
