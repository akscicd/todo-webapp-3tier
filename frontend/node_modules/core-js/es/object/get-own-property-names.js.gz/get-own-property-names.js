'use strict';
require('../../modules/es.object.get-own-property-names');
var path = require('../../internals/path');

var Object = path.Object;

module.exports = function getOwnPropertyNames(it) {
  return Object.getOwnPropertyNames(it);
};
