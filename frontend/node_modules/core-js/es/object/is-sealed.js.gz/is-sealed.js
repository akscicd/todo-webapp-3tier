'use strict';
require('../../modules/es.object.is-sealed');
var path = require('../../internals/path');

module.exports = path.Object.isSealed;
