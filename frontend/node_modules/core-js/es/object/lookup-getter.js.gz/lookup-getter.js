'use strict';
require('../../modules/es.object.lookup-getter');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Object', '__lookupGetter__');
