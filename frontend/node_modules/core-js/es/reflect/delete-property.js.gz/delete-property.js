'use strict';
require('../../modules/es.reflect.delete-property');
var path = require('../../internals/path');

module.exports = path.Reflect.deleteProperty;
