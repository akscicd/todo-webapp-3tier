'use strict';
require('../../modules/es.string.at-alternative');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'at');
