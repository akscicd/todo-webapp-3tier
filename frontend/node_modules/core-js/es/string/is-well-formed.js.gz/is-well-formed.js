'use strict';
require('../../modules/es.string.is-well-formed');

module.exports = require('../../internals/entry-unbind')('String', 'isWellFormed');
