'use strict';
require('../../modules/es.string.substr');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'substr');
