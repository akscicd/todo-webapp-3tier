'use strict';
require('../../modules/es.regexp.exec');
require('../../modules/es.symbol.replace');
require('../../modules/es.string.replace');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('replace');
