'use strict';
require('../../modules/es.regexp.exec');
require('../../modules/es.symbol.split');
require('../../modules/es.string.split');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('split');
