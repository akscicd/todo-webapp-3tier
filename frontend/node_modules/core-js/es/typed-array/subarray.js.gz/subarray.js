'use strict';
require('../../modules/es.typed-array.subarray');
