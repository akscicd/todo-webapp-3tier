'use strict';
module.exports = require('../../full/array-buffer/transfer-to-fixed-length');
