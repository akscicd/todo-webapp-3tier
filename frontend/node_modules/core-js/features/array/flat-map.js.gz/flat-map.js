'use strict';
module.exports = require('../../full/array/flat-map');
