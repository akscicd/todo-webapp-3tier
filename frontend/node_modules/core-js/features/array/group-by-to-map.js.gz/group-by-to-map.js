'use strict';
module.exports = require('../../full/array/group-by-to-map');
