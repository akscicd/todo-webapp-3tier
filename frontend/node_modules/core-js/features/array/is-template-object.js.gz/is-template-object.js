'use strict';
module.exports = require('../../full/array/is-template-object');
