'use strict';
module.exports = require('../../full/array/of');
