'use strict';
module.exports = require('../../../full/array/virtual/copy-within');
