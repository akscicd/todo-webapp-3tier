'use strict';
module.exports = require('../../../full/array/virtual/index-of');
