'use strict';
module.exports = require('../../full/async-disposable-stack/constructor');
