'use strict';
module.exports = require('../../full/async-iterator/as-indexed-pairs');
