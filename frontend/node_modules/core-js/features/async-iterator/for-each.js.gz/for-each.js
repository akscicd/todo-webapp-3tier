'use strict';
module.exports = require('../../full/async-iterator/for-each');
