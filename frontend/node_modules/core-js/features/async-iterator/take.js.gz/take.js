'use strict';
module.exports = require('../../full/async-iterator/take');
