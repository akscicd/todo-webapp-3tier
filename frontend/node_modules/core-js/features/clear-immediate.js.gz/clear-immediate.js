'use strict';
module.exports = require('../full/clear-immediate');
