'use strict';
module.exports = require('../../full/data-view/set-float16');
