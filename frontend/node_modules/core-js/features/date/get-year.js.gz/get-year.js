'use strict';
module.exports = require('../../full/date/get-year');
