'use strict';
module.exports = require('../../full/disposable-stack/constructor');
