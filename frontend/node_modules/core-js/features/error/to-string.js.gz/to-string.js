'use strict';
module.exports = require('../../full/error/to-string');
