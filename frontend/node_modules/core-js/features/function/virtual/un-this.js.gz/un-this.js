'use strict';
module.exports = require('../../../full/function/virtual/un-this');
