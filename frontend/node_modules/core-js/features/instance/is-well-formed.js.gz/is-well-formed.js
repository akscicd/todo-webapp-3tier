'use strict';
module.exports = require('../../full/instance/is-well-formed');
