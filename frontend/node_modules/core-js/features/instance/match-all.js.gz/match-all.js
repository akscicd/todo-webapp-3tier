'use strict';
module.exports = require('../../full/instance/match-all');
