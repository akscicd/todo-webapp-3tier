'use strict';
module.exports = require('../../full/instance/replace-all');
