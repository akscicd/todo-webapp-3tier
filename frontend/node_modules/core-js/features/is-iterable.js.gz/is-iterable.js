'use strict';
module.exports = require('../full/is-iterable');
