'use strict';
module.exports = require('../../full/iterator/as-indexed-pairs');
