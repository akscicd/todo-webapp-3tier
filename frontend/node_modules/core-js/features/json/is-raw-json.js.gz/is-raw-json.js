'use strict';
module.exports = require('../../full/json/is-raw-json');
