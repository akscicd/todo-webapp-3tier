'use strict';
module.exports = require('../../full/json/parse');
