'use strict';
module.exports = require('../../full/map/update');
