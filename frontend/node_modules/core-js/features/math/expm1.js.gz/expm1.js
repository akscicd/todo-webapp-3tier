'use strict';
module.exports = require('../../full/math/expm1');
