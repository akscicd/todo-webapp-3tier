'use strict';
module.exports = require('../../full/math/log2');
