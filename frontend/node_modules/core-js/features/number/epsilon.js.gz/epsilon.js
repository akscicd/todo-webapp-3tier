'use strict';
module.exports = require('../../full/number/epsilon');
