'use strict';
module.exports = require('../../full/object/entries');
