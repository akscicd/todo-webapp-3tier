'use strict';
module.exports = require('../../full/object/from-entries');
