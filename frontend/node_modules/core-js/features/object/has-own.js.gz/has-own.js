'use strict';
module.exports = require('../../full/object/has-own');
