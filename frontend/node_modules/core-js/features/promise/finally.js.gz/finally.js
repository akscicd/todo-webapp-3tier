'use strict';
module.exports = require('../../full/promise/finally');
