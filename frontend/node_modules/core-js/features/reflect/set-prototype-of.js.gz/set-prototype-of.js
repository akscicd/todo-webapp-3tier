'use strict';
module.exports = require('../../full/reflect/set-prototype-of');
