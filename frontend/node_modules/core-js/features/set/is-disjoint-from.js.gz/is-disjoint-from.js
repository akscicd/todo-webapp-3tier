'use strict';
module.exports = require('../../full/set/is-disjoint-from');
