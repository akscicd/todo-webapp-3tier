'use strict';
module.exports = require('../../full/set/reduce');
