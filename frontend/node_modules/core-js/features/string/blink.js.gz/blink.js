'use strict';
module.exports = require('../../full/string/blink');
