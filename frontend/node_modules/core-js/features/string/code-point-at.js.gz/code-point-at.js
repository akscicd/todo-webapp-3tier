'use strict';
module.exports = require('../../full/string/code-point-at');
