'use strict';
module.exports = require('../../full/string/is-well-formed');
