'use strict';
module.exports = require('../../full/string/replace-all');
