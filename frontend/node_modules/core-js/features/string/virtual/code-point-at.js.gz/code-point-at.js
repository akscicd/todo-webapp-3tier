'use strict';
module.exports = require('../../../full/string/virtual/code-point-at');
