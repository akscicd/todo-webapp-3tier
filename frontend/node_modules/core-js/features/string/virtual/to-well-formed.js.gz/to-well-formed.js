'use strict';
module.exports = require('../../../full/string/virtual/to-well-formed');
