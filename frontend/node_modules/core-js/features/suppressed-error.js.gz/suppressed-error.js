'use strict';
module.exports = require('../full/suppressed-error');
