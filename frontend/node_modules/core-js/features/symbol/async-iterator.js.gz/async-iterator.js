'use strict';
module.exports = require('../../full/symbol/async-iterator');
