'use strict';
module.exports = require('../../full/symbol/description');
