'use strict';
module.exports = require('../../full/typed-array/every');
