'use strict';
module.exports = require('../../full/weak-set/of');
