'use strict';
var parent = require('../../actual/array-buffer');

module.exports = parent;
