'use strict';
var parent = require('../../actual/array/find-last-index');

module.exports = parent;
