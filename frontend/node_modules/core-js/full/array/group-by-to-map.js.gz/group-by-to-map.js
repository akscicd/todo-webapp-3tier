'use strict';
var parent = require('../../actual/array/group-by-to-map');

module.exports = parent;
