'use strict';
var parent = require('../../actual/array/iterator');

module.exports = parent;
