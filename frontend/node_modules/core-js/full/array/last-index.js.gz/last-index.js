'use strict';
require('../../modules/esnext.array.last-index');
