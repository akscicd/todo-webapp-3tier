'use strict';
var parent = require('../../actual/array/sort');

module.exports = parent;
