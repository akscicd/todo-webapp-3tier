'use strict';
var parent = require('../../actual/array/to-reversed');

module.exports = parent;
