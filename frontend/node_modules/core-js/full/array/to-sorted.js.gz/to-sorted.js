'use strict';
var parent = require('../../actual/array/to-sorted');

module.exports = parent;
