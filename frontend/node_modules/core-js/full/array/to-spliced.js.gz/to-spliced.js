'use strict';
var parent = require('../../actual/array/to-spliced');

module.exports = parent;
