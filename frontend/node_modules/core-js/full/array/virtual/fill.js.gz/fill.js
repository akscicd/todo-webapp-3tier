'use strict';
var parent = require('../../../actual/array/virtual/fill');

module.exports = parent;
