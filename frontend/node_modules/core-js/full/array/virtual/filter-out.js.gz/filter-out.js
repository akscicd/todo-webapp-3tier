'use strict';
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.array.filter-out');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Array', 'filterOut');
