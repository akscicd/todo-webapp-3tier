'use strict';
require('../../../modules/esnext.array.filter-reject');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Array', 'filterReject');
