'use strict';
var parent = require('../../../actual/array/virtual/push');

module.exports = parent;
