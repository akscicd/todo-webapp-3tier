'use strict';
var parent = require('../../../actual/array/virtual/to-sorted');

module.exports = parent;
