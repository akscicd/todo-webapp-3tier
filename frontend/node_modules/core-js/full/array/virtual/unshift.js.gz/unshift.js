'use strict';
var parent = require('../../../actual/array/virtual/unshift');

module.exports = parent;
