'use strict';
var parent = require('../../actual/async-iterator/async-dispose');

module.exports = parent;
