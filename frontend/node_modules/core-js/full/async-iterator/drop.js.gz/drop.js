'use strict';
var parent = require('../../actual/async-iterator/drop');

module.exports = parent;
