'use strict';
var parent = require('../../actual/async-iterator/filter');

module.exports = parent;
