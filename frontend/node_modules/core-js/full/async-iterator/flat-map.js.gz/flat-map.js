'use strict';
var parent = require('../../actual/async-iterator/flat-map');

module.exports = parent;
