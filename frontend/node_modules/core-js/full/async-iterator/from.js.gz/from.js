'use strict';
var parent = require('../../actual/async-iterator/from');

module.exports = parent;
