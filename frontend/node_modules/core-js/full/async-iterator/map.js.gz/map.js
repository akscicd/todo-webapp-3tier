'use strict';
var parent = require('../../actual/async-iterator/map');

module.exports = parent;
