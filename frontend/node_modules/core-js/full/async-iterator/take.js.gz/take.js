'use strict';
var parent = require('../../actual/async-iterator/take');

module.exports = parent;
