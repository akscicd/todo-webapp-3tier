'use strict';
require('../../modules/esnext.data-view.get-uint8-clamped');
