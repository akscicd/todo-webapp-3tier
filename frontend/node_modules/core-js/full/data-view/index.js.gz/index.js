'use strict';
var parent = require('../../actual/data-view');
require('../../modules/esnext.data-view.get-uint8-clamped');
require('../../modules/esnext.data-view.set-uint8-clamped');

module.exports = parent;
