'use strict';
var parent = require('../../actual/date/to-json');

module.exports = parent;
