'use strict';
var parent = require('../../actual/disposable-stack/constructor');

module.exports = parent;
