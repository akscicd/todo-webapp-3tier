'use strict';
var parent = require('../../actual/error/constructor');

module.exports = parent;
