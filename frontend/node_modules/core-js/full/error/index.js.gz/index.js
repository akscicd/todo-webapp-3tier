'use strict';
var parent = require('../../actual/error');

module.exports = parent;
