'use strict';
var parent = require('../../actual/error/to-string');

module.exports = parent;
