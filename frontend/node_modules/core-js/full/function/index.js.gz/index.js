'use strict';
var parent = require('../../actual/function');
require('../../modules/esnext.function.demethodize');
require('../../modules/esnext.function.is-callable');
require('../../modules/esnext.function.is-constructor');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.function.un-this');

module.exports = parent;
