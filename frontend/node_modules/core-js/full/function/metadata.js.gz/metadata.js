'use strict';
var parent = require('../../actual/function/metadata');

module.exports = parent;
