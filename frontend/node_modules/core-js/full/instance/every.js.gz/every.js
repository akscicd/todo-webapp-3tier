'use strict';
var parent = require('../../actual/instance/every');

module.exports = parent;
