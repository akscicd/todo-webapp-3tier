'use strict';
var parent = require('../../actual/instance/flags');

module.exports = parent;
