'use strict';
var parent = require('../../actual/instance/flat-map');

module.exports = parent;
