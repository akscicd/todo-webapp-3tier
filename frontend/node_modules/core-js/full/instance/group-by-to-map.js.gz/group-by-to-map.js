'use strict';
var parent = require('../../actual/instance/group-by-to-map');

module.exports = parent;
