'use strict';
var parent = require('../../actual/instance/to-reversed');

module.exports = parent;
