'use strict';
var parent = require('../../actual/instance/to-spliced');

module.exports = parent;
