'use strict';
var parent = require('../../actual/instance/trim-end');

module.exports = parent;
