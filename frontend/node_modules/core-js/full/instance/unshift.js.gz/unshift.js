'use strict';
var parent = require('../../actual/instance/unshift');

module.exports = parent;
