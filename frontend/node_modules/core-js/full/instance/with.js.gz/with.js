'use strict';
var parent = require('../../actual/instance/with');

module.exports = parent;
