'use strict';
var parent = require('../../actual/iterator/dispose');

module.exports = parent;
