'use strict';
var parent = require('../../actual/iterator/flat-map');

module.exports = parent;
