'use strict';
var parent = require('../../actual/iterator/for-each');

module.exports = parent;
