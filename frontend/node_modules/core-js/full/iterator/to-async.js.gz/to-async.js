'use strict';
var parent = require('../../actual/iterator/to-async');

module.exports = parent;
