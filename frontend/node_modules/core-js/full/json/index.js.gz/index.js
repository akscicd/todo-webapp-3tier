'use strict';
var parent = require('../../actual/json');

module.exports = parent;
