'use strict';
var parent = require('../../actual/json/parse');

module.exports = parent;
