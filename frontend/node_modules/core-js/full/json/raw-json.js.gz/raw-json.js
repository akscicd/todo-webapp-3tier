'use strict';
var parent = require('../../actual/json/raw-json');

module.exports = parent;
