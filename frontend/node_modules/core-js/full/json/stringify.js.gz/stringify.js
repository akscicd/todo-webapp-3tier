'use strict';
var parent = require('../../actual/json/stringify');

module.exports = parent;
