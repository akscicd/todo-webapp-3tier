'use strict';
var parent = require('../../actual/map/group-by');

module.exports = parent;
