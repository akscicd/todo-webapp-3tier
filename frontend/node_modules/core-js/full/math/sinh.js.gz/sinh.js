'use strict';
var parent = require('../../actual/math/sinh');

module.exports = parent;
