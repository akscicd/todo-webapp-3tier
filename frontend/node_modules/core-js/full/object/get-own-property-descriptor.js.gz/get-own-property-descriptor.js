'use strict';
var parent = require('../../actual/object/get-own-property-descriptor');

module.exports = parent;
