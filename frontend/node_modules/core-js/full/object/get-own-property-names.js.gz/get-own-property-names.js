'use strict';
var parent = require('../../actual/object/get-own-property-names');

module.exports = parent;
