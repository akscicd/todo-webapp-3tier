'use strict';
var parent = require('../../actual/object/group-by');

module.exports = parent;
