'use strict';
var parent = require('../../actual/object/seal');

module.exports = parent;
