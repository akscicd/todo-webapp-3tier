'use strict';
var parent = require('../../actual/object/to-string');

module.exports = parent;
