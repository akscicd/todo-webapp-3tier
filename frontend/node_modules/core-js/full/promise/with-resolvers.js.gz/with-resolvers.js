'use strict';
var parent = require('../../actual/promise/with-resolvers');

module.exports = parent;
