'use strict';
require('../../modules/esnext.reflect.metadata');
var path = require('../../internals/path');

module.exports = path.Reflect.metadata;
