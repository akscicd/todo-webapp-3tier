'use strict';
var parent = require('../../actual/reflect/own-keys');

module.exports = parent;
