'use strict';
var parent = require('../../actual/reflect/prevent-extensions');

module.exports = parent;
