'use strict';
var parent = require('../../actual/regexp/constructor');

module.exports = parent;
