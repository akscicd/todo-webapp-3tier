'use strict';
var parent = require('../actual/self');

module.exports = parent;
