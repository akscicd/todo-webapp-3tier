'use strict';
var parent = require('../../actual/string/anchor');

module.exports = parent;
