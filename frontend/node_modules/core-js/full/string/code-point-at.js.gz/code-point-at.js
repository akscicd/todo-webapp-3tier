'use strict';
var parent = require('../../actual/string/code-point-at');

module.exports = parent;
