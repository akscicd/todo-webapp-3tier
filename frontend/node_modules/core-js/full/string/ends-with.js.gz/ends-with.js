'use strict';
var parent = require('../../actual/string/ends-with');

module.exports = parent;
