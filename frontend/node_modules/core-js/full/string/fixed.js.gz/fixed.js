'use strict';
var parent = require('../../actual/string/fixed');

module.exports = parent;
