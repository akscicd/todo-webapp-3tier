'use strict';
var parent = require('../../actual/string/fontcolor');

module.exports = parent;
