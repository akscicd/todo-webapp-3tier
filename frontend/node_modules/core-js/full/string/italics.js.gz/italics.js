'use strict';
var parent = require('../../actual/string/italics');

module.exports = parent;
