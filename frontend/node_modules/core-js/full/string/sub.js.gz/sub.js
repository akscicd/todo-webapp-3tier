'use strict';
var parent = require('../../actual/string/sub');

module.exports = parent;
