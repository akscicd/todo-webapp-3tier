'use strict';
require('../../../actual/string/virtual/at');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.string.at');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'at');
