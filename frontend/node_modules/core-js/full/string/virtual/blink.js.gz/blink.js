'use strict';
var parent = require('../../../actual/string/virtual/blink');

module.exports = parent;
