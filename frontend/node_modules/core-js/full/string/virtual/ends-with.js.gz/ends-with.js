'use strict';
var parent = require('../../../actual/string/virtual/ends-with');

module.exports = parent;
