'use strict';
var parent = require('../../../actual/string/virtual/fontcolor');

module.exports = parent;
