'use strict';
var parent = require('../../../actual/string/virtual/is-well-formed');

module.exports = parent;
