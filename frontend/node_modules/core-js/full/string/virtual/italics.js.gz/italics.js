'use strict';
var parent = require('../../../actual/string/virtual/italics');

module.exports = parent;
