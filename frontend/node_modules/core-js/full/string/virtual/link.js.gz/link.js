'use strict';
var parent = require('../../../actual/string/virtual/link');

module.exports = parent;
