'use strict';
var parent = require('../../../actual/string/virtual/strike');

module.exports = parent;
