'use strict';
var parent = require('../../../actual/string/virtual/trim-start');

module.exports = parent;
