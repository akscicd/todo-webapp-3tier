'use strict';
var parent = require('../../actual/symbol/async-iterator');

module.exports = parent;
