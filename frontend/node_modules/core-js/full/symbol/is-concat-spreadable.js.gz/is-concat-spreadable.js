'use strict';
var parent = require('../../actual/symbol/is-concat-spreadable');

module.exports = parent;
