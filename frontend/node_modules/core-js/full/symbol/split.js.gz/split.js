'use strict';
var parent = require('../../actual/symbol/split');

module.exports = parent;
