'use strict';
var parent = require('../../actual/symbol/unscopables');

module.exports = parent;
