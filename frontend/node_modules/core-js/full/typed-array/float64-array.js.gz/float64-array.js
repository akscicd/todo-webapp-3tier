'use strict';
var parent = require('../../actual/typed-array/float64-array');
require('../../full/typed-array/methods');

module.exports = parent;
