'use strict';
var parent = require('../../actual/typed-array/includes');

module.exports = parent;
