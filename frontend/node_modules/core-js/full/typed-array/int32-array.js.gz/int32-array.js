'use strict';
var parent = require('../../actual/typed-array/int32-array');
require('../../full/typed-array/methods');

module.exports = parent;
