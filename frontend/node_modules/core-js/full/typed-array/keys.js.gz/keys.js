'use strict';
var parent = require('../../actual/typed-array/keys');

module.exports = parent;
