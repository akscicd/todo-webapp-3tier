'use strict';
var parent = require('../../actual/typed-array/last-index-of');

module.exports = parent;
