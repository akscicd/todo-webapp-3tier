'use strict';
var parent = require('../../actual/typed-array/to-reversed');

module.exports = parent;
