'use strict';
// TODO: Remove from `core-js@4`
var parent = require('../../actual/typed-array/to-spliced');

module.exports = parent;
