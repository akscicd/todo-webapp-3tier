'use strict';
var parent = require('../../actual/typed-array/with');

module.exports = parent;
