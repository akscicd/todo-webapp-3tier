'use strict';
var parent = require('../../actual/url/can-parse');

module.exports = parent;
