'use strict';
var has = require('../internals/set-helpers').has;

// Perform ? RequireInternalSlot(M, [[SetData]])
module.exports = function (it) {
  has(it);
  return it;
};
