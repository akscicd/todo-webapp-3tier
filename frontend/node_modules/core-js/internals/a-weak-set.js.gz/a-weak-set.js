'use strict';
var has = require('../internals/weak-set-helpers').has;

// Perform ? RequireInternalSlot(M, [[WeakSetData]])
module.exports = function (it) {
  has(it);
  return it;
};
