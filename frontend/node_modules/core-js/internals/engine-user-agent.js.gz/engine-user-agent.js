'use strict';
module.exports = typeof navigator != 'undefined' && String(navigator.userAgent) || '';
