'use strict';
var global = require('../internals/global');

module.exports = function (CONSTRUCTOR) {
  return global[CONSTRUCTOR].prototype;
};
