'use strict';
// https://github.com/tc39/proposal-arraybuffer-transfer
require('../modules/esnext.array-buffer.detached');
require('../modules/esnext.array-buffer.transfer');
require('../modules/esnext.array-buffer.transfer-to-fixed-length');
