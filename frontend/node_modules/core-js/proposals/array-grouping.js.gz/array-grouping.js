'use strict';
// https://github.com/tc39/proposal-array-grouping
require('../modules/esnext.array.group-by');
require('../modules/esnext.array.group-by-to-map');
// TODO: Remove from `core-js@4`
require('../modules/esnext.typed-array.group-by');
