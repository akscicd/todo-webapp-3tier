'use strict';
// https://github.com/tc39/proposal-array-is-template-object
require('../modules/esnext.array.is-template-object');
