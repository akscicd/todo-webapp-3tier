'use strict';
// https://github.com/tc39/proposal-dataview-get-set-uint8clamped
require('../modules/esnext.data-view.get-uint8-clamped');
require('../modules/esnext.data-view.set-uint8-clamped');
