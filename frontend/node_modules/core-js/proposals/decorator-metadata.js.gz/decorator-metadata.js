'use strict';
// TODO: Remove from `core-js@4`
// https://github.com/tc39/proposal-decorator-metadata
require('../modules/esnext.symbol.metadata-key');
