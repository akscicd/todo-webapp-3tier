'use strict';
// TODO: Remove from `core-js@4`
// https://github.com/js-choi/proposal-function-un-this
require('../modules/esnext.function.un-this');
