'use strict';
// TODO: Remove this entry from `core-js@4`
require('../stage');
