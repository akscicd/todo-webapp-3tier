'use strict';
// https://github.com/tc39/proposal-json-parse-with-source
require('../modules/esnext.json.is-raw-json');
require('../modules/esnext.json.parse');
require('../modules/esnext.json.raw-json');
