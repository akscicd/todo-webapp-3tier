'use strict';
// https://github.com/tc39/proposal-object-from-entries
require('../modules/es.object.from-entries');
