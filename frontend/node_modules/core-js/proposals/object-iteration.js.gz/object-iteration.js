'use strict';
// TODO: remove from `core-js@4` as withdrawn
// https://github.com/tc39/proposal-object-iteration
require('../modules/esnext.object.iterate-entries');
require('../modules/esnext.object.iterate-keys');
require('../modules/esnext.object.iterate-values');
