'use strict';
// https://github.com/tc39/proposal-observable
require('../modules/esnext.observable');
require('../modules/esnext.symbol.observable');
