'use strict';
// https://github.com/tc39/proposal-regex-escaping
require('../modules/esnext.regexp.escape');
