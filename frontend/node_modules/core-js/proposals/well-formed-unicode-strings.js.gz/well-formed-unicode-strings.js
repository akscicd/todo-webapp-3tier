'use strict';
require('../modules/esnext.string.is-well-formed');
require('../modules/esnext.string.to-well-formed');
