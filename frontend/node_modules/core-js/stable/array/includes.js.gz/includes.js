'use strict';
var parent = require('../../es/array/includes');

module.exports = parent;
