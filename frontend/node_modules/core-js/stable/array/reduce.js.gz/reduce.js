'use strict';
var parent = require('../../es/array/reduce');

module.exports = parent;
