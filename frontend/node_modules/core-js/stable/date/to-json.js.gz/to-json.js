'use strict';
var parent = require('../../es/date/to-json');

module.exports = parent;
