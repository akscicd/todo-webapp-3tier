'use strict';
var parent = require('../../es/date/to-primitive');

module.exports = parent;
