'use strict';
require('../../modules/web.dom-collections.for-each');

var parent = require('../../internals/array-for-each');

module.exports = parent;
