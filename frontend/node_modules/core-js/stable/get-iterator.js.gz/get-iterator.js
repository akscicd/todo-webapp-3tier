'use strict';
var parent = require('../es/get-iterator');
require('../modules/web.dom-collections.iterator');

module.exports = parent;
