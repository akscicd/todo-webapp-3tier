'use strict';
var parent = require('../../es/instance/at');

module.exports = parent;
