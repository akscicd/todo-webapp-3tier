'use strict';
var parent = require('../../es/instance/code-point-at');

module.exports = parent;
