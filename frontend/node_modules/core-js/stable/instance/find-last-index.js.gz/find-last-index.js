'use strict';
var parent = require('../../es/instance/find-last-index');

module.exports = parent;
