'use strict';
var parent = require('../../es/instance/is-well-formed');

module.exports = parent;
