'use strict';
var parent = require('../../es/instance/pad-end');

module.exports = parent;
