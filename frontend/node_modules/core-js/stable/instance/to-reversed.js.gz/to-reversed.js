'use strict';
var parent = require('../../es/instance/to-reversed');

module.exports = parent;
