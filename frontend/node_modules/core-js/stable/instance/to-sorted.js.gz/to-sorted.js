'use strict';
var parent = require('../../es/instance/to-sorted');

module.exports = parent;
