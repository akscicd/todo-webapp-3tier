'use strict';
var parent = require('../../es/map');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
