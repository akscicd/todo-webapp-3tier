'use strict';
var parent = require('../../es/math/atanh');

module.exports = parent;
