'use strict';
var parent = require('../../es/math/sinh');

module.exports = parent;
