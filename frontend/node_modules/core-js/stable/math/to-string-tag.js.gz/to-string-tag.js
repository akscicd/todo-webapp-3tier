'use strict';
var parent = require('../../es/math/to-string-tag');

module.exports = parent;
