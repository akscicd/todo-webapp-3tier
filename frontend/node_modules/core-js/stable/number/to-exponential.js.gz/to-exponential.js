'use strict';
var parent = require('../../es/number/to-exponential');

module.exports = parent;
