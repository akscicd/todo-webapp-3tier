'use strict';
var parent = require('../../es/object/lookup-getter');

module.exports = parent;
