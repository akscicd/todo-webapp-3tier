'use strict';
var parent = require('../../es/object/prevent-extensions');

module.exports = parent;
