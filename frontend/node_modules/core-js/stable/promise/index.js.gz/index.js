'use strict';
var parent = require('../../es/promise');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
