'use strict';
var parent = require('../../es/reflect/get-prototype-of');

module.exports = parent;
