'use strict';
var parent = require('../../es/reflect/has');

module.exports = parent;
