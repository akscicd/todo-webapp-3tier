'use strict';
var parent = require('../../es/regexp/test');

module.exports = parent;
