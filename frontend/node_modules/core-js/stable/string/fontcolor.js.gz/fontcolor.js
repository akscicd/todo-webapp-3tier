'use strict';
var parent = require('../../es/string/fontcolor');

module.exports = parent;
