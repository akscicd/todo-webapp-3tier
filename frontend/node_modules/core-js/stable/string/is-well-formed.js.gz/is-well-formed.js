'use strict';
var parent = require('../../es/string/is-well-formed');

module.exports = parent;
