'use strict';
var parent = require('../../es/string/link');

module.exports = parent;
