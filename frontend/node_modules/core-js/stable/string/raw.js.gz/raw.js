'use strict';
var parent = require('../../es/string/raw');

module.exports = parent;
