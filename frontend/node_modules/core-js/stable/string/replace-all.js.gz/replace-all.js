'use strict';
var parent = require('../../es/string/replace-all');

module.exports = parent;
