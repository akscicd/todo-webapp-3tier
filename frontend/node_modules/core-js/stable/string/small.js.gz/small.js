'use strict';
var parent = require('../../es/string/small');

module.exports = parent;
