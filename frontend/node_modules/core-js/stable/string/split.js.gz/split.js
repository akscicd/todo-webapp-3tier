'use strict';
var parent = require('../../es/string/split');

module.exports = parent;
