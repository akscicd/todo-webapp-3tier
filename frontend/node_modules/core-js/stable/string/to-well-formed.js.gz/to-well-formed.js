'use strict';
var parent = require('../../es/string/to-well-formed');

module.exports = parent;
