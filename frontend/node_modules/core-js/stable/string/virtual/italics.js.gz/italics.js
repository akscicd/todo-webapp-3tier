'use strict';
var parent = require('../../../es/string/virtual/italics');

module.exports = parent;
