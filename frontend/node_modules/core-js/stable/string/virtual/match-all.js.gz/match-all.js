'use strict';
var parent = require('../../../es/string/virtual/match-all');

module.exports = parent;
