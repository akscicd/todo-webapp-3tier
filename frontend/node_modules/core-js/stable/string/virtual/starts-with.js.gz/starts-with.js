'use strict';
var parent = require('../../../es/string/virtual/starts-with');

module.exports = parent;
