'use strict';
var parent = require('../../../es/string/virtual/sup');

module.exports = parent;
