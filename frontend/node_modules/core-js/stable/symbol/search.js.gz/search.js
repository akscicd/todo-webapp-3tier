'use strict';
var parent = require('../../es/symbol/search');

module.exports = parent;
