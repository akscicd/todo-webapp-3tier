'use strict';
var parent = require('../../es/symbol/to-string-tag');

module.exports = parent;
