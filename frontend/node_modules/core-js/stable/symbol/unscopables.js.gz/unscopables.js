'use strict';
var parent = require('../../es/symbol/unscopables');

module.exports = parent;
