'use strict';
var parent = require('../../es/typed-array/entries');

module.exports = parent;
