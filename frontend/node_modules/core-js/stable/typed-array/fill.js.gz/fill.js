'use strict';
var parent = require('../../es/typed-array/fill');

module.exports = parent;
