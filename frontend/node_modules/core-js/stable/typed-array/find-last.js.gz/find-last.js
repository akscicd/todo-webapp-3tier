'use strict';
module.exports = require('../../es/typed-array/find-last');
