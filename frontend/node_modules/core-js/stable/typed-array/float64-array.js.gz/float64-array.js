'use strict';
var parent = require('../../es/typed-array/float64-array');
require('../../stable/typed-array/methods');

module.exports = parent;
