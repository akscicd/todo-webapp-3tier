'use strict';
var parent = require('../../es/typed-array/for-each');

module.exports = parent;
