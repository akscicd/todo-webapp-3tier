'use strict';
var parent = require('../../es/typed-array/from');

module.exports = parent;
