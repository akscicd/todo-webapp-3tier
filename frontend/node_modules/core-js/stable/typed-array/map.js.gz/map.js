'use strict';
var parent = require('../../es/typed-array/map');

module.exports = parent;
