'use strict';
var parent = require('../../es/typed-array/reduce');

module.exports = parent;
