'use strict';
var parent = require('../../es/typed-array/some');

module.exports = parent;
