This folder contains entry points for features from [WHATWG / W3C](https://github.com/zloirock/core-js#web-standards) with dependencies.
