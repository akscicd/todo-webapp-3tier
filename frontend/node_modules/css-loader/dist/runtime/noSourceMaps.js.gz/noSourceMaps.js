"use strict";

module.exports = function (i) {
  return i[1];
};