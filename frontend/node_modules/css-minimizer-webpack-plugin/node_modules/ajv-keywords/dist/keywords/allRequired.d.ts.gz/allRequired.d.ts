import type { Plugin } from "ajv";
declare const allRequired: Plugin<undefined>;
export default allRequired;
