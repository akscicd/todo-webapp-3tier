import type { Plugin } from "ajv";
declare const exclusiveRange: Plugin<undefined>;
export default exclusiveRange;
