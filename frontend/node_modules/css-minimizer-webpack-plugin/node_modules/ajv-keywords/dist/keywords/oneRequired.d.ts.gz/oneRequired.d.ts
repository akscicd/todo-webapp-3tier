import type { Plugin } from "ajv";
declare const oneRequired: Plugin<undefined>;
export default oneRequired;
