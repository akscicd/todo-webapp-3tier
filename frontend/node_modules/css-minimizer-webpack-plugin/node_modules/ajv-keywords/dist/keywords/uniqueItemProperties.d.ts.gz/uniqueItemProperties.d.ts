import type { Plugin } from "ajv";
declare const uniqueItemProperties: Plugin<undefined>;
export default uniqueItemProperties;
