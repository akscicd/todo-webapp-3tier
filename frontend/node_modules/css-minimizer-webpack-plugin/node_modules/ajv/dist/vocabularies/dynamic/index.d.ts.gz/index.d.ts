import type { Vocabulary } from "../../types";
declare const dynamic: Vocabulary;
export default dynamic;
