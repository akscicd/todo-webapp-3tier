module.exports = require('./syntax');
