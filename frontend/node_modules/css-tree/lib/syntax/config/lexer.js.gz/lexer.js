var data = require('../../../data');

module.exports = {
    generic: true,
    types: data.types,
    properties: data.properties,
    node: require('../node')
};
