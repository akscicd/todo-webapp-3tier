var data = require('../../../data');

module.exports = {
    generic: true,
    types: data.types,
    atrules: data.atrules,
    properties: data.properties,
    node: require('../node')
};
