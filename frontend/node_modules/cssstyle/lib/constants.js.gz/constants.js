'use strict';

module.exports.POSITION_AT_SHORTHAND = {
  first: 0,
  second: 1,
};
