import { ComputeTextAlternativeOptions } from "./accessible-name-and-description";
/**
 * @param root
 * @param options
 * @returns
 */
export declare function computeAccessibleDescription(root: Element, options?: ComputeTextAlternativeOptions): string;
//# sourceMappingURL=accessible-description.d.ts.map