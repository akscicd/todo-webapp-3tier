export { computeAccessibleDescription } from "./accessible-description.mjs";
export { computeAccessibleName } from "./accessible-name.mjs";
export { default as getRole } from "./getRole.mjs";
export * from "./is-inaccessible.mjs";
//# sourceMappingURL=index.mjs.map