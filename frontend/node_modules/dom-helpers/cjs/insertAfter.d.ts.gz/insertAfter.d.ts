/**
 * Inserts a node after a given reference node.
 *
 * @param node the node to insert
 * @param refNode the reference node
 */
export default function insertAfter(node: Node | null, refNode: Node | null): Node | null;
