export declare const cancel: (id: number) => void;
export declare const request: typeof requestAnimationFrame;
