var toArray = Function.prototype.bind.call(Function.prototype.call, [].slice);
/**
 * Collects all child nodes of an element.
 * 
 * @param node the node
 */

export default function childNodes(node) {
  return node ? toArray(node.childNodes) : [];
}