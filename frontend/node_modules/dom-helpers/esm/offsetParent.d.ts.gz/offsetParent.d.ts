export default function offsetParent(node: HTMLElement): HTMLElement;
