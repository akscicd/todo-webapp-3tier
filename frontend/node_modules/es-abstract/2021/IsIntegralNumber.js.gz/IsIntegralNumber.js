'use strict';

var isInteger = require('../helpers/isInteger');

// https://262.ecma-international.org/12.0/#sec-isinteger

module.exports = function IsIntegralNumber(argument) {
	return isInteger(argument);
};
