'use strict';

// TODO; semver-major: remove

module.exports = require('call-bind/callBound');
