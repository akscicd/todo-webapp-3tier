'use strict';

// TODO: remove, semver-major
module.exports = require('get-symbol-description');
