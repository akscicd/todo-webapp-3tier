'use strict';

module.exports = function isStringOrUndefined(item) {
	return typeof item === 'string' || typeof item === 'undefined';
};
