# es-array-method-boxes-properly

Utility package to determine if an `Array.prototype` method properly boxes the callback's receiver and third argument.
