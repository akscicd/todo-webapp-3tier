'use strict';

var $Iterator = require('../Iterator/polyfill')();

module.exports = $Iterator;
