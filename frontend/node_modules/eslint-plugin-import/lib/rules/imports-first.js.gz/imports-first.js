'use strict';var _docsUrl = require('../docsUrl');var _docsUrl2 = _interopRequireDefault(_docsUrl);function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { 'default': obj };}

var first = require('./first');

var newMeta = Object.assign({},
first.meta, {
  deprecated: true,
  docs: {
    category: 'Style guide',
    description: 'Replaced by `import/first`.',
    url: (0, _docsUrl2['default'])('imports-first', '7b25c1cb95ee18acc1531002fd343e1e6031f9ed') } });



module.exports = Object.assign({}, first, { meta: newMeta });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9ydWxlcy9pbXBvcnRzLWZpcnN0LmpzIl0sIm5hbWVzIjpbImZpcnN0IiwicmVxdWlyZSIsIm5ld01ldGEiLCJtZXRhIiwiZGVwcmVjYXRlZCIsImRvY3MiLCJjYXRlZ29yeSIsImRlc2NyaXB0aW9uIiwidXJsIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6ImFBQUEscUM7O0FBRUEsSUFBTUEsUUFBUUMsUUFBUSxTQUFSLENBQWQ7O0FBRUEsSUFBTUM7QUFDREYsTUFBTUcsSUFETDtBQUVKQyxjQUFZLElBRlI7QUFHSkMsUUFBTTtBQUNKQyxjQUFVLGFBRE47QUFFSkMsaUJBQWEsNkJBRlQ7QUFHSkMsU0FBSywwQkFBUSxlQUFSLEVBQXlCLDBDQUF6QixDQUhELEVBSEYsR0FBTjs7OztBQVVBQyxPQUFPQyxPQUFQLHFCQUFzQlYsS0FBdEIsSUFBNkJHLE1BQU1ELE9BQW5DIiwiZmlsZSI6ImltcG9ydHMtZmlyc3QuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZG9jc1VybCBmcm9tICcuLi9kb2NzVXJsJztcblxuY29uc3QgZmlyc3QgPSByZXF1aXJlKCcuL2ZpcnN0Jyk7XG5cbmNvbnN0IG5ld01ldGEgPSB7XG4gIC4uLmZpcnN0Lm1ldGEsXG4gIGRlcHJlY2F0ZWQ6IHRydWUsXG4gIGRvY3M6IHtcbiAgICBjYXRlZ29yeTogJ1N0eWxlIGd1aWRlJyxcbiAgICBkZXNjcmlwdGlvbjogJ1JlcGxhY2VkIGJ5IGBpbXBvcnQvZmlyc3RgLicsXG4gICAgdXJsOiBkb2NzVXJsKCdpbXBvcnRzLWZpcnN0JywgJzdiMjVjMWNiOTVlZTE4YWNjMTUzMTAwMmZkMzQzZTFlNjAzMWY5ZWQnKSxcbiAgfSxcbn07XG5cbm1vZHVsZS5leHBvcnRzID0geyAuLi5maXJzdCwgbWV0YTogbmV3TWV0YSB9O1xuIl19