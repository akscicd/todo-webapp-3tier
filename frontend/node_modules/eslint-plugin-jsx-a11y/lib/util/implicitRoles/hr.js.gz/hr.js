"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = getImplicitRoleForHr;
/**
 * Returns the implicit role for an hr tag.
 */
function getImplicitRoleForHr() {
  return 'separator';
}
module.exports = exports.default;