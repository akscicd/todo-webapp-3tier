var async = require('./lib/async');
async.sync = require('./lib/sync');

module.exports = async;
