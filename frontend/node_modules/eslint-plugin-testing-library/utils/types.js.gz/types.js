"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUPPORTED_TESTING_FRAMEWORKS = void 0;
exports.SUPPORTED_TESTING_FRAMEWORKS = [
    'dom',
    'angular',
    'react',
    'vue',
    'marko',
];
