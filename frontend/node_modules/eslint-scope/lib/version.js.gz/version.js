const version = "7.2.2";

export default version;
