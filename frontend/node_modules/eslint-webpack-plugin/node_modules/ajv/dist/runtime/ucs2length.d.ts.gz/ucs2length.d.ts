declare function ucs2length(str: string): number;
declare namespace ucs2length {
    var code: string;
}
export default ucs2length;
