"use strict";

const { ESLint } = require("./eslint");
const { FlatESLint } = require("./flat-eslint");

module.exports = {
    ESLint,
    FlatESLint
};
