import { Formatter } from './Formatter';
declare function createWebpackFormatter(formatter: Formatter): Formatter;
export { createWebpackFormatter };
