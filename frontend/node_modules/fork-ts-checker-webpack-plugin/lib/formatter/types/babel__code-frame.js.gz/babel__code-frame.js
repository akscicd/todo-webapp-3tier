"use strict";
// Base on the type definitions for @babel/code-frame 7.0
// Project: https://github.com/babel/babel/tree/main/packages/babel-code-frame, https://babeljs.io
// Definitions by: Mohsen Azimi <https://github.com/mohsen1>
//                 Forbes Lindesay <https://github.com/ForbesLindesay>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
Object.defineProperty(exports, "__esModule", { value: true });
