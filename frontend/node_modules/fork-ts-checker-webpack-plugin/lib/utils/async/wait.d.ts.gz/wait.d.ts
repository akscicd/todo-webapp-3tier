declare function wait(timeout: number): Promise<unknown>;
export default wait;
