"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function wait(timeout) {
    return new Promise((resolve) => setTimeout(resolve, timeout));
}
exports.default = wait;
