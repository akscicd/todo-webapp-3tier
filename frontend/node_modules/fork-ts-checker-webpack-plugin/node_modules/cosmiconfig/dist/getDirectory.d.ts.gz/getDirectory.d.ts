declare function getDirectory(filepath: string): Promise<string>;
declare function getDirectorySync(filepath: string): string;
export { getDirectory, getDirectorySync };
//# sourceMappingURL=getDirectory.d.ts.map