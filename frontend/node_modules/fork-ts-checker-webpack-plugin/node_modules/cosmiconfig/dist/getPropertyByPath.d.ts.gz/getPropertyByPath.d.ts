declare function getPropertyByPath(source: {
    [key: string]: unknown;
}, path: string | Array<string>): unknown;
export { getPropertyByPath };
//# sourceMappingURL=getPropertyByPath.d.ts.map