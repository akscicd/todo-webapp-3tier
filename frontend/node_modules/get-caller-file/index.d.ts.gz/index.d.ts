declare const _default: (position?: number) => any;
export = _default;
