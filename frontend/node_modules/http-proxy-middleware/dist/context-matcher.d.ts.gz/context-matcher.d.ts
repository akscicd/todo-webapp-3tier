import type { Filter, Request } from './types';
export declare function match(context: Filter, uri: string, req: Request): boolean;
