export declare function getTarget(req: any, config: any): Promise<any>;
