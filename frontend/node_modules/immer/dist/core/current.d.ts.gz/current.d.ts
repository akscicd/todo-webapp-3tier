/** Takes a snapshot of the current state of a draft and finalizes it (but without freezing). This is a great utility to print the current state during debugging (no Proxies in the way). The output of current can also be safely leaked outside the producer. */
export declare function current<T>(value: T): T;
//# sourceMappingURL=current.d.ts.map