import { ImmerScope } from "../internal";
export declare function processResult(result: any, scope: ImmerScope): any;
//# sourceMappingURL=finalize.d.ts.map