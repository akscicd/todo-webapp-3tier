export declare function enableAllPlugins(): void;
//# sourceMappingURL=all.d.ts.map