export declare function enablePatches(): void;
//# sourceMappingURL=patches.d.ts.map