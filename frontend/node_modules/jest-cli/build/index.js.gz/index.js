'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});
Object.defineProperty(exports, 'run', {
  enumerable: true,
  get: function () {
    return _cli.run;
  }
});

var _cli = require('./cli');
