/**
 * Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const NO_DIFF_MESSAGE = "Compared values have no visual difference.";
export declare const SIMILAR_MESSAGE: string;
