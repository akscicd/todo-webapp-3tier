'use strict';

var _expect = _interopRequireDefault(require('expect'));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {default: obj};
}
