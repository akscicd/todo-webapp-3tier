"use strict";

exports.implementation = class MimeType {};
