"use strict";

exports.implementation = class NavigatorLanguageImpl {
  get language() {
    return "en-US";
  }

  // See Navigator constructor for languages
};
