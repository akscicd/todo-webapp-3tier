"use strict";

exports.implementation = class NavigatorOnLineImpl {
  get onLine() {
    return true;
  }
};
