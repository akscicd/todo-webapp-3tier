"use strict";

exports.implementation = class Plugin {};
