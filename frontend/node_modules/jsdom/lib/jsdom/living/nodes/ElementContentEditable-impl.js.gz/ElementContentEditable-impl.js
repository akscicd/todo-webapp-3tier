"use strict";

class ElementContentEditableImpl { }

module.exports = {
  implementation: ElementContentEditableImpl
};
