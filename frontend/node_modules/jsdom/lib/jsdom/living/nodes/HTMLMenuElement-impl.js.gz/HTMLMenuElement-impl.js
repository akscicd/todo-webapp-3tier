"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLMenuElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLMenuElementImpl
};
