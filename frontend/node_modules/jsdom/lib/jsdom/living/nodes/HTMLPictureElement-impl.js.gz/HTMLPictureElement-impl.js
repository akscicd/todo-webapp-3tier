"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLPictureElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLPictureElementImpl
};
