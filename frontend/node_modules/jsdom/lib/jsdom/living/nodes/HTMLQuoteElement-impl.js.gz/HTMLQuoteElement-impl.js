"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLQuoteElementImpl extends HTMLElementImpl {}

module.exports = {
  implementation: HTMLQuoteElementImpl
};
