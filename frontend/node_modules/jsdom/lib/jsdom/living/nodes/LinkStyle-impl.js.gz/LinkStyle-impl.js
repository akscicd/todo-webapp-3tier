"use strict";
module.exports = class LinkStyleImpl {};
