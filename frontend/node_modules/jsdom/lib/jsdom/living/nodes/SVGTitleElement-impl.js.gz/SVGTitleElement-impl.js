"use strict";

const SVGElementImpl = require("./SVGElement-impl").implementation;

class SVGTitleElementImpl extends SVGElementImpl { }

module.exports = {
  implementation: SVGTitleElementImpl
};
