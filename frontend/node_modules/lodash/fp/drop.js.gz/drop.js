var convert = require('./convert'),
    func = convert('drop', require('../drop'));

func.placeholder = require('./placeholder');
module.exports = func;
