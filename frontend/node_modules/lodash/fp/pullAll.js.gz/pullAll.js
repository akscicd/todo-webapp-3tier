var convert = require('./convert'),
    func = convert('pullAll', require('../pullAll'));

func.placeholder = require('./placeholder');
module.exports = func;
