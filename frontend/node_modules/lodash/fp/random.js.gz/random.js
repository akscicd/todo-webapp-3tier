var convert = require('./convert'),
    func = convert('random', require('../random'));

func.placeholder = require('./placeholder');
module.exports = func;
