var convert = require('./convert'),
    func = convert('toNumber', require('../toNumber'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
