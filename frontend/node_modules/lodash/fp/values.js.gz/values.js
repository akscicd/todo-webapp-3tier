var convert = require('./convert'),
    func = convert('values', require('../values'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
