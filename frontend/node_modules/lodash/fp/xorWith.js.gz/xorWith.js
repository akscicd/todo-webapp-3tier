var convert = require('./convert'),
    func = convert('xorWith', require('../xorWith'));

func.placeholder = require('./placeholder');
module.exports = func;
