import type { Plugin } from "ajv";
declare const prohibited: Plugin<undefined>;
export default prohibited;
