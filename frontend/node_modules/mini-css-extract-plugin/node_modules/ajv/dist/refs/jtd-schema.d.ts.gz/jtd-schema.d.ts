import { SchemaObject } from "../types";
declare const jtdMetaSchema: SchemaObject;
export default jtdMetaSchema;
