declare function _exports(moduleId: TODO, options: TODO): TODO;
export = _exports;
export type TODO = any;
