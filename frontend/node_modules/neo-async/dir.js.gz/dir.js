'use strict';

module.exports = require('./async').dir;
