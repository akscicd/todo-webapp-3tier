'use strict';

module.exports = require('./async').mapValuesSeries;
