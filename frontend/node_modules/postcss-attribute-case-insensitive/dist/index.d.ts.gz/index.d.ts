import type { PluginCreator } from 'postcss';
declare const creator: PluginCreator<never>;
export default creator;
