import type { Node } from 'postcss';
export declare function hasSupportsAtRuleAncestor(node: Node): boolean;
