import type { PluginCreator } from 'postcss';
/** Transform lab() and lch() functions in CSS. */
declare const postcssPlugin: PluginCreator<{
    preserve: boolean;
}>;
export default postcssPlugin;
