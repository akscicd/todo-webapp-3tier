import type { FunctionNode } from 'postcss-value-parser';
declare function onCSSFunction(node: FunctionNode): void;
export default onCSSFunction;
