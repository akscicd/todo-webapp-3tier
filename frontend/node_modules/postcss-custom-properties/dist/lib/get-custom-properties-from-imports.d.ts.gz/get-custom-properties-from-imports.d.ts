import type { ImportOptions } from './options';
import valuesParser from 'postcss-value-parser';
export default function getCustomPropertiesFromImports(sources: Array<ImportOptions>): Promise<Map<string, valuesParser.ParsedValue>>;
