import type { Container, Declaration } from 'postcss';
declare function isBlockIgnored(container: Container): any;
declare function isDeclarationIgnored(decl: Declaration): boolean;
export { isBlockIgnored, isDeclarationIgnored, };
