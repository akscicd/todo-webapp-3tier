declare const _default: (decl: any, customProperties: any, opts: any) => void;
export default _default;
