export default function transformValueAST(root: any, customProperties: any): any;
