export declare function includesGradientsFunction(str: string): boolean;
export declare function isGradientsFunctions(str: string): boolean;
