export declare function getComma(node: any): boolean;
