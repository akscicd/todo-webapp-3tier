export declare function getImage(node: any): string | false;
