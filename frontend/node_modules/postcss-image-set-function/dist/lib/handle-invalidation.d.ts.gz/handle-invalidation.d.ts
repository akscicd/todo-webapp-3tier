export declare const handleInvalidation: (opts: any, message: any, word: any) => void;
