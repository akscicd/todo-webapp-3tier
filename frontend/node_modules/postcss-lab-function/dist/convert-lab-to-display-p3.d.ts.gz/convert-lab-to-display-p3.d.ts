declare type color = [number, number, number];
export declare function labToDisplayP3(labRaw: color): [color, boolean];
export {};
