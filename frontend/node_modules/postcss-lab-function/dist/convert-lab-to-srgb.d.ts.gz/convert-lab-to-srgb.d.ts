declare type color = [number, number, number];
export declare function labToSRgb(labRaw: color): color;
export {};
