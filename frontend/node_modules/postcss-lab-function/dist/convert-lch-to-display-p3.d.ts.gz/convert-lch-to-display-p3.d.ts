declare type color = [number, number, number];
export declare function lchToDisplayP3(lchRaw: color): [color, boolean];
export {};
