declare type color = [number, number, number];
export declare function lchToSRgb(lchRaw: color): color;
export {};
