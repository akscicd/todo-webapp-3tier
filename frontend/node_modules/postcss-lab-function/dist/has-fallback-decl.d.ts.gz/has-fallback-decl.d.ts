import type { Declaration } from 'postcss';
export declare function hasFallback(node: Declaration): boolean;
