import type { Declaration, Result } from 'postcss';
export declare function modifiedValues(originalValue: string, decl: Declaration, result: Result, preserve: boolean): {
    rgb: string;
    displayP3: string;
} | undefined;
