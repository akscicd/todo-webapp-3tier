import type { Token } from '../parse/cst.js';
export declare function containsNewline(key: Token | null | undefined): boolean | null;
