import type { Token } from '../parse/cst.js';
export declare function emptyScalarPosition(offset: number, before: Token[] | undefined, pos: number | null): number;
