import type { CollectionTag } from '../types.js';
export declare const map: CollectionTag;
