import type { ScalarTag } from '../types.js';
export declare const nullTag: ScalarTag & {
    test: RegExp;
};
