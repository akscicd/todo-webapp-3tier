import type { CollectionTag } from '../types.js';
export declare const seq: CollectionTag;
