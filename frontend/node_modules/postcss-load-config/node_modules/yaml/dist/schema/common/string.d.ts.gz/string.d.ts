import type { ScalarTag } from '../types.js';
export declare const string: ScalarTag;
