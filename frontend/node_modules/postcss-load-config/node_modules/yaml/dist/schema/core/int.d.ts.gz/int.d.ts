import type { ScalarTag } from '../types.js';
export declare const intOct: ScalarTag;
export declare const int: ScalarTag;
export declare const intHex: ScalarTag;
