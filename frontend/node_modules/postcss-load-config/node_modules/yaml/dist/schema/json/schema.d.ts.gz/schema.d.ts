import { CollectionTag, ScalarTag } from '../types.js';
export declare const schema: (CollectionTag | ScalarTag)[];
