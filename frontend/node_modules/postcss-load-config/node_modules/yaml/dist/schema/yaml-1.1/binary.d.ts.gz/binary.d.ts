import type { ScalarTag } from '../types.js';
export declare const binary: ScalarTag;
