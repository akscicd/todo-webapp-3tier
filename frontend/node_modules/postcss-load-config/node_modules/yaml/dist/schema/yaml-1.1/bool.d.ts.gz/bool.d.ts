import type { ScalarTag } from '../types.js';
export declare const trueTag: ScalarTag & {
    test: RegExp;
};
export declare const falseTag: ScalarTag & {
    test: RegExp;
};
