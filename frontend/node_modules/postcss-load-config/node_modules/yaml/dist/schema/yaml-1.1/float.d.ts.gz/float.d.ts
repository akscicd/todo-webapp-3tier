import type { ScalarTag } from '../types.js';
export declare const floatNaN: ScalarTag;
export declare const floatExp: ScalarTag;
export declare const float: ScalarTag;
