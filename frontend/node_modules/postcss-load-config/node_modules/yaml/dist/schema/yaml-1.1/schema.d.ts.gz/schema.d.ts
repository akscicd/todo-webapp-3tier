export declare const schema: (import("../types.js").CollectionTag | import("../types.js").ScalarTag)[];
