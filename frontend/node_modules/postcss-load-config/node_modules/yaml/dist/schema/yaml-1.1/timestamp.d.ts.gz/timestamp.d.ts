import type { ScalarTag } from '../types.js';
export declare const intTime: ScalarTag;
export declare const floatTime: ScalarTag;
export declare const timestamp: ScalarTag & {
    test: RegExp;
};
