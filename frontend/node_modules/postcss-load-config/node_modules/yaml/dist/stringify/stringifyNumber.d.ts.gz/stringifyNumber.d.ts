import type { Scalar } from '../nodes/Scalar.js';
export declare function stringifyNumber({ format, minFractionDigits, tag, value }: Scalar): string;
