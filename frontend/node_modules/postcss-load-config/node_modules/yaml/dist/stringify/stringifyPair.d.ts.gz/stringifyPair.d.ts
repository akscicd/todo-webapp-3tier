import type { Pair } from '../nodes/Pair.js';
import { StringifyContext } from './stringify.js';
export declare function stringifyPair({ key, value }: Readonly<Pair>, ctx: StringifyContext, onComment?: () => void, onChompKeep?: () => void): string;
