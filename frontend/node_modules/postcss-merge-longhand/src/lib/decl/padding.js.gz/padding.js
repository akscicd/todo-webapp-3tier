'use strict';
const base = require('./boxBase');

module.exports = base('padding');
