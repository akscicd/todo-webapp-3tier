'use strict';
/**
 * @param {import('postcss').Declaration} arg
 * @return {string}
 */
module.exports = function getValue({ value }) {
  return value;
};
