import type { AtRule } from 'postcss';
export default function transformAtruleWithinAtrule(node: AtRule, parent: AtRule): void;
export declare function isAtruleWithinAtrule(node: AtRule, parent: AtRule): boolean;
