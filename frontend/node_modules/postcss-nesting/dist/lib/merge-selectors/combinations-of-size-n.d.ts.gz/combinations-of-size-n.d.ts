export declare function combinationsWithSizeN(set: Array<string>, n: number): Array<Array<string>>;
