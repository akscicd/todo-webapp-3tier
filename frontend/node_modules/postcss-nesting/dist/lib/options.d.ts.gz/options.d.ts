export declare type options = {
    noIsPseudoSelector: boolean;
};
