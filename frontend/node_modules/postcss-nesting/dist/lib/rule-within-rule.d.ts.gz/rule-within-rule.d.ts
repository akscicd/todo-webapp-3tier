import type { Rule } from 'postcss';
import { options } from './options.js';
export default function transformRuleWithinRule(node: Rule, parent: Rule, opts: options): void;
export declare function isValidRuleWithinRule(node: Rule): boolean;
