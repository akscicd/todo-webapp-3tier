import type { ChildNode, Container } from 'postcss';
export default function shiftNodesBeforeParent(node: ChildNode, parent: Container<ChildNode>): void;
