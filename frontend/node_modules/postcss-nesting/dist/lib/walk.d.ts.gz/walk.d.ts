import type { Container } from 'postcss';
import { options } from './options.js';
export default function walk(node: Container, opts: options): void;
