'use strict';
/**
 * @param {string[]} grid
 * @return {string}
 */
module.exports = function joinGridVal(grid) {
  return grid.join(' / ').trim();
};
