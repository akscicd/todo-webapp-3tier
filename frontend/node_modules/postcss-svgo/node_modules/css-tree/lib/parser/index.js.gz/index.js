var createParser = require('./create');
var config = require('../syntax/config/parser');

module.exports = createParser(config);
