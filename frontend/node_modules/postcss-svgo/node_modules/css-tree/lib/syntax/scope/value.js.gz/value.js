module.exports = {
    getNode: require('./default'),
    'expression': require('../function/expression'),
    'var': require('../function/var')
};
