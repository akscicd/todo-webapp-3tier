module.exports = Function.call.bind(Object.prototype.hasOwnProperty);
