export var forceReflow = function forceReflow(node) {
  return node.scrollTop;
};