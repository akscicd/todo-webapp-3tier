module.exports = function () {
  throw new Error('Readable.from is not available in the browser')
};
