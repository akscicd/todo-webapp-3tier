const set = require('regenerate')();
set.addRange(0x108E0, 0x108F2).addRange(0x108F4, 0x108F5).addRange(0x108FB, 0x108FF);
exports.characters = set;
