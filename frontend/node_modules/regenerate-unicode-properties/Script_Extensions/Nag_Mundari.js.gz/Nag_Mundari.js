const set = require('regenerate')();
set.addRange(0x1E4D0, 0x1E4F9);
exports.characters = set;
