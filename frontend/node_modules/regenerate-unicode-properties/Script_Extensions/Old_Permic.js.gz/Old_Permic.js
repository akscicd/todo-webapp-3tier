const set = require('regenerate')(0x483);
set.addRange(0x10350, 0x1037A);
exports.characters = set;
