/*
 * MIT License http://opensource.org/licenses/MIT
 * Author: Ben Holloway @bholloway
 */
'use strict';

throw new Error('This "engine" is designed to fail at require time, for testing purposes only');
