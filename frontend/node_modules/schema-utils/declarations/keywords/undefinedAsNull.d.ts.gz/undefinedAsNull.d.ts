export default addUndefinedAsNullKeyword;
export type Ajv = import("ajv").Ajv;
/**
 *
 * @param {Ajv} ajv
 * @returns {Ajv}
 */
declare function addUndefinedAsNullKeyword(ajv: Ajv): Ajv;
