require('./').install({hookRequire: true});
