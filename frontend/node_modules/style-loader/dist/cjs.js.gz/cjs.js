"use strict";

const loader = require("./index");
module.exports = loader.default;