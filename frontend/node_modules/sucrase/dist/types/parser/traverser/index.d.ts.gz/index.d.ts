import type { File } from "../index";
export declare function parseFile(): File;
