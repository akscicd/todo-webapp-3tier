import type { Options } from "../index";
import type TokenProcessor from "../TokenProcessor";
export declare function getNonTypeIdentifiers(tokens: TokenProcessor, options: Options): Set<string>;
