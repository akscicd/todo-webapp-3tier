import { Selector } from "./parse";
export default function stringify(token: Selector[][]): string;
//# sourceMappingURL=stringify.d.ts.map