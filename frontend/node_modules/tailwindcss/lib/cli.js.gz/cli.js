#!/usr/bin/env node
"use strict";
if (false) {
    module.exports = require("./oxide/cli");
} else {
    module.exports = require("./cli/index");
}
