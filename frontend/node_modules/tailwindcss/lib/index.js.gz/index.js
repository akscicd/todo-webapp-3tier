"use strict";
module.exports = require("./plugin");
