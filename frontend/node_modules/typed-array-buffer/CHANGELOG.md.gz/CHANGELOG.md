# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2023-06-05

### Commits

- Initial implementation, tests, readme [`5bc2953`](https://github.com/ljharb/typed-array-buffer/commit/5bc295337b4310659832fc08699a4d10c2dbbded)
- Initial commit [`98b8ac9`](https://github.com/ljharb/typed-array-buffer/commit/98b8ac90f407c368effa25d395aeea1d72e1d4b6)
- npm init [`6a4a73c`](https://github.com/ljharb/typed-array-buffer/commit/6a4a73c66b1f13fd17699c6500a4979003676696)
- Only apps should have lockfiles [`7226abf`](https://github.com/ljharb/typed-array-buffer/commit/7226abfda329b99dc25526c48740b076d128a7be)
