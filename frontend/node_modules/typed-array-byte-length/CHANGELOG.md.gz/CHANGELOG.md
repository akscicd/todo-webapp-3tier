# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2023-07-14

### Commits

- Initial implementation, tests, readme [`b8800c8`](https://github.com/inspect-js/typed-array-byte-length/commit/b8800c8f7f0fddd8744fd13dfa6239a504b4dc8d)
- Initial commit [`72723d8`](https://github.com/inspect-js/typed-array-byte-length/commit/72723d8f8fbff27d74b19f5e096d2eb2087d90dc)
- Only apps should have lockfiles [`a7dfc57`](https://github.com/inspect-js/typed-array-byte-length/commit/a7dfc57098655049b9c43cf1c3a39f24205821be)
