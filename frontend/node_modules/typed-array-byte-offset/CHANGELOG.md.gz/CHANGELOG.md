# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2023-06-06

### Commits

- Initial implementation, tests, readme [`f227633`](https://github.com/inspect-js/typed-array-byte-offset/commit/f2276337a907bdfe9725af1b36c3109e76f2430d)
- Initial commit [`806bbaf`](https://github.com/inspect-js/typed-array-byte-offset/commit/806bbaf81e0267aebce5ae68cbf138718513642a)
- npm init [`1151981`](https://github.com/inspect-js/typed-array-byte-offset/commit/1151981427eb1fddab8599d36e6afea50a78293f)
- Only apps should have lockfiles [`5fa9933`](https://github.com/inspect-js/typed-array-byte-offset/commit/5fa9933275f10bdb9e8a175cc70a8228d4811642)
