define(function () {

  // A version of the `>` operator that can be passed around as a function.
  function greater(left, right) {
    return left > right;
  }

  return greater;

});
