var _setup = require('./_setup.js');
var _unmethodize = require('./_unmethodize.js');

var apply = _unmethodize(_setup.apply);

module.exports = apply;
