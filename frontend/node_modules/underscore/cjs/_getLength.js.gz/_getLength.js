var _shallowProperty = require('./_shallowProperty.js');

// Internal helper to obtain the `length` property of an object.
var getLength = _shallowProperty('length');

module.exports = getLength;
