var _setup = require('./_setup.js');
var _unmethodize = require('./_unmethodize.js');

var slice = _unmethodize(_setup.ArrayProto.slice);

module.exports = slice;
