function strictEqual(left, right) {
  return left === right;
}

module.exports = strictEqual;
