var _tagTester = require('./_tagTester.js');

var isError = _tagTester('Error');

module.exports = isError;
