// Is a given value equal to null?
function isNull(obj) {
  return obj === null;
}

module.exports = isNull;
