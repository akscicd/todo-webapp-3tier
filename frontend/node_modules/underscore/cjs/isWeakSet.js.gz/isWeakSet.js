var _tagTester = require('./_tagTester.js');

var isWeakSet = _tagTester('WeakSet');

module.exports = isWeakSet;
