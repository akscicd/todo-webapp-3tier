var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var join = _unmethodize(_setup.ArrayProto.join);

module.exports = join;
