var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var pop = _unmethodize(_setup.ArrayProto.pop);

module.exports = pop;
