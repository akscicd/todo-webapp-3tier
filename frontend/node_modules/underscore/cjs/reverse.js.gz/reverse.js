var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var reverse = _unmethodize(_setup.ArrayProto.reverse);

module.exports = reverse;
