var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var shift = _unmethodize(_setup.ArrayProto.shift);

module.exports = shift;
