var sample = require('./sample.js');

// Shuffle a collection.
function shuffle(obj) {
  return sample(obj, Infinity);
}

module.exports = shuffle;
