var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var slice = _unmethodize(_setup.ArrayProto.slice);

module.exports = slice;
