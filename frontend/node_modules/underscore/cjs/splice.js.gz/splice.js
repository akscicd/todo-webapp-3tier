var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var splice = _unmethodize(_setup.ArrayProto.splice);

module.exports = splice;
