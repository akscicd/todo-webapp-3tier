var _unmethodize = require('./_unmethodize.js');
var _setup = require('./_setup.js');

var unshift = _unmethodize(_setup.ArrayProto.unshift);

module.exports = unshift;
