import { URIRegExps } from "./uri";
export declare function buildExps(isIRI: boolean): URIRegExps;
declare const _default: URIRegExps;
export default _default;
