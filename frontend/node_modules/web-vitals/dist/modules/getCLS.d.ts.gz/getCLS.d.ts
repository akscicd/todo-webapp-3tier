import { ReportHandler } from './types.js';
export declare const getCLS: (onReport: ReportHandler, reportAllChanges?: boolean | undefined) => void;
