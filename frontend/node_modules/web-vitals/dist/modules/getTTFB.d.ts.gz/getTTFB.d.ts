import { ReportHandler } from './types.js';
export declare const getTTFB: (onReport: ReportHandler) => void;
