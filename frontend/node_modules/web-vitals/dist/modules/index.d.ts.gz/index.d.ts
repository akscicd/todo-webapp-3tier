export { getCLS } from './getCLS.js';
export { getFCP } from './getFCP.js';
export { getFID } from './getFID.js';
export { getLCP } from './getLCP.js';
export { getTTFB } from './getTTFB.js';
export * from './types.js';
