export declare const getVisibilityWatcher: () => {
    readonly firstHiddenTime: number;
};
