import { Metric } from '../types.js';
export declare const initMetric: (name: Metric['name'], value?: number | undefined) => Metric;
