interface onBFCacheRestoreCallback {
    (event: PageTransitionEvent): void;
}
export declare const onBFCacheRestore: (cb: onBFCacheRestoreCallback) => void;
export {};
