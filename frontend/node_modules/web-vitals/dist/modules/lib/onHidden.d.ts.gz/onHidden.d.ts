export interface OnHiddenCallback {
    (event: Event): void;
}
export declare const onHidden: (cb: OnHiddenCallback, once?: boolean | undefined) => void;
