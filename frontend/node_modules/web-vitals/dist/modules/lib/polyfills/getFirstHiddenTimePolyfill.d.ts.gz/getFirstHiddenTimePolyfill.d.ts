export declare const getFirstHiddenTime: () => number;
