import type { Plugin } from "ajv";
declare const dynamicDefaults: Plugin<undefined>;
export default dynamicDefaults;
