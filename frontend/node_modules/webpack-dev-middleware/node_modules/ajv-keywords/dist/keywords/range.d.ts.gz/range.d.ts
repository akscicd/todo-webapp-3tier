import type { Plugin } from "ajv";
declare const range: Plugin<undefined>;
export default range;
