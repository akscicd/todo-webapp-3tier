import type { Vocabulary } from "../types";
declare const draft2020Vocabularies: Vocabulary[];
export default draft2020Vocabularies;
