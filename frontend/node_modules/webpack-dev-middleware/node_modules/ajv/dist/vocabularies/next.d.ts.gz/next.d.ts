import type { Vocabulary } from "../types";
declare const next: Vocabulary;
export default next;
