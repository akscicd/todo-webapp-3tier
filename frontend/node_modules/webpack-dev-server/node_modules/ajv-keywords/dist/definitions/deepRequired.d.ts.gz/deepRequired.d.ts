import type { CodeKeywordDefinition } from "ajv";
export default function getDef(): CodeKeywordDefinition;
