import type { Vocabulary } from "../../types";
declare const unevaluated: Vocabulary;
export default unevaluated;
