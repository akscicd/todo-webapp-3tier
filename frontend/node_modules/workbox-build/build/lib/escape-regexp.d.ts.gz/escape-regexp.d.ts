export declare function escapeRegExp(str: string): string;
