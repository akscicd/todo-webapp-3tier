import { FileDetails } from '../types';
export declare function getCompositeDetails(compositeURL: string, dependencyDetails: Array<FileDetails>): FileDetails;
