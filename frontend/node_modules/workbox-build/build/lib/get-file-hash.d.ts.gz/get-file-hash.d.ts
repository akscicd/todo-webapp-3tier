export declare function getFileHash(file: string): string;
