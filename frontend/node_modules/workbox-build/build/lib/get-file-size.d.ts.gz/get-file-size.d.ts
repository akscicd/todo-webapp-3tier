export declare function getFileSize(file: string): number | null;
