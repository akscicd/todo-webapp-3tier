export declare function getSourceMapURL(srcContents: string): string | null;
