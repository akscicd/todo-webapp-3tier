import { FileDetails } from '../types';
export declare function getStringDetails(url: string, str: string): FileDetails;
