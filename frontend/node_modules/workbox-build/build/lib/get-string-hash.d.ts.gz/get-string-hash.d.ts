/// <reference types="node" />
import crypto from 'crypto';
export declare function getStringHash(input: crypto.BinaryLike): string;
