import { ManifestTransform } from '../types';
export declare function noRevisionForURLsMatchingTransform(regexp: RegExp): ManifestTransform;
