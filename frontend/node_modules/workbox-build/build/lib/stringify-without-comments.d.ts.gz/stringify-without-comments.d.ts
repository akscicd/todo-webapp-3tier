export declare function stringifyWithoutComments(obj: {
    [key: string]: any;
}): string;
