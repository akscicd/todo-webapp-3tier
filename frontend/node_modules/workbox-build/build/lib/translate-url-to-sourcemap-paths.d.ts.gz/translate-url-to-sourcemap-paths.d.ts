export declare function translateURLToSourcemapPaths(url: string | null, swSrc: string, swDest: string): {
    destPath: string | undefined;
    srcPath: string | undefined;
    warning: string | undefined;
};
