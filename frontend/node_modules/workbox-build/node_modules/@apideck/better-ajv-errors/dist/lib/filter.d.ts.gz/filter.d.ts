import { DefinedError } from 'ajv';
export declare const filterSingleErrorPerProperty: (errors: DefinedError[]) => DefinedError[];
