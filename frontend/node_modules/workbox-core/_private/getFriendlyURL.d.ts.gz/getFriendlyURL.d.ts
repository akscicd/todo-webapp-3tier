import '../_version.js';
declare const getFriendlyURL: (url: URL | string) => string;
export { getFriendlyURL };
