// @ts-ignore
try{self['workbox:core:6.6.0']&&_()}catch(e){}