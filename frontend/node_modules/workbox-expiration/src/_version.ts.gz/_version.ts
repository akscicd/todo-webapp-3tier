// @ts-ignore
try{self['workbox:expiration:6.6.0']&&_()}catch(e){}