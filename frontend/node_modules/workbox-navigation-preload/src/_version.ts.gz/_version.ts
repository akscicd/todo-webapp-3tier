// @ts-ignore
try{self['workbox:navigation-preload:6.6.0']&&_()}catch(e){}