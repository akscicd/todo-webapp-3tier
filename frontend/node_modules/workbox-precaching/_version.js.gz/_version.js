"use strict";
// @ts-ignore
try {
    self['workbox:precaching:6.5.4'] && _();
}
catch (e) { }
