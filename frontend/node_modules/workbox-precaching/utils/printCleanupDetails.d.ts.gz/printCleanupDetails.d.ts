import '../_version.js';
/**
 * @param {Array<string>} deletedURLs
 *
 * @private
 * @memberof workbox-precaching
 */
export declare function printCleanupDetails(deletedURLs: string[]): void;
