// @ts-ignore
try{self['workbox:routing:6.6.0']&&_()}catch(e){}