This module's documentation can be found at https://developer.chrome.com/docs/workbox/modules/workbox-webpack-plugin/
