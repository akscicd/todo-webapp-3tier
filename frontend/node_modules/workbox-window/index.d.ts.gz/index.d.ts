import { messageSW } from './messageSW.js';
import { Workbox } from './Workbox.js';
import './_version.js';
/**
 * @module workbox-window
 */
export { messageSW, Workbox };
export * from './utils/WorkboxEvent.js';
