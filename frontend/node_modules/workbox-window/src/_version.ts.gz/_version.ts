// @ts-ignore
try{self['workbox:window:6.6.0']&&_()}catch(e){}