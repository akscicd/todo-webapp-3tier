const legacy = require('../dist/legacy-exports')
module.exports = legacy.pairs
legacy.warnFileDeprecation(__filename)
