'use strict'
Object.defineProperty(exports, '__esModule', { value: true })

const legacy = require('../dist/legacy-exports')
exports.default = [legacy.intTime, legacy.floatTime, legacy.timestamp]
exports.floatTime = legacy.floatTime
exports.intTime = legacy.intTime
exports.timestamp = legacy.timestamp

legacy.warnFileDeprecation(__filename)
